﻿namespace Computer_And_Mobile_Shoppee_Management_System
{
    partial class frm_Search_Or_Update_Distributor
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frm_Search_Or_Update_Distributor));
            this.dtp_Tie_Up_Date = new System.Windows.Forms.DateTimePicker();
            this.pnl_Search_Or_Update_Distributor = new System.Windows.Forms.Panel();
            this.pb_Close = new System.Windows.Forms.PictureBox();
            this.pb_Back = new System.Windows.Forms.PictureBox();
            this.lbl_Header = new System.Windows.Forms.Label();
            this.tb_Aadhar_Card_No = new System.Windows.Forms.TextBox();
            this.tb_Mob_No2 = new System.Windows.Forms.TextBox();
            this.btn_Search = new System.Windows.Forms.Button();
            this.tb_Mob_No1 = new System.Windows.Forms.TextBox();
            this.lbl_Distributor_ID = new System.Windows.Forms.Label();
            this.tb_Pan_Card_No = new System.Windows.Forms.TextBox();
            this.tb_Email_ID = new System.Windows.Forms.TextBox();
            this.btn_Save = new System.Windows.Forms.Button();
            this.tb_Registration_No = new System.Windows.Forms.TextBox();
            this.tb_Address = new System.Windows.Forms.TextBox();
            this.tb_Distributor_ID = new System.Windows.Forms.TextBox();
            this.tb_Distributor_Name = new System.Windows.Forms.TextBox();
            this.btn_Update = new System.Windows.Forms.Button();
            this.cb_Brand_Delivered = new System.Windows.Forms.ComboBox();
            this.gb_Search_Or_Update_Distributor = new System.Windows.Forms.GroupBox();
            this.lbl_Pan_Card_No = new System.Windows.Forms.Label();
            this.lbl_Email_ID = new System.Windows.Forms.Label();
            this.lbl_Aadhar_Card_No = new System.Windows.Forms.Label();
            this.lbl_Brand_Delivered = new System.Windows.Forms.Label();
            this.lbl_Mob_No2 = new System.Windows.Forms.Label();
            this.lbl_Registration_No = new System.Windows.Forms.Label();
            this.lbl_Mob_No1 = new System.Windows.Forms.Label();
            this.lbl_Address = new System.Windows.Forms.Label();
            this.lbl_Tie_Up_Date = new System.Windows.Forms.Label();
            this.lbl_Distributor_Name = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.btn_Refresh = new System.Windows.Forms.Button();
            this.pnl_Search_Or_Update_Distributor.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pb_Close)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_Back)).BeginInit();
            this.gb_Search_Or_Update_Distributor.SuspendLayout();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // dtp_Tie_Up_Date
            // 
            this.dtp_Tie_Up_Date.Enabled = false;
            this.dtp_Tie_Up_Date.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtp_Tie_Up_Date.Location = new System.Drawing.Point(956, 201);
            this.dtp_Tie_Up_Date.Name = "dtp_Tie_Up_Date";
            this.dtp_Tie_Up_Date.Size = new System.Drawing.Size(263, 29);
            this.dtp_Tie_Up_Date.TabIndex = 9;
            // 
            // pnl_Search_Or_Update_Distributor
            // 
            this.pnl_Search_Or_Update_Distributor.BackColor = System.Drawing.Color.Indigo;
            this.pnl_Search_Or_Update_Distributor.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pnl_Search_Or_Update_Distributor.Controls.Add(this.pb_Close);
            this.pnl_Search_Or_Update_Distributor.Controls.Add(this.pb_Back);
            this.pnl_Search_Or_Update_Distributor.Controls.Add(this.lbl_Header);
            this.pnl_Search_Or_Update_Distributor.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnl_Search_Or_Update_Distributor.Location = new System.Drawing.Point(0, 0);
            this.pnl_Search_Or_Update_Distributor.Name = "pnl_Search_Or_Update_Distributor";
            this.pnl_Search_Or_Update_Distributor.Size = new System.Drawing.Size(1344, 98);
            this.pnl_Search_Or_Update_Distributor.TabIndex = 12;
            // 
            // pb_Close
            // 
            this.pb_Close.Image = ((System.Drawing.Image)(resources.GetObject("pb_Close.Image")));
            this.pb_Close.Location = new System.Drawing.Point(1225, 28);
            this.pb_Close.Name = "pb_Close";
            this.pb_Close.Size = new System.Drawing.Size(105, 55);
            this.pb_Close.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pb_Close.TabIndex = 2;
            this.pb_Close.TabStop = false;
            this.pb_Close.Click += new System.EventHandler(this.pb_Close_Click);
            // 
            // pb_Back
            // 
            this.pb_Back.Image = ((System.Drawing.Image)(resources.GetObject("pb_Back.Image")));
            this.pb_Back.Location = new System.Drawing.Point(13, 28);
            this.pb_Back.Name = "pb_Back";
            this.pb_Back.Size = new System.Drawing.Size(100, 50);
            this.pb_Back.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pb_Back.TabIndex = 1;
            this.pb_Back.TabStop = false;
            this.pb_Back.Click += new System.EventHandler(this.pb_Back_Click);
            // 
            // lbl_Header
            // 
            this.lbl_Header.AutoSize = true;
            this.lbl_Header.Font = new System.Drawing.Font("Lucida Bright", 27.75F, System.Drawing.FontStyle.Bold);
            this.lbl_Header.ForeColor = System.Drawing.Color.LavenderBlush;
            this.lbl_Header.Location = new System.Drawing.Point(412, 28);
            this.lbl_Header.Name = "lbl_Header";
            this.lbl_Header.Size = new System.Drawing.Size(559, 42);
            this.lbl_Header.TabIndex = 0;
            this.lbl_Header.Text = "Search Or Update Distributor";
            // 
            // tb_Aadhar_Card_No
            // 
            this.tb_Aadhar_Card_No.Enabled = false;
            this.tb_Aadhar_Card_No.Font = new System.Drawing.Font("Lucida Bright", 14.25F);
            this.tb_Aadhar_Card_No.Location = new System.Drawing.Point(956, 380);
            this.tb_Aadhar_Card_No.MaxLength = 14;
            this.tb_Aadhar_Card_No.Name = "tb_Aadhar_Card_No";
            this.tb_Aadhar_Card_No.Size = new System.Drawing.Size(263, 30);
            this.tb_Aadhar_Card_No.TabIndex = 0;
            this.tb_Aadhar_Card_No.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tb_Aadhar_Card_No_KeyPress);
            // 
            // tb_Mob_No2
            // 
            this.tb_Mob_No2.Font = new System.Drawing.Font("Lucida Bright", 14.25F);
            this.tb_Mob_No2.Location = new System.Drawing.Point(956, 316);
            this.tb_Mob_No2.MaxLength = 10;
            this.tb_Mob_No2.Name = "tb_Mob_No2";
            this.tb_Mob_No2.Size = new System.Drawing.Size(263, 30);
            this.tb_Mob_No2.TabIndex = 7;
            this.tb_Mob_No2.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tb_Mob_No2_KeyPress);
            // 
            // btn_Search
            // 
            this.btn_Search.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.btn_Search.Font = new System.Drawing.Font("Lucida Bright", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Search.ForeColor = System.Drawing.Color.White;
            this.btn_Search.Location = new System.Drawing.Point(625, 3);
            this.btn_Search.Name = "btn_Search";
            this.btn_Search.Size = new System.Drawing.Size(138, 50);
            this.btn_Search.TabIndex = 2;
            this.btn_Search.Text = "Search";
            this.btn_Search.UseVisualStyleBackColor = false;
            this.btn_Search.Click += new System.EventHandler(this.btn_Search_Click);
            // 
            // tb_Mob_No1
            // 
            this.tb_Mob_No1.Font = new System.Drawing.Font("Lucida Bright", 14.25F);
            this.tb_Mob_No1.Location = new System.Drawing.Point(956, 256);
            this.tb_Mob_No1.MaxLength = 10;
            this.tb_Mob_No1.Name = "tb_Mob_No1";
            this.tb_Mob_No1.Size = new System.Drawing.Size(263, 30);
            this.tb_Mob_No1.TabIndex = 6;
            this.tb_Mob_No1.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tb_Mob_No1_KeyPress);
            // 
            // lbl_Distributor_ID
            // 
            this.lbl_Distributor_ID.AutoSize = true;
            this.lbl_Distributor_ID.BackColor = System.Drawing.Color.SeaShell;
            this.lbl_Distributor_ID.Font = new System.Drawing.Font("Lucida Bright", 14.25F);
            this.lbl_Distributor_ID.ForeColor = System.Drawing.Color.DarkRed;
            this.lbl_Distributor_ID.Location = new System.Drawing.Point(35, 21);
            this.lbl_Distributor_ID.Name = "lbl_Distributor_ID";
            this.lbl_Distributor_ID.Size = new System.Drawing.Size(138, 22);
            this.lbl_Distributor_ID.TabIndex = 1;
            this.lbl_Distributor_ID.Text = "Distributor ID";
            // 
            // tb_Pan_Card_No
            // 
            this.tb_Pan_Card_No.Enabled = false;
            this.tb_Pan_Card_No.Font = new System.Drawing.Font("Lucida Bright", 14.25F);
            this.tb_Pan_Card_No.Location = new System.Drawing.Point(956, 443);
            this.tb_Pan_Card_No.MaxLength = 10;
            this.tb_Pan_Card_No.Name = "tb_Pan_Card_No";
            this.tb_Pan_Card_No.Size = new System.Drawing.Size(263, 30);
            this.tb_Pan_Card_No.TabIndex = 0;
            // 
            // tb_Email_ID
            // 
            this.tb_Email_ID.Font = new System.Drawing.Font("Lucida Bright", 14.25F);
            this.tb_Email_ID.Location = new System.Drawing.Point(336, 439);
            this.tb_Email_ID.Name = "tb_Email_ID";
            this.tb_Email_ID.Size = new System.Drawing.Size(263, 30);
            this.tb_Email_ID.TabIndex = 5;
            // 
            // btn_Save
            // 
            this.btn_Save.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.btn_Save.Font = new System.Drawing.Font("Lucida Bright", 27.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Save.ForeColor = System.Drawing.Color.White;
            this.btn_Save.Location = new System.Drawing.Point(366, 644);
            this.btn_Save.Name = "btn_Save";
            this.btn_Save.Size = new System.Drawing.Size(127, 56);
            this.btn_Save.TabIndex = 8;
            this.btn_Save.Text = "Save";
            this.btn_Save.UseVisualStyleBackColor = false;
            this.btn_Save.Click += new System.EventHandler(this.btn_Save_Click);
            // 
            // tb_Registration_No
            // 
            this.tb_Registration_No.Enabled = false;
            this.tb_Registration_No.Font = new System.Drawing.Font("Lucida Bright", 14.25F);
            this.tb_Registration_No.Location = new System.Drawing.Point(336, 320);
            this.tb_Registration_No.Name = "tb_Registration_No";
            this.tb_Registration_No.Size = new System.Drawing.Size(263, 30);
            this.tb_Registration_No.TabIndex = 0;
            // 
            // tb_Address
            // 
            this.tb_Address.Font = new System.Drawing.Font("Lucida Bright", 14.25F);
            this.tb_Address.Location = new System.Drawing.Point(336, 260);
            this.tb_Address.Name = "tb_Address";
            this.tb_Address.Size = new System.Drawing.Size(263, 30);
            this.tb_Address.TabIndex = 4;
            // 
            // tb_Distributor_ID
            // 
            this.tb_Distributor_ID.Location = new System.Drawing.Point(233, 18);
            this.tb_Distributor_ID.MaxLength = 3;
            this.tb_Distributor_ID.Name = "tb_Distributor_ID";
            this.tb_Distributor_ID.Size = new System.Drawing.Size(263, 29);
            this.tb_Distributor_ID.TabIndex = 1;
            this.tb_Distributor_ID.TextChanged += new System.EventHandler(this.tb_Distributor_ID_TextChanged);
            this.tb_Distributor_ID.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tb_Distributor_ID_KeyPress);
            // 
            // tb_Distributor_Name
            // 
            this.tb_Distributor_Name.Enabled = false;
            this.tb_Distributor_Name.Font = new System.Drawing.Font("Lucida Bright", 14.25F);
            this.tb_Distributor_Name.Location = new System.Drawing.Point(336, 201);
            this.tb_Distributor_Name.Name = "tb_Distributor_Name";
            this.tb_Distributor_Name.Size = new System.Drawing.Size(263, 30);
            this.tb_Distributor_Name.TabIndex = 4;
            // 
            // btn_Update
            // 
            this.btn_Update.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.btn_Update.Font = new System.Drawing.Font("Lucida Bright", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Update.ForeColor = System.Drawing.Color.White;
            this.btn_Update.Location = new System.Drawing.Point(885, 3);
            this.btn_Update.Name = "btn_Update";
            this.btn_Update.Size = new System.Drawing.Size(150, 50);
            this.btn_Update.TabIndex = 3;
            this.btn_Update.Text = "Update";
            this.btn_Update.UseVisualStyleBackColor = false;
            this.btn_Update.Click += new System.EventHandler(this.btn_Update_Click);
            // 
            // cb_Brand_Delivered
            // 
            this.cb_Brand_Delivered.Enabled = false;
            this.cb_Brand_Delivered.FormattingEnabled = true;
            this.cb_Brand_Delivered.Location = new System.Drawing.Point(336, 384);
            this.cb_Brand_Delivered.Name = "cb_Brand_Delivered";
            this.cb_Brand_Delivered.Size = new System.Drawing.Size(263, 31);
            this.cb_Brand_Delivered.TabIndex = 0;
            // 
            // gb_Search_Or_Update_Distributor
            // 
            this.gb_Search_Or_Update_Distributor.Controls.Add(this.dtp_Tie_Up_Date);
            this.gb_Search_Or_Update_Distributor.Controls.Add(this.tb_Aadhar_Card_No);
            this.gb_Search_Or_Update_Distributor.Controls.Add(this.tb_Mob_No2);
            this.gb_Search_Or_Update_Distributor.Controls.Add(this.tb_Mob_No1);
            this.gb_Search_Or_Update_Distributor.Controls.Add(this.tb_Pan_Card_No);
            this.gb_Search_Or_Update_Distributor.Controls.Add(this.tb_Email_ID);
            this.gb_Search_Or_Update_Distributor.Controls.Add(this.tb_Registration_No);
            this.gb_Search_Or_Update_Distributor.Controls.Add(this.tb_Address);
            this.gb_Search_Or_Update_Distributor.Controls.Add(this.tb_Distributor_Name);
            this.gb_Search_Or_Update_Distributor.Controls.Add(this.cb_Brand_Delivered);
            this.gb_Search_Or_Update_Distributor.Controls.Add(this.lbl_Pan_Card_No);
            this.gb_Search_Or_Update_Distributor.Controls.Add(this.lbl_Email_ID);
            this.gb_Search_Or_Update_Distributor.Controls.Add(this.lbl_Aadhar_Card_No);
            this.gb_Search_Or_Update_Distributor.Controls.Add(this.lbl_Brand_Delivered);
            this.gb_Search_Or_Update_Distributor.Controls.Add(this.lbl_Mob_No2);
            this.gb_Search_Or_Update_Distributor.Controls.Add(this.lbl_Registration_No);
            this.gb_Search_Or_Update_Distributor.Controls.Add(this.lbl_Mob_No1);
            this.gb_Search_Or_Update_Distributor.Controls.Add(this.lbl_Address);
            this.gb_Search_Or_Update_Distributor.Controls.Add(this.lbl_Tie_Up_Date);
            this.gb_Search_Or_Update_Distributor.Controls.Add(this.lbl_Distributor_Name);
            this.gb_Search_Or_Update_Distributor.Controls.Add(this.panel1);
            this.gb_Search_Or_Update_Distributor.Font = new System.Drawing.Font("Georgia", 14.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))));
            this.gb_Search_Or_Update_Distributor.ForeColor = System.Drawing.Color.Black;
            this.gb_Search_Or_Update_Distributor.Location = new System.Drawing.Point(13, 104);
            this.gb_Search_Or_Update_Distributor.Name = "gb_Search_Or_Update_Distributor";
            this.gb_Search_Or_Update_Distributor.Size = new System.Drawing.Size(1320, 522);
            this.gb_Search_Or_Update_Distributor.TabIndex = 13;
            this.gb_Search_Or_Update_Distributor.TabStop = false;
            this.gb_Search_Or_Update_Distributor.Text = "Search Or Update Distributor";
            // 
            // lbl_Pan_Card_No
            // 
            this.lbl_Pan_Card_No.AutoSize = true;
            this.lbl_Pan_Card_No.BackColor = System.Drawing.Color.SeaShell;
            this.lbl_Pan_Card_No.Font = new System.Drawing.Font("Lucida Bright", 14.25F);
            this.lbl_Pan_Card_No.ForeColor = System.Drawing.Color.DarkRed;
            this.lbl_Pan_Card_No.Location = new System.Drawing.Point(743, 443);
            this.lbl_Pan_Card_No.Name = "lbl_Pan_Card_No";
            this.lbl_Pan_Card_No.Size = new System.Drawing.Size(126, 22);
            this.lbl_Pan_Card_No.TabIndex = 1;
            this.lbl_Pan_Card_No.Text = "Pan Card No";
            // 
            // lbl_Email_ID
            // 
            this.lbl_Email_ID.AutoSize = true;
            this.lbl_Email_ID.BackColor = System.Drawing.Color.SeaShell;
            this.lbl_Email_ID.Font = new System.Drawing.Font("Lucida Bright", 14.25F);
            this.lbl_Email_ID.ForeColor = System.Drawing.Color.DarkRed;
            this.lbl_Email_ID.Location = new System.Drawing.Point(101, 443);
            this.lbl_Email_ID.Name = "lbl_Email_ID";
            this.lbl_Email_ID.Size = new System.Drawing.Size(88, 22);
            this.lbl_Email_ID.TabIndex = 1;
            this.lbl_Email_ID.Text = "Email ID";
            // 
            // lbl_Aadhar_Card_No
            // 
            this.lbl_Aadhar_Card_No.AutoSize = true;
            this.lbl_Aadhar_Card_No.BackColor = System.Drawing.Color.SeaShell;
            this.lbl_Aadhar_Card_No.Font = new System.Drawing.Font("Lucida Bright", 14.25F);
            this.lbl_Aadhar_Card_No.ForeColor = System.Drawing.Color.DarkRed;
            this.lbl_Aadhar_Card_No.Location = new System.Drawing.Point(743, 384);
            this.lbl_Aadhar_Card_No.Name = "lbl_Aadhar_Card_No";
            this.lbl_Aadhar_Card_No.Size = new System.Drawing.Size(162, 22);
            this.lbl_Aadhar_Card_No.TabIndex = 1;
            this.lbl_Aadhar_Card_No.Text = "Aadhar Card No";
            // 
            // lbl_Brand_Delivered
            // 
            this.lbl_Brand_Delivered.AutoSize = true;
            this.lbl_Brand_Delivered.BackColor = System.Drawing.Color.SeaShell;
            this.lbl_Brand_Delivered.Font = new System.Drawing.Font("Lucida Bright", 14.25F);
            this.lbl_Brand_Delivered.ForeColor = System.Drawing.Color.DarkRed;
            this.lbl_Brand_Delivered.Location = new System.Drawing.Point(101, 384);
            this.lbl_Brand_Delivered.Name = "lbl_Brand_Delivered";
            this.lbl_Brand_Delivered.Size = new System.Drawing.Size(158, 22);
            this.lbl_Brand_Delivered.TabIndex = 1;
            this.lbl_Brand_Delivered.Text = "Brand Delivered";
            // 
            // lbl_Mob_No2
            // 
            this.lbl_Mob_No2.AutoSize = true;
            this.lbl_Mob_No2.BackColor = System.Drawing.Color.SeaShell;
            this.lbl_Mob_No2.Font = new System.Drawing.Font("Lucida Bright", 14.25F);
            this.lbl_Mob_No2.ForeColor = System.Drawing.Color.DarkRed;
            this.lbl_Mob_No2.Location = new System.Drawing.Point(743, 320);
            this.lbl_Mob_No2.Name = "lbl_Mob_No2";
            this.lbl_Mob_No2.Size = new System.Drawing.Size(121, 22);
            this.lbl_Mob_No2.TabIndex = 1;
            this.lbl_Mob_No2.Text = "Mobile No 2";
            // 
            // lbl_Registration_No
            // 
            this.lbl_Registration_No.AutoSize = true;
            this.lbl_Registration_No.BackColor = System.Drawing.Color.SeaShell;
            this.lbl_Registration_No.Font = new System.Drawing.Font("Lucida Bright", 14.25F);
            this.lbl_Registration_No.ForeColor = System.Drawing.Color.DarkRed;
            this.lbl_Registration_No.Location = new System.Drawing.Point(98, 320);
            this.lbl_Registration_No.Name = "lbl_Registration_No";
            this.lbl_Registration_No.Size = new System.Drawing.Size(155, 22);
            this.lbl_Registration_No.TabIndex = 1;
            this.lbl_Registration_No.Text = "Registration No";
            // 
            // lbl_Mob_No1
            // 
            this.lbl_Mob_No1.AutoSize = true;
            this.lbl_Mob_No1.BackColor = System.Drawing.Color.SeaShell;
            this.lbl_Mob_No1.Font = new System.Drawing.Font("Lucida Bright", 14.25F);
            this.lbl_Mob_No1.ForeColor = System.Drawing.Color.DarkRed;
            this.lbl_Mob_No1.Location = new System.Drawing.Point(743, 260);
            this.lbl_Mob_No1.Name = "lbl_Mob_No1";
            this.lbl_Mob_No1.Size = new System.Drawing.Size(121, 22);
            this.lbl_Mob_No1.TabIndex = 1;
            this.lbl_Mob_No1.Text = "Mobile No 1";
            // 
            // lbl_Address
            // 
            this.lbl_Address.AutoSize = true;
            this.lbl_Address.BackColor = System.Drawing.Color.SeaShell;
            this.lbl_Address.Font = new System.Drawing.Font("Lucida Bright", 14.25F);
            this.lbl_Address.ForeColor = System.Drawing.Color.DarkRed;
            this.lbl_Address.Location = new System.Drawing.Point(101, 260);
            this.lbl_Address.Name = "lbl_Address";
            this.lbl_Address.Size = new System.Drawing.Size(85, 22);
            this.lbl_Address.TabIndex = 1;
            this.lbl_Address.Text = "Address";
            // 
            // lbl_Tie_Up_Date
            // 
            this.lbl_Tie_Up_Date.AutoSize = true;
            this.lbl_Tie_Up_Date.BackColor = System.Drawing.Color.SeaShell;
            this.lbl_Tie_Up_Date.Font = new System.Drawing.Font("Lucida Bright", 14.25F);
            this.lbl_Tie_Up_Date.ForeColor = System.Drawing.Color.DarkRed;
            this.lbl_Tie_Up_Date.Location = new System.Drawing.Point(743, 207);
            this.lbl_Tie_Up_Date.Name = "lbl_Tie_Up_Date";
            this.lbl_Tie_Up_Date.Size = new System.Drawing.Size(119, 22);
            this.lbl_Tie_Up_Date.TabIndex = 1;
            this.lbl_Tie_Up_Date.Text = "Tie-Up Date";
            // 
            // lbl_Distributor_Name
            // 
            this.lbl_Distributor_Name.AutoSize = true;
            this.lbl_Distributor_Name.BackColor = System.Drawing.Color.SeaShell;
            this.lbl_Distributor_Name.Font = new System.Drawing.Font("Lucida Bright", 14.25F);
            this.lbl_Distributor_Name.ForeColor = System.Drawing.Color.DarkRed;
            this.lbl_Distributor_Name.Location = new System.Drawing.Point(98, 201);
            this.lbl_Distributor_Name.Name = "lbl_Distributor_Name";
            this.lbl_Distributor_Name.Size = new System.Drawing.Size(171, 22);
            this.lbl_Distributor_Name.TabIndex = 1;
            this.lbl_Distributor_Name.Text = "Distributor Name";
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Silver;
            this.panel1.Controls.Add(this.btn_Update);
            this.panel1.Controls.Add(this.btn_Search);
            this.panel1.Controls.Add(this.lbl_Distributor_ID);
            this.panel1.Controls.Add(this.tb_Distributor_ID);
            this.panel1.Location = new System.Drawing.Point(88, 75);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1148, 63);
            this.panel1.TabIndex = 0;
            // 
            // btn_Refresh
            // 
            this.btn_Refresh.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.btn_Refresh.Font = new System.Drawing.Font("Lucida Bright", 27.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Refresh.ForeColor = System.Drawing.Color.White;
            this.btn_Refresh.Location = new System.Drawing.Point(872, 644);
            this.btn_Refresh.Name = "btn_Refresh";
            this.btn_Refresh.Size = new System.Drawing.Size(170, 56);
            this.btn_Refresh.TabIndex = 9;
            this.btn_Refresh.Text = "Refresh";
            this.btn_Refresh.UseVisualStyleBackColor = false;
            this.btn_Refresh.Click += new System.EventHandler(this.btn_Refresh_Click);
            // 
            // frm_Search_Or_Update_Distributor
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(15F, 28F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.ClientSize = new System.Drawing.Size(1344, 712);
            this.Controls.Add(this.pnl_Search_Or_Update_Distributor);
            this.Controls.Add(this.btn_Save);
            this.Controls.Add(this.gb_Search_Or_Update_Distributor);
            this.Controls.Add(this.btn_Refresh);
            this.Font = new System.Drawing.Font("Lucida Bright", 18F);
            this.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.Margin = new System.Windows.Forms.Padding(8, 6, 8, 6);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "frm_Search_Or_Update_Distributor";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Search Or Update Distributor";
            this.Load += new System.EventHandler(this.frm_Search_Or_Update_Distributor_Load);
            this.pnl_Search_Or_Update_Distributor.ResumeLayout(false);
            this.pnl_Search_Or_Update_Distributor.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pb_Close)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_Back)).EndInit();
            this.gb_Search_Or_Update_Distributor.ResumeLayout(false);
            this.gb_Search_Or_Update_Distributor.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DateTimePicker dtp_Tie_Up_Date;
        private System.Windows.Forms.Panel pnl_Search_Or_Update_Distributor;
        private System.Windows.Forms.PictureBox pb_Close;
        private System.Windows.Forms.PictureBox pb_Back;
        private System.Windows.Forms.TextBox tb_Aadhar_Card_No;
        private System.Windows.Forms.TextBox tb_Mob_No2;
        private System.Windows.Forms.Button btn_Search;
        private System.Windows.Forms.TextBox tb_Mob_No1;
        private System.Windows.Forms.Label lbl_Distributor_ID;
        private System.Windows.Forms.TextBox tb_Pan_Card_No;
        private System.Windows.Forms.TextBox tb_Email_ID;
        private System.Windows.Forms.Button btn_Save;
        private System.Windows.Forms.TextBox tb_Registration_No;
        private System.Windows.Forms.TextBox tb_Address;
        private System.Windows.Forms.TextBox tb_Distributor_ID;
        private System.Windows.Forms.TextBox tb_Distributor_Name;
        private System.Windows.Forms.Button btn_Update;
        private System.Windows.Forms.ComboBox cb_Brand_Delivered;
        private System.Windows.Forms.GroupBox gb_Search_Or_Update_Distributor;
        private System.Windows.Forms.Label lbl_Pan_Card_No;
        private System.Windows.Forms.Label lbl_Email_ID;
        private System.Windows.Forms.Label lbl_Aadhar_Card_No;
        private System.Windows.Forms.Label lbl_Brand_Delivered;
        private System.Windows.Forms.Label lbl_Mob_No2;
        private System.Windows.Forms.Label lbl_Registration_No;
        private System.Windows.Forms.Label lbl_Mob_No1;
        private System.Windows.Forms.Label lbl_Address;
        private System.Windows.Forms.Label lbl_Tie_Up_Date;
        private System.Windows.Forms.Label lbl_Distributor_Name;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button btn_Refresh;
        private System.Windows.Forms.Label lbl_Header;
    }
}