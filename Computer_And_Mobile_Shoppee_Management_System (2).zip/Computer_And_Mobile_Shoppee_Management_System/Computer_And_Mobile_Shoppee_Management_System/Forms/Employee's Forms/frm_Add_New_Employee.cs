﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Computer_And_Mobile_Shoppee_Management_System
{
    public partial class frm_Add_New_Employee : Form
    {
        Global_ClassFile Gobj = new Global_ClassFile();

        public frm_Add_New_Employee()
        {
            InitializeComponent();
        }

        int Auto_Incr_ID()
        {
            Gobj.ConnectDB();

            int Cnt = 0;

            SqlCommand Cmd = new SqlCommand();

            Cmd.CommandText = "Select Count(Employee_ID) from Employee_Details";
            Cmd.Connection = Gobj.Con;

            Cnt = Convert.ToInt32(Cmd.ExecuteScalar());

            Cmd.Dispose();

            if (Cnt > 0)
            {
                Cmd.CommandText = "Select Max(Employee_ID) from Employee_Details";
                Cmd.Connection = Gobj.Con;
            }

            Cnt = 1 + Cnt;

            Gobj.DisconnectDB();

            return Cnt;
        }

        void Clear_Controls()
        {
            tb_Emp_ID.Text = Convert.ToString(Auto_Incr_ID());
            tb_Emp_Name.Text = " ";
            dtp_DOB.ResetText();
            tb_Address.Text = "";
            tb_Email_ID.Text = "";
            dtp_Joining_Date.ResetText();
            tb_Mob_No1.Text = "";
            tb_Mob_No2.Text = "";
            tb_Aadhar_No.Text = "";
            tb_Pan_No.Text = "";
            tb_Salary.Text = "";
            rb_Female.Checked = false;
            rb_Male.Checked = false;
            tb_Emp_Name.Focus();
        }

        private void frm_Add_New_Employee_Load(object sender, EventArgs e)
        {
            Clear_Controls();
        }

        private void tb_Mob_No1_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!(Char.IsDigit(e.KeyChar) || (e.KeyChar == (char)Keys.Back)))
            {
                e.Handled = true;
            }
        }

        private void tb_Mob_No2_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!(Char.IsDigit(e.KeyChar) || (e.KeyChar == (char)Keys.Back)))
            {
                e.Handled = true;
            }
        }

        private void tb_Aadhar_No_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!(Char.IsDigit(e.KeyChar) || (e.KeyChar == (char)Keys.Back)))
            {
                e.Handled = true;
            }
        }

        private void btn_Save_Click(object sender, EventArgs e)
        {
            Gobj.ConnectDB();

            if (tb_Mob_No1.TextLength < 10)
            {
                MessageBox.Show("Invalid Mobile Number", "Failure", MessageBoxButtons.OK, MessageBoxIcon.Error);
                tb_Mob_No1.Focus();
                goto DWN;
            }

            if (tb_Aadhar_No.TextLength < 12)
            {
                MessageBox.Show("Invalid Aadhar Card Number", "Failure", MessageBoxButtons.OK, MessageBoxIcon.Error);
                tb_Aadhar_No.Focus();
                goto DWN;
            }

            if (tb_Pan_No.TextLength < 10)
            {
                MessageBox.Show("Invalid Pan Card Number", "Failure", MessageBoxButtons.OK, MessageBoxIcon.Error);
                tb_Pan_No.Focus();
                goto DWN;
            }

            string Gender = "";

            if (rb_Male.Checked)
            {
                Gender = rb_Male.Text;
            }
            else if (rb_Female.Checked)
            {
                Gender = rb_Female.Text;
            }

            long Mob_No2 = 0;

            if (tb_Mob_No2.Text != "")
            {
                Mob_No2 = Convert.ToInt64(tb_Mob_No2.Text);
            }

            if (tb_Emp_ID.Text!="" && tb_Emp_Name.Text != "" && tb_Address.Text != "" && tb_Mob_No1.Text != "" && tb_Aadhar_No.Text != "" && tb_Pan_No.Text != "" && tb_Salary.Text != "")
            {
                SqlDataAdapter sda = new SqlDataAdapter("Insert into Employee_Details(Employee_Name ,Date_Of_Birth ,Gender ,Address ,Email_ID ,Joining_Date ,Mobile_No_1 ,Mobile_No_2 ,Aadhar_Card_No ,Pan_Card_No ,Salary ,Username) values('" + tb_Emp_Name.Text + "','" + dtp_DOB.Text + "','" + Gender + "','" + tb_Address.Text + "','" + tb_Email_ID.Text + "','" + dtp_Joining_Date.Text + "'," + tb_Mob_No1.Text + "," + Mob_No2 + "," + tb_Aadhar_No.Text + ",'" + tb_Pan_No.Text + "'," + tb_Salary.Text + ",'" + Global_ClassFile.Uname + "')", Gobj.Con);
                DataTable DT = new DataTable();
                sda.Fill(DT);

                MessageBox.Show("Record Saved Successfully...", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);

                Clear_Controls();
            }
            else
            {
                MessageBox.Show("Please, Fill All The Fields", "Failure", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

            DWN:
            Gobj.DisconnectDB();
        }

        private void btn_Refresh_Click(object sender, EventArgs e)
        {
            Clear_Controls();
            pb_Back.Focus();
        }

        private void pb_Back_Click(object sender, EventArgs e)
        {
            frm_Employee_Entry_Form Obj = new frm_Employee_Entry_Form();

            Obj.WindowState = FormWindowState.Maximized;
            this.Hide();
            Obj.Show();
        }

        private void pb_Close_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show("Do You Want To Close This Appllication?", "close Application", MessageBoxButtons.YesNo);

            if (result == DialogResult.Yes)
            {
                frm_Login obj = new frm_Login();
                this.Hide();
                obj.Show();
            }
            else
            {
                this.Show();
            }
        }       
    }
}
