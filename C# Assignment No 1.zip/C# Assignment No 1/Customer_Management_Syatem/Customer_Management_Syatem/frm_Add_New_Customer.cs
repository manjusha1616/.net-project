﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Customer_Management_Syatem
{
    public partial class frm_Add_New_Customer : Form
    {
        SqlConnection Con = new SqlConnection(@"Data Source=.\SQLEXPRESS;Initial Catalog=Customer_Data_System_DB;Integrated Security=True");

        void Con_Open()
        {
            if (Con.State == ConnectionState.Closed)
            {
                Con.Open();
            }
        }

        void Con_Close()
        {
            if (Con.State == ConnectionState.Open)
            {
                Con.Close();
            }
        }

        public frm_Add_New_Customer()
        {
            InitializeComponent();
        }

        private void btn_Log_Out_Click(object sender, EventArgs e)
        {
            frm_Login a = new frm_Login();
            a.Show();
            this.Hide();
        }

         private void btn_View_All_Customers_Click(object sender, EventArgs e)
        {
            frm_View_All_Customers obj = new frm_View_All_Customers();
            obj.Show();
            this.Hide();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (tb_Cust_ID.Text != "" && tb_Name.Text != "" && tb_Mob_No.Text != "" && cb_City.Text != "")
            {
                Con_Open();

                SqlDataAdapter sda = new SqlDataAdapter("Insert into Customer_Details(Cust_ID ,Name ,Mob_No ,DOB ,City) values(" + tb_Cust_ID.Text + ",'" + tb_Name.Text + "'," + tb_Mob_No.Text + ",'" + dtp_DOB.Text + "','" + cb_City.Text + "')", Con);
                DataTable dtp = new DataTable();
                sda.Fill(dtp);

                MessageBox.Show("Record Saved Successfully...");

                tb_Cust_ID.Text = "";
                tb_Name.Text = "";
                tb_Mob_No.Text = "";
                dtp_DOB.Text = "";
                cb_City.SelectedIndex = 0;
            }
            else
            {
                MessageBox.Show("Please, Fill All The Fields");
            }

            Con_Close();

        }
    }
}
