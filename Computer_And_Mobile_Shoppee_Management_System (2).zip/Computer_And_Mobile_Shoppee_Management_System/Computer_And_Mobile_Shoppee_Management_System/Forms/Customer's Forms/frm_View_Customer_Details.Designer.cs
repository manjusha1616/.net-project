﻿namespace Computer_And_Mobile_Shoppee_Management_System
{
    partial class frm_View_Customer_Details
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frm_View_Customer_Details));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            this.pb_Close = new System.Windows.Forms.PictureBox();
            this.btn_Refresh = new System.Windows.Forms.Button();
            this.computer_And_Mob_Shoppee_Mgt_Sys_DBDataSet1 = new Computer_And_Mobile_Shoppee_Management_System.Computer_And_Mob_Shoppee_Mgt_Sys_DBDataSet1();
            this.employeeDetailsBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.pb_Back = new System.Windows.Forms.PictureBox();
            this.pnl_View_Emp = new System.Windows.Forms.Panel();
            this.dtp_Date2 = new System.Windows.Forms.DateTimePicker();
            this.dtp_Date = new System.Windows.Forms.DateTimePicker();
            this.lbl_To = new System.Windows.Forms.Label();
            this.btn_Search = new System.Windows.Forms.Button();
            this.lbl_From = new System.Windows.Forms.Label();
            this.lbl_Header = new System.Windows.Forms.Label();
            this.pnl_View_All_Employees = new System.Windows.Forms.Panel();
            this.gb_Customer_Details = new System.Windows.Forms.GroupBox();
            this.dgv_Customer_Details = new System.Windows.Forms.DataGridView();
            this.customerIDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.productNameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.quantityDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.gstDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.priceDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.usernameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.customerBillDetailsBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.computer_And_Mob_Shoppee_Mgt_Sys_DBDataSet4 = new Computer_And_Mobile_Shoppee_Management_System.Computer_And_Mob_Shoppee_Mgt_Sys_DBDataSet4();
            this.employee_DetailsTableAdapter = new Computer_And_Mobile_Shoppee_Management_System.Computer_And_Mob_Shoppee_Mgt_Sys_DBDataSet1TableAdapters.Employee_DetailsTableAdapter();
            this.customer_Bill_DetailsTableAdapter = new Computer_And_Mobile_Shoppee_Management_System.Computer_And_Mob_Shoppee_Mgt_Sys_DBDataSet4TableAdapters.Customer_Bill_DetailsTableAdapter();
            ((System.ComponentModel.ISupportInitialize)(this.pb_Close)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.computer_And_Mob_Shoppee_Mgt_Sys_DBDataSet1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.employeeDetailsBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_Back)).BeginInit();
            this.pnl_View_Emp.SuspendLayout();
            this.pnl_View_All_Employees.SuspendLayout();
            this.gb_Customer_Details.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_Customer_Details)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.customerBillDetailsBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.computer_And_Mob_Shoppee_Mgt_Sys_DBDataSet4)).BeginInit();
            this.SuspendLayout();
            // 
            // pb_Close
            // 
            this.pb_Close.Image = ((System.Drawing.Image)(resources.GetObject("pb_Close.Image")));
            this.pb_Close.Location = new System.Drawing.Point(1226, 22);
            this.pb_Close.Name = "pb_Close";
            this.pb_Close.Size = new System.Drawing.Size(105, 50);
            this.pb_Close.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pb_Close.TabIndex = 4;
            this.pb_Close.TabStop = false;
            this.pb_Close.Click += new System.EventHandler(this.pb_Close_Click);
            // 
            // btn_Refresh
            // 
            this.btn_Refresh.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.btn_Refresh.Font = new System.Drawing.Font("Lucida Bright", 27.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Refresh.ForeColor = System.Drawing.Color.White;
            this.btn_Refresh.Location = new System.Drawing.Point(601, 629);
            this.btn_Refresh.Name = "btn_Refresh";
            this.btn_Refresh.Size = new System.Drawing.Size(170, 56);
            this.btn_Refresh.TabIndex = 11;
            this.btn_Refresh.Text = "Refresh";
            this.btn_Refresh.UseVisualStyleBackColor = false;
            this.btn_Refresh.Click += new System.EventHandler(this.btn_Refresh_Click);
            // 
            // computer_And_Mob_Shoppee_Mgt_Sys_DBDataSet1
            // 
            this.computer_And_Mob_Shoppee_Mgt_Sys_DBDataSet1.DataSetName = "Computer_And_Mob_Shoppee_Mgt_Sys_DBDataSet1";
            this.computer_And_Mob_Shoppee_Mgt_Sys_DBDataSet1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // employeeDetailsBindingSource
            // 
            this.employeeDetailsBindingSource.DataMember = "Employee_Details";
            this.employeeDetailsBindingSource.DataSource = this.computer_And_Mob_Shoppee_Mgt_Sys_DBDataSet1;
            // 
            // pb_Back
            // 
            this.pb_Back.Image = ((System.Drawing.Image)(resources.GetObject("pb_Back.Image")));
            this.pb_Back.Location = new System.Drawing.Point(12, 22);
            this.pb_Back.Name = "pb_Back";
            this.pb_Back.Size = new System.Drawing.Size(100, 50);
            this.pb_Back.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pb_Back.TabIndex = 3;
            this.pb_Back.TabStop = false;
            this.pb_Back.Click += new System.EventHandler(this.pb_Back_Click);
            // 
            // pnl_View_Emp
            // 
            this.pnl_View_Emp.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.pnl_View_Emp.BackColor = System.Drawing.Color.Silver;
            this.pnl_View_Emp.Controls.Add(this.dtp_Date2);
            this.pnl_View_Emp.Controls.Add(this.dtp_Date);
            this.pnl_View_Emp.Controls.Add(this.lbl_To);
            this.pnl_View_Emp.Controls.Add(this.btn_Search);
            this.pnl_View_Emp.Controls.Add(this.lbl_From);
            this.pnl_View_Emp.Location = new System.Drawing.Point(102, 45);
            this.pnl_View_Emp.Name = "pnl_View_Emp";
            this.pnl_View_Emp.Size = new System.Drawing.Size(1127, 64);
            this.pnl_View_Emp.TabIndex = 17;
            // 
            // dtp_Date2
            // 
            this.dtp_Date2.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtp_Date2.Location = new System.Drawing.Point(594, 20);
            this.dtp_Date2.Name = "dtp_Date2";
            this.dtp_Date2.Size = new System.Drawing.Size(237, 29);
            this.dtp_Date2.TabIndex = 3;
            // 
            // dtp_Date
            // 
            this.dtp_Date.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtp_Date.Location = new System.Drawing.Point(167, 20);
            this.dtp_Date.Name = "dtp_Date";
            this.dtp_Date.Size = new System.Drawing.Size(237, 29);
            this.dtp_Date.TabIndex = 3;
            // 
            // lbl_To
            // 
            this.lbl_To.AutoSize = true;
            this.lbl_To.BackColor = System.Drawing.Color.SeaShell;
            this.lbl_To.Font = new System.Drawing.Font("Lucida Bright", 14.25F);
            this.lbl_To.ForeColor = System.Drawing.Color.DarkRed;
            this.lbl_To.Location = new System.Drawing.Point(482, 26);
            this.lbl_To.Name = "lbl_To";
            this.lbl_To.Size = new System.Drawing.Size(83, 22);
            this.lbl_To.TabIndex = 0;
            this.lbl_To.Text = "To Date";
            // 
            // btn_Search
            // 
            this.btn_Search.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.btn_Search.Font = new System.Drawing.Font("Lucida Bright", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Search.ForeColor = System.Drawing.Color.White;
            this.btn_Search.Location = new System.Drawing.Point(923, 7);
            this.btn_Search.Name = "btn_Search";
            this.btn_Search.Size = new System.Drawing.Size(137, 50);
            this.btn_Search.TabIndex = 2;
            this.btn_Search.Text = "Search";
            this.btn_Search.UseVisualStyleBackColor = false;
            this.btn_Search.Click += new System.EventHandler(this.btn_Search_Click);
            // 
            // lbl_From
            // 
            this.lbl_From.AutoSize = true;
            this.lbl_From.BackColor = System.Drawing.Color.SeaShell;
            this.lbl_From.Font = new System.Drawing.Font("Lucida Bright", 14.25F);
            this.lbl_From.ForeColor = System.Drawing.Color.DarkRed;
            this.lbl_From.Location = new System.Drawing.Point(44, 26);
            this.lbl_From.Name = "lbl_From";
            this.lbl_From.Size = new System.Drawing.Size(107, 22);
            this.lbl_From.TabIndex = 0;
            this.lbl_From.Text = "From Date";
            // 
            // lbl_Header
            // 
            this.lbl_Header.AutoSize = true;
            this.lbl_Header.Font = new System.Drawing.Font("Lucida Bright", 27.75F, System.Drawing.FontStyle.Bold);
            this.lbl_Header.ForeColor = System.Drawing.Color.LavenderBlush;
            this.lbl_Header.Location = new System.Drawing.Point(487, 27);
            this.lbl_Header.Name = "lbl_Header";
            this.lbl_Header.Size = new System.Drawing.Size(440, 42);
            this.lbl_Header.TabIndex = 0;
            this.lbl_Header.Text = "View Customer Details";
            // 
            // pnl_View_All_Employees
            // 
            this.pnl_View_All_Employees.BackColor = System.Drawing.Color.Indigo;
            this.pnl_View_All_Employees.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pnl_View_All_Employees.Controls.Add(this.pb_Close);
            this.pnl_View_All_Employees.Controls.Add(this.pb_Back);
            this.pnl_View_All_Employees.Controls.Add(this.lbl_Header);
            this.pnl_View_All_Employees.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnl_View_All_Employees.Location = new System.Drawing.Point(0, 0);
            this.pnl_View_All_Employees.Name = "pnl_View_All_Employees";
            this.pnl_View_All_Employees.Size = new System.Drawing.Size(1344, 98);
            this.pnl_View_All_Employees.TabIndex = 9;
            // 
            // gb_Customer_Details
            // 
            this.gb_Customer_Details.Controls.Add(this.dgv_Customer_Details);
            this.gb_Customer_Details.Controls.Add(this.pnl_View_Emp);
            this.gb_Customer_Details.Font = new System.Drawing.Font("Georgia", 14.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))));
            this.gb_Customer_Details.ForeColor = System.Drawing.Color.Black;
            this.gb_Customer_Details.Location = new System.Drawing.Point(13, 104);
            this.gb_Customer_Details.Name = "gb_Customer_Details";
            this.gb_Customer_Details.Size = new System.Drawing.Size(1319, 510);
            this.gb_Customer_Details.TabIndex = 10;
            this.gb_Customer_Details.TabStop = false;
            this.gb_Customer_Details.Text = "Customer Details";
            // 
            // dgv_Customer_Details
            // 
            this.dgv_Customer_Details.AutoGenerateColumns = false;
            this.dgv_Customer_Details.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Georgia", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgv_Customer_Details.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dgv_Customer_Details.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv_Customer_Details.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.customerIDDataGridViewTextBoxColumn,
            this.productNameDataGridViewTextBoxColumn,
            this.quantityDataGridViewTextBoxColumn,
            this.gstDataGridViewTextBoxColumn,
            this.priceDataGridViewTextBoxColumn,
            this.usernameDataGridViewTextBoxColumn});
            this.dgv_Customer_Details.DataSource = this.customerBillDetailsBindingSource;
            this.dgv_Customer_Details.Location = new System.Drawing.Point(40, 138);
            this.dgv_Customer_Details.Name = "dgv_Customer_Details";
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Rockwell", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dgv_Customer_Details.RowsDefaultCellStyle = dataGridViewCellStyle2;
            this.dgv_Customer_Details.Size = new System.Drawing.Size(1234, 355);
            this.dgv_Customer_Details.TabIndex = 18;
            // 
            // customerIDDataGridViewTextBoxColumn
            // 
            this.customerIDDataGridViewTextBoxColumn.DataPropertyName = "Customer_ID";
            this.customerIDDataGridViewTextBoxColumn.HeaderText = "Customer_ID";
            this.customerIDDataGridViewTextBoxColumn.Name = "customerIDDataGridViewTextBoxColumn";
            // 
            // productNameDataGridViewTextBoxColumn
            // 
            this.productNameDataGridViewTextBoxColumn.DataPropertyName = "Product_Name";
            this.productNameDataGridViewTextBoxColumn.HeaderText = "Product_Name";
            this.productNameDataGridViewTextBoxColumn.Name = "productNameDataGridViewTextBoxColumn";
            // 
            // quantityDataGridViewTextBoxColumn
            // 
            this.quantityDataGridViewTextBoxColumn.DataPropertyName = "Quantity";
            this.quantityDataGridViewTextBoxColumn.HeaderText = "Quantity";
            this.quantityDataGridViewTextBoxColumn.Name = "quantityDataGridViewTextBoxColumn";
            // 
            // gstDataGridViewTextBoxColumn
            // 
            this.gstDataGridViewTextBoxColumn.DataPropertyName = "Gst";
            this.gstDataGridViewTextBoxColumn.HeaderText = "Gst";
            this.gstDataGridViewTextBoxColumn.Name = "gstDataGridViewTextBoxColumn";
            // 
            // priceDataGridViewTextBoxColumn
            // 
            this.priceDataGridViewTextBoxColumn.DataPropertyName = "Price";
            this.priceDataGridViewTextBoxColumn.HeaderText = "Price";
            this.priceDataGridViewTextBoxColumn.Name = "priceDataGridViewTextBoxColumn";
            // 
            // usernameDataGridViewTextBoxColumn
            // 
            this.usernameDataGridViewTextBoxColumn.DataPropertyName = "Username";
            this.usernameDataGridViewTextBoxColumn.HeaderText = "Username";
            this.usernameDataGridViewTextBoxColumn.Name = "usernameDataGridViewTextBoxColumn";
            // 
            // customerBillDetailsBindingSource
            // 
            this.customerBillDetailsBindingSource.DataMember = "Customer_Bill_Details";
            this.customerBillDetailsBindingSource.DataSource = this.computer_And_Mob_Shoppee_Mgt_Sys_DBDataSet4;
            // 
            // computer_And_Mob_Shoppee_Mgt_Sys_DBDataSet4
            // 
            this.computer_And_Mob_Shoppee_Mgt_Sys_DBDataSet4.DataSetName = "Computer_And_Mob_Shoppee_Mgt_Sys_DBDataSet4";
            this.computer_And_Mob_Shoppee_Mgt_Sys_DBDataSet4.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // employee_DetailsTableAdapter
            // 
            this.employee_DetailsTableAdapter.ClearBeforeFill = true;
            // 
            // customer_Bill_DetailsTableAdapter
            // 
            this.customer_Bill_DetailsTableAdapter.ClearBeforeFill = true;
            // 
            // frm_View_Customer_Details
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(15F, 28F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.ClientSize = new System.Drawing.Size(1344, 712);
            this.Controls.Add(this.btn_Refresh);
            this.Controls.Add(this.pnl_View_All_Employees);
            this.Controls.Add(this.gb_Customer_Details);
            this.Font = new System.Drawing.Font("Lucida Bright", 18F);
            this.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.Margin = new System.Windows.Forms.Padding(8, 6, 8, 6);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "frm_View_Customer_Details";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "View Customer Details";
            this.Load += new System.EventHandler(this.frm_View_Customer_Details_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pb_Close)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.computer_And_Mob_Shoppee_Mgt_Sys_DBDataSet1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.employeeDetailsBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_Back)).EndInit();
            this.pnl_View_Emp.ResumeLayout(false);
            this.pnl_View_Emp.PerformLayout();
            this.pnl_View_All_Employees.ResumeLayout(false);
            this.pnl_View_All_Employees.PerformLayout();
            this.gb_Customer_Details.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgv_Customer_Details)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.customerBillDetailsBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.computer_And_Mob_Shoppee_Mgt_Sys_DBDataSet4)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.PictureBox pb_Close;
        private System.Windows.Forms.Button btn_Refresh;
        private Computer_And_Mob_Shoppee_Mgt_Sys_DBDataSet1 computer_And_Mob_Shoppee_Mgt_Sys_DBDataSet1;
        private System.Windows.Forms.BindingSource employeeDetailsBindingSource;
        private System.Windows.Forms.PictureBox pb_Back;
        private System.Windows.Forms.Panel pnl_View_Emp;
        private System.Windows.Forms.Button btn_Search;
        private System.Windows.Forms.Label lbl_From;
        private System.Windows.Forms.Label lbl_Header;
        private System.Windows.Forms.Panel pnl_View_All_Employees;
        private System.Windows.Forms.GroupBox gb_Customer_Details;
        private Computer_And_Mob_Shoppee_Mgt_Sys_DBDataSet1TableAdapters.Employee_DetailsTableAdapter employee_DetailsTableAdapter;
        private System.Windows.Forms.DataGridView dgv_Customer_Details;
        private Computer_And_Mob_Shoppee_Mgt_Sys_DBDataSet4 computer_And_Mob_Shoppee_Mgt_Sys_DBDataSet4;
        private System.Windows.Forms.BindingSource customerBillDetailsBindingSource;
        private Computer_And_Mob_Shoppee_Mgt_Sys_DBDataSet4TableAdapters.Customer_Bill_DetailsTableAdapter customer_Bill_DetailsTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn customerIDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn productNameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn quantityDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn gstDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn priceDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn usernameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DateTimePicker dtp_Date;
        private System.Windows.Forms.DateTimePicker dtp_Date2;
        private System.Windows.Forms.Label lbl_To;

    }
}