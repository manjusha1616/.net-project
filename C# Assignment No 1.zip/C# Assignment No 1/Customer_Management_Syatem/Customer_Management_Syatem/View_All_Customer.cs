﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Customer_Management_Syatem
{
    class View_All_Customer
    {
        internal void Show()
        {
            throw new NotImplementedException();
        }
    }
}
