﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Student_Management_System
{    
    
    public partial class frm_Add_New_Student : Form
    {
        SqlConnection Con = new SqlConnection(@"Data Source=.\SQLEXPRESS;Initial Catalog=Student_Data_System_DB;Integrated Security=True");

        void Con_Open()
        {
            if (Con.State == ConnectionState.Closed)
            {
                Con.Open();
            }
        }

        void Con_Close()
        {
            if (Con.State == ConnectionState.Open)
            {
                Con.Close();
            }
        }


        public frm_Add_New_Student()
        {
            InitializeComponent();
        }

        private void btn_Log_Out_Click(object sender, EventArgs e)
        {
            frm_Login a = new frm_Login();
            a.Show();
            this.Hide();
        }

        private void btn_Save_Click(object sender, EventArgs e)
        {
            Con_Open();

            if (tb_Roll_No.Text != "" && tb_Name.Text != "" && tb_Mob_No.Text != "" && cb_Course.Text != "")
            {
                SqlDataAdapter sda = new SqlDataAdapter("Insert into Student_Details(Roll_No ,Name ,Mob_No ,DOB ,Course) values(" + tb_Roll_No.Text + ",'" + tb_Name.Text + "'," + tb_Mob_No.Text + ",'" + dtp_DOB.Text + "','" + cb_Course.Text + "')", Con);
                DataTable DT = new DataTable();
                sda.Fill(DT);

                MessageBox.Show("Record Saved Successfully...");

                tb_Roll_No.Text = "";
                tb_Name.Text = "";
                tb_Mob_No.Text = "";
                dtp_DOB.Text = "";
                cb_Course.SelectedIndex = 0;
            }
            else
            {
                MessageBox.Show("Please, Fill All The Fields");
            }

            Con_Close();
        }

        private void btn_Search_Student_Click(object sender, EventArgs e)
        {
            frm_Search_Student obj = new frm_Search_Student();
            obj.Show();
            this.Hide();
        }

        private void btn_View_All_Students_Click(object sender, EventArgs e)
        {
            frm_View_All_Students obj = new frm_View_All_Students();
            obj.Show();
            this.Hide();
        }

        
    }
}
