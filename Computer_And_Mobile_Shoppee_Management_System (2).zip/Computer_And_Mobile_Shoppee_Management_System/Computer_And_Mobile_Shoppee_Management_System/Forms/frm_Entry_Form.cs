﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Computer_And_Mobile_Shoppee_Management_System
{
    public partial class frm_Entry_Form : Form
    {
        public frm_Entry_Form()
        {
            InitializeComponent();
        }

        void Form_Load_Event()
        {
            btn_Uname.Text = Global_ClassFile.Uname;

            if (btn_Uname.Text == "Admin" || btn_Uname.Text == "admin")
            {
                btn_Distributor.Focus();
            }
            else if (btn_Uname.Text != "Admin" || btn_Uname.Text != "admin")
            {
                pb_Distributor.Hide();
                pb_Employees.Hide();
                btn_Distributor.Hide();
                btn_Employee.Hide();
                pb_Customers.Location = new Point(137, 193);
                pb_Customers.Size = new Size(315, 240);
                pb_Product.Location = new Point(637, 193);
                pb_Product.Size = new Size(315, 240);
                btn_Customers.Size = new Size(314, 44);
                btn_Products.Location = new Point(637, 443);
                btn_Customers.Location = new Point(137, 443);
                btn_Products.Size = new Size(314, 44);
            }
        }

        private void frm_Entry_Form_Load(object sender, EventArgs e)
        {
            Form_Load_Event();
        }

        private void btn_Distributor_Click(object sender, EventArgs e)
        {
            frm_Distributor_Entry_Form obj = new frm_Distributor_Entry_Form();

            obj.WindowState = FormWindowState.Maximized;
            this.Hide();
            obj.Show();
        }

        private void btn_Employee_Click(object sender, EventArgs e)
        {
            frm_Employee_Entry_Form obj = new frm_Employee_Entry_Form();

            obj.WindowState = FormWindowState.Maximized;
            this.Hide();
            obj.Show();
        }

        private void btn_Customers_Click(object sender, EventArgs e)
        {
            frm_Customer_Entry_Form obj = new frm_Customer_Entry_Form();

            obj.WindowState = FormWindowState.Maximized;
            this.Hide();
            obj.Show();
        }

        private void btn_Products_Click(object sender, EventArgs e)
        {
            frm_Product_Entry_Form obj = new frm_Product_Entry_Form();

            obj.WindowState = FormWindowState.Maximized;
            this.Hide();
            obj.Show();
        }

        private void pb_Close_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show("Do You Want To Close This Appllication?", "close Application", MessageBoxButtons.YesNo);

            if (result == DialogResult.Yes)
            {
                frm_Login obj = new frm_Login();
                this.Hide();
                obj.Show();
            }
            else
            {
                this.Show();
            }
        }
    }
}
