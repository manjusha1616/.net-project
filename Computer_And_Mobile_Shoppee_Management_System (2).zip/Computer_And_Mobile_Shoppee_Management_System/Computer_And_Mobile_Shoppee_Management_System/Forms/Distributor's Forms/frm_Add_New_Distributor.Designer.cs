﻿namespace Computer_And_Mobile_Shoppee_Management_System
{
    partial class frm_Add_New_Distributor
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frm_Add_New_Distributor));
            this.gb_Gender = new System.Windows.Forms.GroupBox();
            this.rb_Female = new System.Windows.Forms.RadioButton();
            this.rb_Male = new System.Windows.Forms.RadioButton();
            this.pnl_Add_New_Distributor = new System.Windows.Forms.Panel();
            this.pb_Close = new System.Windows.Forms.PictureBox();
            this.pb_Back = new System.Windows.Forms.PictureBox();
            this.lbl_Add_New_Distributor = new System.Windows.Forms.Label();
            this.tb_Pan_No = new System.Windows.Forms.TextBox();
            this.tb_Mob_No2 = new System.Windows.Forms.TextBox();
            this.tb_Mob_No1 = new System.Windows.Forms.TextBox();
            this.tb_Registration_No = new System.Windows.Forms.TextBox();
            this.dtp_Tie_Up_Date = new System.Windows.Forms.DateTimePicker();
            this.tb_Aadhar_No = new System.Windows.Forms.TextBox();
            this.btn_Refresh = new System.Windows.Forms.Button();
            this.tb_Email_ID = new System.Windows.Forms.TextBox();
            this.tb_Address = new System.Windows.Forms.TextBox();
            this.tb_Distributor_Name = new System.Windows.Forms.TextBox();
            this.tb_Distributor_ID = new System.Windows.Forms.TextBox();
            this.lbl_Gender = new System.Windows.Forms.Label();
            this.lbl_Pan_No = new System.Windows.Forms.Label();
            this.lbl_Aadhar_Card_No = new System.Windows.Forms.Label();
            this.lbl_Mob_No2 = new System.Windows.Forms.Label();
            this.lbl_Tie_Up_Date = new System.Windows.Forms.Label();
            this.lbl_Email_ID = new System.Windows.Forms.Label();
            this.lbl_Mob_No1 = new System.Windows.Forms.Label();
            this.lbl_Brand_Delivered = new System.Windows.Forms.Label();
            this.gb_Distributor_Details = new System.Windows.Forms.GroupBox();
            this.pnl_Brand_Delivered = new System.Windows.Forms.Panel();
            this.cb_Other_Accessories = new System.Windows.Forms.CheckBox();
            this.cb_Laptop = new System.Windows.Forms.CheckBox();
            this.cb_Desktop_Computer = new System.Windows.Forms.CheckBox();
            this.cb_Mobile = new System.Windows.Forms.CheckBox();
            this.lbl_Registration_No = new System.Windows.Forms.Label();
            this.lbl_Address = new System.Windows.Forms.Label();
            this.lbl_Distributor_Name = new System.Windows.Forms.Label();
            this.lbl_Distributor_ID = new System.Windows.Forms.Label();
            this.btn_Save = new System.Windows.Forms.Button();
            this.gb_Gender.SuspendLayout();
            this.pnl_Add_New_Distributor.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pb_Close)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_Back)).BeginInit();
            this.gb_Distributor_Details.SuspendLayout();
            this.pnl_Brand_Delivered.SuspendLayout();
            this.SuspendLayout();
            // 
            // gb_Gender
            // 
            this.gb_Gender.BackColor = System.Drawing.SystemColors.Window;
            this.gb_Gender.Controls.Add(this.rb_Female);
            this.gb_Gender.Controls.Add(this.rb_Male);
            this.gb_Gender.Font = new System.Drawing.Font("Lucida Bright", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gb_Gender.Location = new System.Drawing.Point(332, 269);
            this.gb_Gender.Margin = new System.Windows.Forms.Padding(2);
            this.gb_Gender.Name = "gb_Gender";
            this.gb_Gender.Padding = new System.Windows.Forms.Padding(2);
            this.gb_Gender.Size = new System.Drawing.Size(255, 30);
            this.gb_Gender.TabIndex = 3;
            this.gb_Gender.TabStop = false;
            // 
            // rb_Female
            // 
            this.rb_Female.AutoSize = true;
            this.rb_Female.Font = new System.Drawing.Font("Lucida Bright", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rb_Female.Location = new System.Drawing.Point(142, 2);
            this.rb_Female.Margin = new System.Windows.Forms.Padding(2);
            this.rb_Female.Name = "rb_Female";
            this.rb_Female.Size = new System.Drawing.Size(81, 24);
            this.rb_Female.TabIndex = 0;
            this.rb_Female.TabStop = true;
            this.rb_Female.Text = "Female";
            this.rb_Female.UseVisualStyleBackColor = true;
            // 
            // rb_Male
            // 
            this.rb_Male.AutoSize = true;
            this.rb_Male.Font = new System.Drawing.Font("Lucida Bright", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rb_Male.Location = new System.Drawing.Point(30, 2);
            this.rb_Male.Margin = new System.Windows.Forms.Padding(2);
            this.rb_Male.Name = "rb_Male";
            this.rb_Male.Size = new System.Drawing.Size(64, 24);
            this.rb_Male.TabIndex = 0;
            this.rb_Male.TabStop = true;
            this.rb_Male.Text = "Male";
            this.rb_Male.UseVisualStyleBackColor = true;
            // 
            // pnl_Add_New_Distributor
            // 
            this.pnl_Add_New_Distributor.BackColor = System.Drawing.Color.Indigo;
            this.pnl_Add_New_Distributor.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pnl_Add_New_Distributor.Controls.Add(this.pb_Close);
            this.pnl_Add_New_Distributor.Controls.Add(this.pb_Back);
            this.pnl_Add_New_Distributor.Controls.Add(this.lbl_Add_New_Distributor);
            this.pnl_Add_New_Distributor.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnl_Add_New_Distributor.Location = new System.Drawing.Point(0, 0);
            this.pnl_Add_New_Distributor.Margin = new System.Windows.Forms.Padding(2);
            this.pnl_Add_New_Distributor.Name = "pnl_Add_New_Distributor";
            this.pnl_Add_New_Distributor.Size = new System.Drawing.Size(1345, 99);
            this.pnl_Add_New_Distributor.TabIndex = 13;
            // 
            // pb_Close
            // 
            this.pb_Close.Image = ((System.Drawing.Image)(resources.GetObject("pb_Close.Image")));
            this.pb_Close.Location = new System.Drawing.Point(1232, 22);
            this.pb_Close.Margin = new System.Windows.Forms.Padding(2);
            this.pb_Close.Name = "pb_Close";
            this.pb_Close.Size = new System.Drawing.Size(105, 56);
            this.pb_Close.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pb_Close.TabIndex = 4;
            this.pb_Close.TabStop = false;
            this.pb_Close.Click += new System.EventHandler(this.pb_Close_Click);
            // 
            // pb_Back
            // 
            this.pb_Back.Image = ((System.Drawing.Image)(resources.GetObject("pb_Back.Image")));
            this.pb_Back.Location = new System.Drawing.Point(12, 22);
            this.pb_Back.Margin = new System.Windows.Forms.Padding(2);
            this.pb_Back.Name = "pb_Back";
            this.pb_Back.Size = new System.Drawing.Size(100, 50);
            this.pb_Back.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pb_Back.TabIndex = 3;
            this.pb_Back.TabStop = false;
            this.pb_Back.Click += new System.EventHandler(this.pb_Back_Click);
            // 
            // lbl_Add_New_Distributor
            // 
            this.lbl_Add_New_Distributor.AutoSize = true;
            this.lbl_Add_New_Distributor.BackColor = System.Drawing.Color.Indigo;
            this.lbl_Add_New_Distributor.Font = new System.Drawing.Font("Lucida Bright", 27.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Add_New_Distributor.ForeColor = System.Drawing.Color.LavenderBlush;
            this.lbl_Add_New_Distributor.Location = new System.Drawing.Point(495, 28);
            this.lbl_Add_New_Distributor.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lbl_Add_New_Distributor.Name = "lbl_Add_New_Distributor";
            this.lbl_Add_New_Distributor.Size = new System.Drawing.Size(406, 42);
            this.lbl_Add_New_Distributor.TabIndex = 0;
            this.lbl_Add_New_Distributor.Text = "Add New Distributor";
            // 
            // tb_Pan_No
            // 
            this.tb_Pan_No.Font = new System.Drawing.Font("Lucida Bright", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_Pan_No.Location = new System.Drawing.Point(1012, 261);
            this.tb_Pan_No.Margin = new System.Windows.Forms.Padding(2, 4, 2, 4);
            this.tb_Pan_No.MaxLength = 10;
            this.tb_Pan_No.Name = "tb_Pan_No";
            this.tb_Pan_No.Size = new System.Drawing.Size(254, 30);
            this.tb_Pan_No.TabIndex = 9;
            // 
            // tb_Mob_No2
            // 
            this.tb_Mob_No2.Font = new System.Drawing.Font("Lucida Bright", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_Mob_No2.Location = new System.Drawing.Point(332, 420);
            this.tb_Mob_No2.Margin = new System.Windows.Forms.Padding(2, 4, 2, 4);
            this.tb_Mob_No2.MaxLength = 10;
            this.tb_Mob_No2.Name = "tb_Mob_No2";
            this.tb_Mob_No2.Size = new System.Drawing.Size(254, 30);
            this.tb_Mob_No2.TabIndex = 5;
            this.tb_Mob_No2.TextChanged += new System.EventHandler(this.tb_Mob_No2_TextChanged);
            this.tb_Mob_No2.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tb_Mob_No2_KeyPress);
            // 
            // tb_Mob_No1
            // 
            this.tb_Mob_No1.Font = new System.Drawing.Font("Lucida Bright", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_Mob_No1.Location = new System.Drawing.Point(332, 349);
            this.tb_Mob_No1.Margin = new System.Windows.Forms.Padding(2, 4, 2, 4);
            this.tb_Mob_No1.MaxLength = 10;
            this.tb_Mob_No1.Name = "tb_Mob_No1";
            this.tb_Mob_No1.Size = new System.Drawing.Size(254, 30);
            this.tb_Mob_No1.TabIndex = 4;
            this.tb_Mob_No1.TextChanged += new System.EventHandler(this.tb_Mob_No1_TextChanged);
            this.tb_Mob_No1.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tb_Mob_No1_KeyPress);
            // 
            // tb_Registration_No
            // 
            this.tb_Registration_No.Font = new System.Drawing.Font("Lucida Bright", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_Registration_No.Location = new System.Drawing.Point(1012, 114);
            this.tb_Registration_No.Margin = new System.Windows.Forms.Padding(2, 4, 2, 4);
            this.tb_Registration_No.MaxLength = 5;
            this.tb_Registration_No.Name = "tb_Registration_No";
            this.tb_Registration_No.Size = new System.Drawing.Size(254, 30);
            this.tb_Registration_No.TabIndex = 7;
            this.tb_Registration_No.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tb_Registration_No_KeyPress);
            // 
            // dtp_Tie_Up_Date
            // 
            this.dtp_Tie_Up_Date.Font = new System.Drawing.Font("Lucida Bright", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtp_Tie_Up_Date.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtp_Tie_Up_Date.Location = new System.Drawing.Point(1012, 52);
            this.dtp_Tie_Up_Date.Margin = new System.Windows.Forms.Padding(2, 4, 2, 4);
            this.dtp_Tie_Up_Date.Name = "dtp_Tie_Up_Date";
            this.dtp_Tie_Up_Date.Size = new System.Drawing.Size(254, 30);
            this.dtp_Tie_Up_Date.TabIndex = 6;
            // 
            // tb_Aadhar_No
            // 
            this.tb_Aadhar_No.Font = new System.Drawing.Font("Lucida Bright", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_Aadhar_No.Location = new System.Drawing.Point(1012, 190);
            this.tb_Aadhar_No.Margin = new System.Windows.Forms.Padding(2, 4, 2, 4);
            this.tb_Aadhar_No.MaxLength = 12;
            this.tb_Aadhar_No.Name = "tb_Aadhar_No";
            this.tb_Aadhar_No.Size = new System.Drawing.Size(254, 30);
            this.tb_Aadhar_No.TabIndex = 8;
            this.tb_Aadhar_No.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tb_Aadhar_No_KeyPress);
            // 
            // btn_Refresh
            // 
            this.btn_Refresh.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.btn_Refresh.Font = new System.Drawing.Font("Lucida Bright", 27.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Refresh.ForeColor = System.Drawing.Color.White;
            this.btn_Refresh.Location = new System.Drawing.Point(850, 633);
            this.btn_Refresh.Margin = new System.Windows.Forms.Padding(2);
            this.btn_Refresh.Name = "btn_Refresh";
            this.btn_Refresh.Size = new System.Drawing.Size(170, 54);
            this.btn_Refresh.TabIndex = 13;
            this.btn_Refresh.Text = "Refresh";
            this.btn_Refresh.UseVisualStyleBackColor = false;
            this.btn_Refresh.Click += new System.EventHandler(this.btn_Refresh_Click);
            // 
            // tb_Email_ID
            // 
            this.tb_Email_ID.Font = new System.Drawing.Font("Lucida Bright", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_Email_ID.Location = new System.Drawing.Point(1012, 336);
            this.tb_Email_ID.Margin = new System.Windows.Forms.Padding(2, 4, 2, 4);
            this.tb_Email_ID.Name = "tb_Email_ID";
            this.tb_Email_ID.Size = new System.Drawing.Size(254, 30);
            this.tb_Email_ID.TabIndex = 10;
            // 
            // tb_Address
            // 
            this.tb_Address.Font = new System.Drawing.Font("Lucida Bright", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_Address.Location = new System.Drawing.Point(332, 192);
            this.tb_Address.Margin = new System.Windows.Forms.Padding(2, 4, 2, 4);
            this.tb_Address.Name = "tb_Address";
            this.tb_Address.Size = new System.Drawing.Size(254, 30);
            this.tb_Address.TabIndex = 2;
            // 
            // tb_Distributor_Name
            // 
            this.tb_Distributor_Name.Font = new System.Drawing.Font("Lucida Bright", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_Distributor_Name.Location = new System.Drawing.Point(332, 121);
            this.tb_Distributor_Name.Margin = new System.Windows.Forms.Padding(2, 4, 2, 4);
            this.tb_Distributor_Name.Name = "tb_Distributor_Name";
            this.tb_Distributor_Name.Size = new System.Drawing.Size(254, 30);
            this.tb_Distributor_Name.TabIndex = 1;
            // 
            // tb_Distributor_ID
            // 
            this.tb_Distributor_ID.Enabled = false;
            this.tb_Distributor_ID.Font = new System.Drawing.Font("Lucida Bright", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_Distributor_ID.Location = new System.Drawing.Point(332, 52);
            this.tb_Distributor_ID.Margin = new System.Windows.Forms.Padding(2, 4, 2, 4);
            this.tb_Distributor_ID.Name = "tb_Distributor_ID";
            this.tb_Distributor_ID.Size = new System.Drawing.Size(254, 30);
            this.tb_Distributor_ID.TabIndex = 0;
            // 
            // lbl_Gender
            // 
            this.lbl_Gender.AutoSize = true;
            this.lbl_Gender.BackColor = System.Drawing.Color.SeaShell;
            this.lbl_Gender.Font = new System.Drawing.Font("Lucida Bright", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Gender.ForeColor = System.Drawing.Color.DarkRed;
            this.lbl_Gender.Location = new System.Drawing.Point(52, 269);
            this.lbl_Gender.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lbl_Gender.Name = "lbl_Gender";
            this.lbl_Gender.Size = new System.Drawing.Size(77, 22);
            this.lbl_Gender.TabIndex = 49;
            this.lbl_Gender.Text = "Gender";
            // 
            // lbl_Pan_No
            // 
            this.lbl_Pan_No.AutoSize = true;
            this.lbl_Pan_No.BackColor = System.Drawing.Color.SeaShell;
            this.lbl_Pan_No.Font = new System.Drawing.Font("Lucida Bright", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Pan_No.ForeColor = System.Drawing.Color.DarkRed;
            this.lbl_Pan_No.Location = new System.Drawing.Point(755, 267);
            this.lbl_Pan_No.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lbl_Pan_No.Name = "lbl_Pan_No";
            this.lbl_Pan_No.Size = new System.Drawing.Size(126, 22);
            this.lbl_Pan_No.TabIndex = 48;
            this.lbl_Pan_No.Text = "Pan Card No";
            // 
            // lbl_Aadhar_Card_No
            // 
            this.lbl_Aadhar_Card_No.AutoSize = true;
            this.lbl_Aadhar_Card_No.BackColor = System.Drawing.Color.SeaShell;
            this.lbl_Aadhar_Card_No.Font = new System.Drawing.Font("Lucida Bright", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Aadhar_Card_No.ForeColor = System.Drawing.Color.DarkRed;
            this.lbl_Aadhar_Card_No.Location = new System.Drawing.Point(755, 196);
            this.lbl_Aadhar_Card_No.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lbl_Aadhar_Card_No.Name = "lbl_Aadhar_Card_No";
            this.lbl_Aadhar_Card_No.Size = new System.Drawing.Size(162, 22);
            this.lbl_Aadhar_Card_No.TabIndex = 47;
            this.lbl_Aadhar_Card_No.Text = "Aadhar Card No";
            // 
            // lbl_Mob_No2
            // 
            this.lbl_Mob_No2.AutoSize = true;
            this.lbl_Mob_No2.BackColor = System.Drawing.Color.SeaShell;
            this.lbl_Mob_No2.Font = new System.Drawing.Font("Lucida Bright", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Mob_No2.ForeColor = System.Drawing.Color.DarkRed;
            this.lbl_Mob_No2.Location = new System.Drawing.Point(52, 429);
            this.lbl_Mob_No2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lbl_Mob_No2.Name = "lbl_Mob_No2";
            this.lbl_Mob_No2.Size = new System.Drawing.Size(121, 22);
            this.lbl_Mob_No2.TabIndex = 46;
            this.lbl_Mob_No2.Text = "Mobile No 2";
            // 
            // lbl_Tie_Up_Date
            // 
            this.lbl_Tie_Up_Date.AutoSize = true;
            this.lbl_Tie_Up_Date.BackColor = System.Drawing.Color.SeaShell;
            this.lbl_Tie_Up_Date.Font = new System.Drawing.Font("Lucida Bright", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Tie_Up_Date.ForeColor = System.Drawing.Color.DarkRed;
            this.lbl_Tie_Up_Date.Location = new System.Drawing.Point(750, 52);
            this.lbl_Tie_Up_Date.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lbl_Tie_Up_Date.Name = "lbl_Tie_Up_Date";
            this.lbl_Tie_Up_Date.Size = new System.Drawing.Size(119, 22);
            this.lbl_Tie_Up_Date.TabIndex = 44;
            this.lbl_Tie_Up_Date.Text = "Tie-Up Date";
            // 
            // lbl_Email_ID
            // 
            this.lbl_Email_ID.AutoSize = true;
            this.lbl_Email_ID.BackColor = System.Drawing.Color.SeaShell;
            this.lbl_Email_ID.Font = new System.Drawing.Font("Lucida Bright", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Email_ID.ForeColor = System.Drawing.Color.DarkRed;
            this.lbl_Email_ID.Location = new System.Drawing.Point(755, 342);
            this.lbl_Email_ID.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lbl_Email_ID.Name = "lbl_Email_ID";
            this.lbl_Email_ID.Size = new System.Drawing.Size(88, 22);
            this.lbl_Email_ID.TabIndex = 43;
            this.lbl_Email_ID.Text = "Email ID";
            // 
            // lbl_Mob_No1
            // 
            this.lbl_Mob_No1.AutoSize = true;
            this.lbl_Mob_No1.BackColor = System.Drawing.Color.SeaShell;
            this.lbl_Mob_No1.Font = new System.Drawing.Font("Lucida Bright", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Mob_No1.ForeColor = System.Drawing.Color.DarkRed;
            this.lbl_Mob_No1.Location = new System.Drawing.Point(52, 355);
            this.lbl_Mob_No1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lbl_Mob_No1.Name = "lbl_Mob_No1";
            this.lbl_Mob_No1.Size = new System.Drawing.Size(121, 22);
            this.lbl_Mob_No1.TabIndex = 45;
            this.lbl_Mob_No1.Text = "Mobile No 1";
            // 
            // lbl_Brand_Delivered
            // 
            this.lbl_Brand_Delivered.AutoSize = true;
            this.lbl_Brand_Delivered.BackColor = System.Drawing.Color.SeaShell;
            this.lbl_Brand_Delivered.Font = new System.Drawing.Font("Lucida Bright", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Brand_Delivered.ForeColor = System.Drawing.Color.DarkRed;
            this.lbl_Brand_Delivered.Location = new System.Drawing.Point(755, 420);
            this.lbl_Brand_Delivered.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lbl_Brand_Delivered.Name = "lbl_Brand_Delivered";
            this.lbl_Brand_Delivered.Size = new System.Drawing.Size(158, 22);
            this.lbl_Brand_Delivered.TabIndex = 42;
            this.lbl_Brand_Delivered.Text = "Brand Delivered";
            // 
            // gb_Distributor_Details
            // 
            this.gb_Distributor_Details.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.gb_Distributor_Details.Controls.Add(this.pnl_Brand_Delivered);
            this.gb_Distributor_Details.Controls.Add(this.gb_Gender);
            this.gb_Distributor_Details.Controls.Add(this.tb_Pan_No);
            this.gb_Distributor_Details.Controls.Add(this.tb_Mob_No2);
            this.gb_Distributor_Details.Controls.Add(this.tb_Mob_No1);
            this.gb_Distributor_Details.Controls.Add(this.tb_Registration_No);
            this.gb_Distributor_Details.Controls.Add(this.dtp_Tie_Up_Date);
            this.gb_Distributor_Details.Controls.Add(this.tb_Aadhar_No);
            this.gb_Distributor_Details.Controls.Add(this.tb_Email_ID);
            this.gb_Distributor_Details.Controls.Add(this.tb_Address);
            this.gb_Distributor_Details.Controls.Add(this.tb_Distributor_Name);
            this.gb_Distributor_Details.Controls.Add(this.tb_Distributor_ID);
            this.gb_Distributor_Details.Controls.Add(this.lbl_Gender);
            this.gb_Distributor_Details.Controls.Add(this.lbl_Pan_No);
            this.gb_Distributor_Details.Controls.Add(this.lbl_Aadhar_Card_No);
            this.gb_Distributor_Details.Controls.Add(this.lbl_Mob_No2);
            this.gb_Distributor_Details.Controls.Add(this.lbl_Mob_No1);
            this.gb_Distributor_Details.Controls.Add(this.lbl_Tie_Up_Date);
            this.gb_Distributor_Details.Controls.Add(this.lbl_Email_ID);
            this.gb_Distributor_Details.Controls.Add(this.lbl_Brand_Delivered);
            this.gb_Distributor_Details.Controls.Add(this.lbl_Registration_No);
            this.gb_Distributor_Details.Controls.Add(this.lbl_Address);
            this.gb_Distributor_Details.Controls.Add(this.lbl_Distributor_Name);
            this.gb_Distributor_Details.Controls.Add(this.lbl_Distributor_ID);
            this.gb_Distributor_Details.Font = new System.Drawing.Font("Georgia", 14.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))));
            this.gb_Distributor_Details.ForeColor = System.Drawing.Color.Black;
            this.gb_Distributor_Details.Location = new System.Drawing.Point(12, 103);
            this.gb_Distributor_Details.Margin = new System.Windows.Forms.Padding(2);
            this.gb_Distributor_Details.Name = "gb_Distributor_Details";
            this.gb_Distributor_Details.Padding = new System.Windows.Forms.Padding(2);
            this.gb_Distributor_Details.Size = new System.Drawing.Size(1320, 508);
            this.gb_Distributor_Details.TabIndex = 14;
            this.gb_Distributor_Details.TabStop = false;
            this.gb_Distributor_Details.Text = "Distributor Details";
            // 
            // pnl_Brand_Delivered
            // 
            this.pnl_Brand_Delivered.AutoScroll = true;
            this.pnl_Brand_Delivered.BackColor = System.Drawing.SystemColors.Window;
            this.pnl_Brand_Delivered.Controls.Add(this.cb_Other_Accessories);
            this.pnl_Brand_Delivered.Controls.Add(this.cb_Laptop);
            this.pnl_Brand_Delivered.Controls.Add(this.cb_Desktop_Computer);
            this.pnl_Brand_Delivered.Controls.Add(this.cb_Mobile);
            this.pnl_Brand_Delivered.Location = new System.Drawing.Point(1012, 402);
            this.pnl_Brand_Delivered.Margin = new System.Windows.Forms.Padding(2);
            this.pnl_Brand_Delivered.Name = "pnl_Brand_Delivered";
            this.pnl_Brand_Delivered.Size = new System.Drawing.Size(255, 87);
            this.pnl_Brand_Delivered.TabIndex = 50;
            // 
            // cb_Other_Accessories
            // 
            this.cb_Other_Accessories.AutoSize = true;
            this.cb_Other_Accessories.Font = new System.Drawing.Font("Georgia", 9.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cb_Other_Accessories.Location = new System.Drawing.Point(2, 67);
            this.cb_Other_Accessories.Margin = new System.Windows.Forms.Padding(2);
            this.cb_Other_Accessories.Name = "cb_Other_Accessories";
            this.cb_Other_Accessories.Size = new System.Drawing.Size(157, 20);
            this.cb_Other_Accessories.TabIndex = 3;
            this.cb_Other_Accessories.Text = "Other Accessories";
            this.cb_Other_Accessories.UseVisualStyleBackColor = true;
            // 
            // cb_Laptop
            // 
            this.cb_Laptop.AutoSize = true;
            this.cb_Laptop.Font = new System.Drawing.Font("Georgia", 9.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cb_Laptop.Location = new System.Drawing.Point(2, 47);
            this.cb_Laptop.Margin = new System.Windows.Forms.Padding(2);
            this.cb_Laptop.Name = "cb_Laptop";
            this.cb_Laptop.Size = new System.Drawing.Size(78, 20);
            this.cb_Laptop.TabIndex = 2;
            this.cb_Laptop.Text = "Laptop";
            this.cb_Laptop.UseVisualStyleBackColor = true;
            // 
            // cb_Desktop_Computer
            // 
            this.cb_Desktop_Computer.AutoSize = true;
            this.cb_Desktop_Computer.Font = new System.Drawing.Font("Georgia", 9.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cb_Desktop_Computer.Location = new System.Drawing.Point(0, 23);
            this.cb_Desktop_Computer.Margin = new System.Windows.Forms.Padding(2);
            this.cb_Desktop_Computer.Name = "cb_Desktop_Computer";
            this.cb_Desktop_Computer.Size = new System.Drawing.Size(162, 20);
            this.cb_Desktop_Computer.TabIndex = 1;
            this.cb_Desktop_Computer.Text = "Desktop Computer";
            this.cb_Desktop_Computer.UseVisualStyleBackColor = true;
            // 
            // cb_Mobile
            // 
            this.cb_Mobile.AutoSize = true;
            this.cb_Mobile.Font = new System.Drawing.Font("Georgia", 9.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cb_Mobile.Location = new System.Drawing.Point(2, 2);
            this.cb_Mobile.Margin = new System.Windows.Forms.Padding(2);
            this.cb_Mobile.Name = "cb_Mobile";
            this.cb_Mobile.Size = new System.Drawing.Size(76, 20);
            this.cb_Mobile.TabIndex = 0;
            this.cb_Mobile.Text = "Mobile";
            this.cb_Mobile.UseVisualStyleBackColor = true;
            // 
            // lbl_Registration_No
            // 
            this.lbl_Registration_No.AutoSize = true;
            this.lbl_Registration_No.BackColor = System.Drawing.Color.SeaShell;
            this.lbl_Registration_No.Font = new System.Drawing.Font("Lucida Bright", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Registration_No.ForeColor = System.Drawing.Color.DarkRed;
            this.lbl_Registration_No.Location = new System.Drawing.Point(750, 123);
            this.lbl_Registration_No.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lbl_Registration_No.Name = "lbl_Registration_No";
            this.lbl_Registration_No.Size = new System.Drawing.Size(155, 22);
            this.lbl_Registration_No.TabIndex = 41;
            this.lbl_Registration_No.Text = "Registration No";
            // 
            // lbl_Address
            // 
            this.lbl_Address.AutoSize = true;
            this.lbl_Address.BackColor = System.Drawing.Color.SeaShell;
            this.lbl_Address.Font = new System.Drawing.Font("Lucida Bright", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Address.ForeColor = System.Drawing.Color.DarkRed;
            this.lbl_Address.Location = new System.Drawing.Point(52, 192);
            this.lbl_Address.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lbl_Address.Name = "lbl_Address";
            this.lbl_Address.Size = new System.Drawing.Size(85, 22);
            this.lbl_Address.TabIndex = 40;
            this.lbl_Address.Text = "Address";
            // 
            // lbl_Distributor_Name
            // 
            this.lbl_Distributor_Name.AutoSize = true;
            this.lbl_Distributor_Name.BackColor = System.Drawing.Color.SeaShell;
            this.lbl_Distributor_Name.Font = new System.Drawing.Font("Lucida Bright", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Distributor_Name.ForeColor = System.Drawing.Color.DarkRed;
            this.lbl_Distributor_Name.Location = new System.Drawing.Point(50, 125);
            this.lbl_Distributor_Name.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lbl_Distributor_Name.Name = "lbl_Distributor_Name";
            this.lbl_Distributor_Name.Size = new System.Drawing.Size(171, 22);
            this.lbl_Distributor_Name.TabIndex = 39;
            this.lbl_Distributor_Name.Text = "Distributor Name";
            // 
            // lbl_Distributor_ID
            // 
            this.lbl_Distributor_ID.AutoSize = true;
            this.lbl_Distributor_ID.BackColor = System.Drawing.Color.SeaShell;
            this.lbl_Distributor_ID.Font = new System.Drawing.Font("Lucida Bright", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Distributor_ID.ForeColor = System.Drawing.Color.DarkRed;
            this.lbl_Distributor_ID.Location = new System.Drawing.Point(52, 58);
            this.lbl_Distributor_ID.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lbl_Distributor_ID.Name = "lbl_Distributor_ID";
            this.lbl_Distributor_ID.Size = new System.Drawing.Size(138, 22);
            this.lbl_Distributor_ID.TabIndex = 38;
            this.lbl_Distributor_ID.Text = "Distributor ID";
            // 
            // btn_Save
            // 
            this.btn_Save.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.btn_Save.Font = new System.Drawing.Font("Lucida Bright", 27.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Save.ForeColor = System.Drawing.Color.White;
            this.btn_Save.Location = new System.Drawing.Point(375, 633);
            this.btn_Save.Margin = new System.Windows.Forms.Padding(2);
            this.btn_Save.Name = "btn_Save";
            this.btn_Save.Size = new System.Drawing.Size(128, 54);
            this.btn_Save.TabIndex = 12;
            this.btn_Save.Text = "Save";
            this.btn_Save.UseVisualStyleBackColor = false;
            this.btn_Save.Click += new System.EventHandler(this.btn_Save_Click);
            // 
            // frm_Add_New_Distributor
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(15F, 28F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.ClientSize = new System.Drawing.Size(1345, 713);
            this.Controls.Add(this.pnl_Add_New_Distributor);
            this.Controls.Add(this.btn_Refresh);
            this.Controls.Add(this.gb_Distributor_Details);
            this.Controls.Add(this.btn_Save);
            this.Font = new System.Drawing.Font("Lucida Bright", 18F);
            this.Margin = new System.Windows.Forms.Padding(8, 6, 8, 6);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "frm_Add_New_Distributor";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Add New Distributor";
            this.Load += new System.EventHandler(this.frm_Add_New_Distributor_Load);
            this.gb_Gender.ResumeLayout(false);
            this.gb_Gender.PerformLayout();
            this.pnl_Add_New_Distributor.ResumeLayout(false);
            this.pnl_Add_New_Distributor.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pb_Close)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_Back)).EndInit();
            this.gb_Distributor_Details.ResumeLayout(false);
            this.gb_Distributor_Details.PerformLayout();
            this.pnl_Brand_Delivered.ResumeLayout(false);
            this.pnl_Brand_Delivered.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox gb_Gender;
        private System.Windows.Forms.RadioButton rb_Female;
        private System.Windows.Forms.RadioButton rb_Male;
        private System.Windows.Forms.Panel pnl_Add_New_Distributor;
        private System.Windows.Forms.PictureBox pb_Close;
        private System.Windows.Forms.PictureBox pb_Back;
        private System.Windows.Forms.Label lbl_Add_New_Distributor;
        private System.Windows.Forms.TextBox tb_Pan_No;
        private System.Windows.Forms.TextBox tb_Mob_No2;
        private System.Windows.Forms.TextBox tb_Mob_No1;
        private System.Windows.Forms.TextBox tb_Registration_No;
        private System.Windows.Forms.DateTimePicker dtp_Tie_Up_Date;
        private System.Windows.Forms.TextBox tb_Aadhar_No;
        private System.Windows.Forms.Button btn_Refresh;
        private System.Windows.Forms.TextBox tb_Email_ID;
        private System.Windows.Forms.TextBox tb_Address;
        private System.Windows.Forms.TextBox tb_Distributor_Name;
        private System.Windows.Forms.TextBox tb_Distributor_ID;
        private System.Windows.Forms.Label lbl_Gender;
        private System.Windows.Forms.Label lbl_Pan_No;
        private System.Windows.Forms.Label lbl_Aadhar_Card_No;
        private System.Windows.Forms.Label lbl_Mob_No2;
        private System.Windows.Forms.Label lbl_Tie_Up_Date;
        private System.Windows.Forms.Label lbl_Email_ID;
        private System.Windows.Forms.Label lbl_Mob_No1;
        private System.Windows.Forms.Label lbl_Brand_Delivered;
        private System.Windows.Forms.GroupBox gb_Distributor_Details;
        private System.Windows.Forms.Label lbl_Registration_No;
        private System.Windows.Forms.Label lbl_Address;
        private System.Windows.Forms.Label lbl_Distributor_Name;
        private System.Windows.Forms.Label lbl_Distributor_ID;
        private System.Windows.Forms.Button btn_Save;
        private System.Windows.Forms.Panel pnl_Brand_Delivered;
        private System.Windows.Forms.CheckBox cb_Mobile;
        private System.Windows.Forms.CheckBox cb_Other_Accessories;
        private System.Windows.Forms.CheckBox cb_Laptop;
        private System.Windows.Forms.CheckBox cb_Desktop_Computer;
    }
}