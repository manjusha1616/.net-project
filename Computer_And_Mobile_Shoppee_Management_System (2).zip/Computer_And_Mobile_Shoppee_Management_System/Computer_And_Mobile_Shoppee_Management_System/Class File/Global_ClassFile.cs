﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;

namespace Computer_And_Mobile_Shoppee_Management_System
{
    class Global_ClassFile
    {
        public static string Uname = "";

        string Connectionstring = (@"Data Source=.\SQLEXPRESS;Initial Catalog=Computer_And_Mob_Shoppee_Mgt_Sys_DB;Integrated Security=True");

        public SqlConnection Con;

        public void ConnectDB()
        {
            Con = new SqlConnection(Connectionstring);

            if (Con.State == System.Data.ConnectionState.Closed)
            {
                Con.Open();
            }
        }

        public void DisconnectDB()
        {
            if (Con.State == System.Data.ConnectionState.Open)
            {
                Con.Close();
            }
        }      
    }
}
