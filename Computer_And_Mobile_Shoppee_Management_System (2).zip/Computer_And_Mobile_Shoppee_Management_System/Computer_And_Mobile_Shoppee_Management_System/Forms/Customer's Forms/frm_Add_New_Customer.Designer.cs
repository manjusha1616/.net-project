﻿namespace Computer_And_Mobile_Shoppee_Management_System
{
    partial class frm_Add_New_Customer
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frm_Add_New_Customer));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            this.gb_Bill_Details = new System.Windows.Forms.GroupBox();
            this.tb_Total_Bill = new System.Windows.Forms.TextBox();
            this.lbl_Total_Bill = new System.Windows.Forms.Label();
            this.tb_Discount = new System.Windows.Forms.TextBox();
            this.tb_Total_Price = new System.Windows.Forms.TextBox();
            this.lbl_Total_Price = new System.Windows.Forms.Label();
            this.lbl_Discount = new System.Windows.Forms.Label();
            this.tb_GST_Applied = new System.Windows.Forms.TextBox();
            this.lbl_GST = new System.Windows.Forms.Label();
            this.pnl_Add_new_Customer = new System.Windows.Forms.Panel();
            this.pb_Close = new System.Windows.Forms.PictureBox();
            this.pb_Back = new System.Windows.Forms.PictureBox();
            this.lbl_Header = new System.Windows.Forms.Label();
            this.btn_Add = new System.Windows.Forms.Button();
            this.tb_Price = new System.Windows.Forms.TextBox();
            this.gb_Purchase_Details = new System.Windows.Forms.GroupBox();
            this.btn_Confirm = new System.Windows.Forms.Button();
            this.dgv_Purchase_Details = new System.Windows.Forms.DataGridView();
            this.Clear = new System.Windows.Forms.DataGridViewButtonColumn();
            this.tb_Quantity = new System.Windows.Forms.TextBox();
            this.lbl_Quantity = new System.Windows.Forms.Label();
            this.cb_Product_Subcategory = new System.Windows.Forms.ComboBox();
            this.cb_Product_Category = new System.Windows.Forms.ComboBox();
            this.cb_Product_Name = new System.Windows.Forms.ComboBox();
            this.lbl_Subcategory = new System.Windows.Forms.Label();
            this.lbl_Price = new System.Windows.Forms.Label();
            this.lbl_Category = new System.Windows.Forms.Label();
            this.lbl_Product_Name = new System.Windows.Forms.Label();
            this.customerPurchaseDetailsBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.computer_And_Mob_Shoppee_Mgt_Sys_DBDataSet3 = new Computer_And_Mobile_Shoppee_Management_System.Computer_And_Mob_Shoppee_Mgt_Sys_DBDataSet3();
            this.lbl_Customer_ID = new System.Windows.Forms.Label();
            this.lbl_Customer_Name = new System.Windows.Forms.Label();
            this.gb_Customer_Details = new System.Windows.Forms.GroupBox();
            this.dtp_Date = new System.Windows.Forms.DateTimePicker();
            this.tb_Address = new System.Windows.Forms.TextBox();
            this.tb_Mob_No = new System.Windows.Forms.TextBox();
            this.tb_Customer_Name = new System.Windows.Forms.TextBox();
            this.tb_Customer_ID = new System.Windows.Forms.TextBox();
            this.lbl_Address = new System.Windows.Forms.Label();
            this.lbl_Mob_No = new System.Windows.Forms.Label();
            this.btn_Save = new System.Windows.Forms.Button();
            this.btn_Refresh = new System.Windows.Forms.Button();
            this.customer_Purchase_DetailsTableAdapter = new Computer_And_Mobile_Shoppee_Management_System.Computer_And_Mob_Shoppee_Mgt_Sys_DBDataSet3TableAdapters.Customer_Purchase_DetailsTableAdapter();
            this.gb_Bill_Details.SuspendLayout();
            this.pnl_Add_new_Customer.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pb_Close)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_Back)).BeginInit();
            this.gb_Purchase_Details.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_Purchase_Details)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.customerPurchaseDetailsBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.computer_And_Mob_Shoppee_Mgt_Sys_DBDataSet3)).BeginInit();
            this.gb_Customer_Details.SuspendLayout();
            this.SuspendLayout();
            // 
            // gb_Bill_Details
            // 
            this.gb_Bill_Details.Controls.Add(this.tb_Total_Bill);
            this.gb_Bill_Details.Controls.Add(this.lbl_Total_Bill);
            this.gb_Bill_Details.Controls.Add(this.tb_Discount);
            this.gb_Bill_Details.Controls.Add(this.tb_Total_Price);
            this.gb_Bill_Details.Controls.Add(this.lbl_Total_Price);
            this.gb_Bill_Details.Controls.Add(this.lbl_Discount);
            this.gb_Bill_Details.Font = new System.Drawing.Font("Georgia", 14.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))));
            this.gb_Bill_Details.ForeColor = System.Drawing.Color.Black;
            this.gb_Bill_Details.Location = new System.Drawing.Point(13, 527);
            this.gb_Bill_Details.Name = "gb_Bill_Details";
            this.gb_Bill_Details.Size = new System.Drawing.Size(1319, 82);
            this.gb_Bill_Details.TabIndex = 29;
            this.gb_Bill_Details.TabStop = false;
            this.gb_Bill_Details.Text = "Bill Details";
            // 
            // tb_Total_Bill
            // 
            this.tb_Total_Bill.Enabled = false;
            this.tb_Total_Bill.Font = new System.Drawing.Font("Lucida Bright", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_Total_Bill.Location = new System.Drawing.Point(1108, 43);
            this.tb_Total_Bill.Name = "tb_Total_Bill";
            this.tb_Total_Bill.Size = new System.Drawing.Size(160, 30);
            this.tb_Total_Bill.TabIndex = 0;
            this.tb_Total_Bill.TextChanged += new System.EventHandler(this.tb_Total_Bill_TextChanged);
            // 
            // lbl_Total_Bill
            // 
            this.lbl_Total_Bill.AutoSize = true;
            this.lbl_Total_Bill.BackColor = System.Drawing.Color.SeaShell;
            this.lbl_Total_Bill.Font = new System.Drawing.Font("Lucida Bright", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Total_Bill.ForeColor = System.Drawing.Color.DarkRed;
            this.lbl_Total_Bill.Location = new System.Drawing.Point(988, 46);
            this.lbl_Total_Bill.Name = "lbl_Total_Bill";
            this.lbl_Total_Bill.Size = new System.Drawing.Size(94, 22);
            this.lbl_Total_Bill.TabIndex = 24;
            this.lbl_Total_Bill.Text = "Total Bill";
            // 
            // tb_Discount
            // 
            this.tb_Discount.Font = new System.Drawing.Font("Lucida Bright", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_Discount.Location = new System.Drawing.Point(679, 40);
            this.tb_Discount.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.tb_Discount.MaxLength = 2;
            this.tb_Discount.Name = "tb_Discount";
            this.tb_Discount.Size = new System.Drawing.Size(237, 30);
            this.tb_Discount.TabIndex = 10;
            this.tb_Discount.Text = "0";
            this.tb_Discount.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tb_Discount_KeyPress);
            this.tb_Discount.Leave += new System.EventHandler(this.tb_Discount_Leave);
            // 
            // tb_Total_Price
            // 
            this.tb_Total_Price.Enabled = false;
            this.tb_Total_Price.Font = new System.Drawing.Font("Lucida Bright", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_Total_Price.Location = new System.Drawing.Point(214, 40);
            this.tb_Total_Price.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.tb_Total_Price.Name = "tb_Total_Price";
            this.tb_Total_Price.Size = new System.Drawing.Size(237, 30);
            this.tb_Total_Price.TabIndex = 0;
            // 
            // lbl_Total_Price
            // 
            this.lbl_Total_Price.AutoSize = true;
            this.lbl_Total_Price.BackColor = System.Drawing.Color.SeaShell;
            this.lbl_Total_Price.Font = new System.Drawing.Font("Lucida Bright", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Total_Price.ForeColor = System.Drawing.Color.DarkRed;
            this.lbl_Total_Price.Location = new System.Drawing.Point(67, 43);
            this.lbl_Total_Price.Name = "lbl_Total_Price";
            this.lbl_Total_Price.Size = new System.Drawing.Size(110, 22);
            this.lbl_Total_Price.TabIndex = 18;
            this.lbl_Total_Price.Text = "Total Price";
            // 
            // lbl_Discount
            // 
            this.lbl_Discount.AutoSize = true;
            this.lbl_Discount.BackColor = System.Drawing.Color.SeaShell;
            this.lbl_Discount.Font = new System.Drawing.Font("Lucida Bright", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Discount.ForeColor = System.Drawing.Color.DarkRed;
            this.lbl_Discount.Location = new System.Drawing.Point(553, 43);
            this.lbl_Discount.Name = "lbl_Discount";
            this.lbl_Discount.Size = new System.Drawing.Size(92, 22);
            this.lbl_Discount.TabIndex = 17;
            this.lbl_Discount.Text = "Discount";
            // 
            // tb_GST_Applied
            // 
            this.tb_GST_Applied.Font = new System.Drawing.Font("Lucida Bright", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_GST_Applied.Location = new System.Drawing.Point(187, 163);
            this.tb_GST_Applied.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.tb_GST_Applied.Name = "tb_GST_Applied";
            this.tb_GST_Applied.Size = new System.Drawing.Size(168, 30);
            this.tb_GST_Applied.TabIndex = 8;
            this.tb_GST_Applied.TextChanged += new System.EventHandler(this.tb_GST_Applied_TextChanged);
            this.tb_GST_Applied.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tb_GST_Applied_KeyPress);
            // 
            // lbl_GST
            // 
            this.lbl_GST.AutoSize = true;
            this.lbl_GST.BackColor = System.Drawing.Color.SeaShell;
            this.lbl_GST.Font = new System.Drawing.Font("Lucida Bright", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_GST.ForeColor = System.Drawing.Color.DarkRed;
            this.lbl_GST.Location = new System.Drawing.Point(37, 166);
            this.lbl_GST.Name = "lbl_GST";
            this.lbl_GST.Size = new System.Drawing.Size(125, 22);
            this.lbl_GST.TabIndex = 20;
            this.lbl_GST.Text = "GST Applied";
            // 
            // pnl_Add_new_Customer
            // 
            this.pnl_Add_new_Customer.BackColor = System.Drawing.Color.Indigo;
            this.pnl_Add_new_Customer.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pnl_Add_new_Customer.Controls.Add(this.pb_Close);
            this.pnl_Add_new_Customer.Controls.Add(this.pb_Back);
            this.pnl_Add_new_Customer.Controls.Add(this.lbl_Header);
            this.pnl_Add_new_Customer.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnl_Add_new_Customer.Location = new System.Drawing.Point(0, 0);
            this.pnl_Add_new_Customer.Name = "pnl_Add_new_Customer";
            this.pnl_Add_new_Customer.Size = new System.Drawing.Size(1344, 98);
            this.pnl_Add_new_Customer.TabIndex = 24;
            // 
            // pb_Close
            // 
            this.pb_Close.Image = ((System.Drawing.Image)(resources.GetObject("pb_Close.Image")));
            this.pb_Close.Location = new System.Drawing.Point(1227, 22);
            this.pb_Close.Name = "pb_Close";
            this.pb_Close.Size = new System.Drawing.Size(105, 55);
            this.pb_Close.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pb_Close.TabIndex = 4;
            this.pb_Close.TabStop = false;
            this.pb_Close.Click += new System.EventHandler(this.pb_Close_Click);
            // 
            // pb_Back
            // 
            this.pb_Back.Image = ((System.Drawing.Image)(resources.GetObject("pb_Back.Image")));
            this.pb_Back.Location = new System.Drawing.Point(13, 22);
            this.pb_Back.Name = "pb_Back";
            this.pb_Back.Size = new System.Drawing.Size(100, 50);
            this.pb_Back.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pb_Back.TabIndex = 3;
            this.pb_Back.TabStop = false;
            this.pb_Back.Click += new System.EventHandler(this.pb_Back_Click);
            // 
            // lbl_Header
            // 
            this.lbl_Header.AutoSize = true;
            this.lbl_Header.BackColor = System.Drawing.Color.Indigo;
            this.lbl_Header.Font = new System.Drawing.Font("Lucida Bright", 27.75F, System.Drawing.FontStyle.Bold);
            this.lbl_Header.ForeColor = System.Drawing.Color.LavenderBlush;
            this.lbl_Header.Location = new System.Drawing.Point(490, 23);
            this.lbl_Header.Name = "lbl_Header";
            this.lbl_Header.Size = new System.Drawing.Size(381, 42);
            this.lbl_Header.TabIndex = 0;
            this.lbl_Header.Text = "Add New Customer";
            // 
            // btn_Add
            // 
            this.btn_Add.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.btn_Add.Font = new System.Drawing.Font("Lucida Bright", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Add.ForeColor = System.Drawing.Color.White;
            this.btn_Add.Location = new System.Drawing.Point(402, 103);
            this.btn_Add.Name = "btn_Add";
            this.btn_Add.Size = new System.Drawing.Size(88, 40);
            this.btn_Add.TabIndex = 8;
            this.btn_Add.Text = "Add";
            this.btn_Add.UseVisualStyleBackColor = false;
            this.btn_Add.Click += new System.EventHandler(this.btn_Add_Click);
            // 
            // tb_Price
            // 
            this.tb_Price.Enabled = false;
            this.tb_Price.Font = new System.Drawing.Font("Lucida Bright", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_Price.Location = new System.Drawing.Point(187, 253);
            this.tb_Price.Name = "tb_Price";
            this.tb_Price.Size = new System.Drawing.Size(168, 30);
            this.tb_Price.TabIndex = 0;
            this.tb_Price.TextChanged += new System.EventHandler(this.tb_Price_TextChanged);
            // 
            // gb_Purchase_Details
            // 
            this.gb_Purchase_Details.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.gb_Purchase_Details.Controls.Add(this.btn_Confirm);
            this.gb_Purchase_Details.Controls.Add(this.dgv_Purchase_Details);
            this.gb_Purchase_Details.Controls.Add(this.btn_Add);
            this.gb_Purchase_Details.Controls.Add(this.tb_Price);
            this.gb_Purchase_Details.Controls.Add(this.tb_Quantity);
            this.gb_Purchase_Details.Controls.Add(this.tb_GST_Applied);
            this.gb_Purchase_Details.Controls.Add(this.lbl_GST);
            this.gb_Purchase_Details.Controls.Add(this.lbl_Quantity);
            this.gb_Purchase_Details.Controls.Add(this.cb_Product_Subcategory);
            this.gb_Purchase_Details.Controls.Add(this.cb_Product_Category);
            this.gb_Purchase_Details.Controls.Add(this.cb_Product_Name);
            this.gb_Purchase_Details.Controls.Add(this.lbl_Subcategory);
            this.gb_Purchase_Details.Controls.Add(this.lbl_Price);
            this.gb_Purchase_Details.Controls.Add(this.lbl_Category);
            this.gb_Purchase_Details.Controls.Add(this.lbl_Product_Name);
            this.gb_Purchase_Details.Font = new System.Drawing.Font("Georgia", 14.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))));
            this.gb_Purchase_Details.ForeColor = System.Drawing.Color.Black;
            this.gb_Purchase_Details.Location = new System.Drawing.Point(13, 229);
            this.gb_Purchase_Details.Name = "gb_Purchase_Details";
            this.gb_Purchase_Details.Size = new System.Drawing.Size(1319, 292);
            this.gb_Purchase_Details.TabIndex = 28;
            this.gb_Purchase_Details.TabStop = false;
            this.gb_Purchase_Details.Text = "Purchase Details";
            // 
            // btn_Confirm
            // 
            this.btn_Confirm.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.btn_Confirm.Font = new System.Drawing.Font("Lucida Bright", 20.25F, System.Drawing.FontStyle.Bold);
            this.btn_Confirm.ForeColor = System.Drawing.Color.White;
            this.btn_Confirm.Location = new System.Drawing.Point(379, 163);
            this.btn_Confirm.Name = "btn_Confirm";
            this.btn_Confirm.Size = new System.Drawing.Size(130, 40);
            this.btn_Confirm.TabIndex = 21;
            this.btn_Confirm.Text = "confirm";
            this.btn_Confirm.UseVisualStyleBackColor = false;
            this.btn_Confirm.Click += new System.EventHandler(this.btn_Confirm_Click);
            // 
            // dgv_Purchase_Details
            // 
            this.dgv_Purchase_Details.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Georgia", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgv_Purchase_Details.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dgv_Purchase_Details.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv_Purchase_Details.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Clear});
            this.dgv_Purchase_Details.Location = new System.Drawing.Point(528, 41);
            this.dgv_Purchase_Details.Name = "dgv_Purchase_Details";
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dgv_Purchase_Details.RowsDefaultCellStyle = dataGridViewCellStyle2;
            this.dgv_Purchase_Details.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.dgv_Purchase_Details.Size = new System.Drawing.Size(760, 222);
            this.dgv_Purchase_Details.TabIndex = 17;
            this.dgv_Purchase_Details.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick);
            // 
            // Clear
            // 
            this.Clear.HeaderText = "Clear";
            this.Clear.Name = "Clear";
            this.Clear.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.Clear.Text = "X";
            this.Clear.UseColumnTextForButtonValue = true;
            // 
            // tb_Quantity
            // 
            this.tb_Quantity.Font = new System.Drawing.Font("Lucida Bright", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_Quantity.Location = new System.Drawing.Point(187, 209);
            this.tb_Quantity.MaxLength = 5;
            this.tb_Quantity.Name = "tb_Quantity";
            this.tb_Quantity.Size = new System.Drawing.Size(168, 30);
            this.tb_Quantity.TabIndex = 9;
            this.tb_Quantity.TextChanged += new System.EventHandler(this.tb_Quantity_TextChanged);
            this.tb_Quantity.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tb_Quantity_KeyPress);
            // 
            // lbl_Quantity
            // 
            this.lbl_Quantity.AutoSize = true;
            this.lbl_Quantity.BackColor = System.Drawing.Color.SeaShell;
            this.lbl_Quantity.Font = new System.Drawing.Font("Lucida Bright", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Quantity.ForeColor = System.Drawing.Color.DarkRed;
            this.lbl_Quantity.Location = new System.Drawing.Point(43, 212);
            this.lbl_Quantity.Name = "lbl_Quantity";
            this.lbl_Quantity.Size = new System.Drawing.Size(90, 22);
            this.lbl_Quantity.TabIndex = 3;
            this.lbl_Quantity.Text = "Quantity";
            // 
            // cb_Product_Subcategory
            // 
            this.cb_Product_Subcategory.Font = new System.Drawing.Font("Lucida Bright", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cb_Product_Subcategory.FormattingEnabled = true;
            this.cb_Product_Subcategory.Location = new System.Drawing.Point(187, 73);
            this.cb_Product_Subcategory.Name = "cb_Product_Subcategory";
            this.cb_Product_Subcategory.Size = new System.Drawing.Size(168, 30);
            this.cb_Product_Subcategory.TabIndex = 5;
            this.cb_Product_Subcategory.SelectedIndexChanged += new System.EventHandler(this.cb_Product_Subcategory_SelectedIndexChanged);
            // 
            // cb_Product_Category
            // 
            this.cb_Product_Category.Font = new System.Drawing.Font("Lucida Bright", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cb_Product_Category.FormattingEnabled = true;
            this.cb_Product_Category.Location = new System.Drawing.Point(187, 28);
            this.cb_Product_Category.Name = "cb_Product_Category";
            this.cb_Product_Category.Size = new System.Drawing.Size(168, 30);
            this.cb_Product_Category.TabIndex = 4;
            this.cb_Product_Category.SelectedIndexChanged += new System.EventHandler(this.cb_Product_Category_SelectedIndexChanged);
            // 
            // cb_Product_Name
            // 
            this.cb_Product_Name.Font = new System.Drawing.Font("Lucida Bright", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cb_Product_Name.FormattingEnabled = true;
            this.cb_Product_Name.Location = new System.Drawing.Point(187, 118);
            this.cb_Product_Name.Name = "cb_Product_Name";
            this.cb_Product_Name.Size = new System.Drawing.Size(168, 30);
            this.cb_Product_Name.TabIndex = 6;
            this.cb_Product_Name.SelectedIndexChanged += new System.EventHandler(this.cb_Product_Name_SelectedIndexChanged);
            // 
            // lbl_Subcategory
            // 
            this.lbl_Subcategory.AutoSize = true;
            this.lbl_Subcategory.BackColor = System.Drawing.Color.SeaShell;
            this.lbl_Subcategory.Font = new System.Drawing.Font("Lucida Bright", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Subcategory.ForeColor = System.Drawing.Color.DarkRed;
            this.lbl_Subcategory.Location = new System.Drawing.Point(40, 76);
            this.lbl_Subcategory.Name = "lbl_Subcategory";
            this.lbl_Subcategory.Size = new System.Drawing.Size(123, 22);
            this.lbl_Subcategory.TabIndex = 2;
            this.lbl_Subcategory.Text = "Subcategory";
            // 
            // lbl_Price
            // 
            this.lbl_Price.AutoSize = true;
            this.lbl_Price.BackColor = System.Drawing.Color.SeaShell;
            this.lbl_Price.Font = new System.Drawing.Font("Lucida Bright", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Price.ForeColor = System.Drawing.Color.DarkRed;
            this.lbl_Price.Location = new System.Drawing.Point(40, 256);
            this.lbl_Price.Name = "lbl_Price";
            this.lbl_Price.Size = new System.Drawing.Size(55, 22);
            this.lbl_Price.TabIndex = 16;
            this.lbl_Price.Text = "Price";
            // 
            // lbl_Category
            // 
            this.lbl_Category.AutoSize = true;
            this.lbl_Category.BackColor = System.Drawing.Color.SeaShell;
            this.lbl_Category.Font = new System.Drawing.Font("Lucida Bright", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Category.ForeColor = System.Drawing.Color.DarkRed;
            this.lbl_Category.Location = new System.Drawing.Point(40, 31);
            this.lbl_Category.Name = "lbl_Category";
            this.lbl_Category.Size = new System.Drawing.Size(93, 22);
            this.lbl_Category.TabIndex = 1;
            this.lbl_Category.Text = "Category";
            // 
            // lbl_Product_Name
            // 
            this.lbl_Product_Name.AutoSize = true;
            this.lbl_Product_Name.BackColor = System.Drawing.Color.SeaShell;
            this.lbl_Product_Name.Font = new System.Drawing.Font("Lucida Bright", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Product_Name.ForeColor = System.Drawing.Color.DarkRed;
            this.lbl_Product_Name.Location = new System.Drawing.Point(37, 121);
            this.lbl_Product_Name.Name = "lbl_Product_Name";
            this.lbl_Product_Name.Size = new System.Drawing.Size(141, 22);
            this.lbl_Product_Name.TabIndex = 0;
            this.lbl_Product_Name.Text = "Product Name";
            // 
            // customerPurchaseDetailsBindingSource
            // 
            this.customerPurchaseDetailsBindingSource.DataMember = "Customer_Purchase_Details";
            this.customerPurchaseDetailsBindingSource.DataSource = this.computer_And_Mob_Shoppee_Mgt_Sys_DBDataSet3;
            // 
            // computer_And_Mob_Shoppee_Mgt_Sys_DBDataSet3
            // 
            this.computer_And_Mob_Shoppee_Mgt_Sys_DBDataSet3.DataSetName = "Computer_And_Mob_Shoppee_Mgt_Sys_DBDataSet3";
            this.computer_And_Mob_Shoppee_Mgt_Sys_DBDataSet3.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // lbl_Customer_ID
            // 
            this.lbl_Customer_ID.AutoSize = true;
            this.lbl_Customer_ID.BackColor = System.Drawing.Color.SeaShell;
            this.lbl_Customer_ID.Font = new System.Drawing.Font("Lucida Bright", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Customer_ID.ForeColor = System.Drawing.Color.DarkRed;
            this.lbl_Customer_ID.Location = new System.Drawing.Point(41, 37);
            this.lbl_Customer_ID.Name = "lbl_Customer_ID";
            this.lbl_Customer_ID.Size = new System.Drawing.Size(126, 22);
            this.lbl_Customer_ID.TabIndex = 0;
            this.lbl_Customer_ID.Text = "Customer ID";
            // 
            // lbl_Customer_Name
            // 
            this.lbl_Customer_Name.AutoSize = true;
            this.lbl_Customer_Name.BackColor = System.Drawing.Color.SeaShell;
            this.lbl_Customer_Name.Font = new System.Drawing.Font("Lucida Bright", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Customer_Name.ForeColor = System.Drawing.Color.DarkRed;
            this.lbl_Customer_Name.Location = new System.Drawing.Point(41, 86);
            this.lbl_Customer_Name.Name = "lbl_Customer_Name";
            this.lbl_Customer_Name.Size = new System.Drawing.Size(159, 22);
            this.lbl_Customer_Name.TabIndex = 1;
            this.lbl_Customer_Name.Text = "Customer Name";
            // 
            // gb_Customer_Details
            // 
            this.gb_Customer_Details.BackColor = System.Drawing.Color.Transparent;
            this.gb_Customer_Details.Controls.Add(this.dtp_Date);
            this.gb_Customer_Details.Controls.Add(this.tb_Address);
            this.gb_Customer_Details.Controls.Add(this.tb_Mob_No);
            this.gb_Customer_Details.Controls.Add(this.tb_Customer_Name);
            this.gb_Customer_Details.Controls.Add(this.tb_Customer_ID);
            this.gb_Customer_Details.Controls.Add(this.lbl_Address);
            this.gb_Customer_Details.Controls.Add(this.lbl_Mob_No);
            this.gb_Customer_Details.Controls.Add(this.lbl_Customer_Name);
            this.gb_Customer_Details.Controls.Add(this.lbl_Customer_ID);
            this.gb_Customer_Details.Font = new System.Drawing.Font("Georgia", 14.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))));
            this.gb_Customer_Details.ForeColor = System.Drawing.Color.Black;
            this.gb_Customer_Details.Location = new System.Drawing.Point(13, 97);
            this.gb_Customer_Details.Name = "gb_Customer_Details";
            this.gb_Customer_Details.Size = new System.Drawing.Size(1319, 126);
            this.gb_Customer_Details.TabIndex = 27;
            this.gb_Customer_Details.TabStop = false;
            this.gb_Customer_Details.Text = "Customer Details";
            // 
            // dtp_Date
            // 
            this.dtp_Date.CalendarFont = new System.Drawing.Font("Georgia", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtp_Date.Enabled = false;
            this.dtp_Date.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtp_Date.Location = new System.Drawing.Point(1097, 59);
            this.dtp_Date.Name = "dtp_Date";
            this.dtp_Date.Size = new System.Drawing.Size(199, 29);
            this.dtp_Date.TabIndex = 4;
            // 
            // tb_Address
            // 
            this.tb_Address.Font = new System.Drawing.Font("Lucida Bright", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_Address.Location = new System.Drawing.Point(770, 86);
            this.tb_Address.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.tb_Address.MaxLength = 40;
            this.tb_Address.Name = "tb_Address";
            this.tb_Address.Size = new System.Drawing.Size(273, 30);
            this.tb_Address.TabIndex = 3;
            // 
            // tb_Mob_No
            // 
            this.tb_Mob_No.Font = new System.Drawing.Font("Lucida Bright", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_Mob_No.Location = new System.Drawing.Point(770, 27);
            this.tb_Mob_No.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.tb_Mob_No.MaxLength = 10;
            this.tb_Mob_No.Name = "tb_Mob_No";
            this.tb_Mob_No.Size = new System.Drawing.Size(273, 30);
            this.tb_Mob_No.TabIndex = 2;
            this.tb_Mob_No.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tb_Mob_No_KeyPress);
            // 
            // tb_Customer_Name
            // 
            this.tb_Customer_Name.Font = new System.Drawing.Font("Lucida Bright", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_Customer_Name.Location = new System.Drawing.Point(256, 83);
            this.tb_Customer_Name.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.tb_Customer_Name.MaxLength = 20;
            this.tb_Customer_Name.Name = "tb_Customer_Name";
            this.tb_Customer_Name.Size = new System.Drawing.Size(273, 30);
            this.tb_Customer_Name.TabIndex = 1;
            // 
            // tb_Customer_ID
            // 
            this.tb_Customer_ID.Enabled = false;
            this.tb_Customer_ID.Font = new System.Drawing.Font("Lucida Bright", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_Customer_ID.Location = new System.Drawing.Point(256, 27);
            this.tb_Customer_ID.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.tb_Customer_ID.Name = "tb_Customer_ID";
            this.tb_Customer_ID.Size = new System.Drawing.Size(273, 30);
            this.tb_Customer_ID.TabIndex = 0;
            // 
            // lbl_Address
            // 
            this.lbl_Address.AutoSize = true;
            this.lbl_Address.BackColor = System.Drawing.Color.SeaShell;
            this.lbl_Address.Font = new System.Drawing.Font("Lucida Bright", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Address.ForeColor = System.Drawing.Color.DarkRed;
            this.lbl_Address.Location = new System.Drawing.Point(612, 89);
            this.lbl_Address.Name = "lbl_Address";
            this.lbl_Address.Size = new System.Drawing.Size(85, 22);
            this.lbl_Address.TabIndex = 3;
            this.lbl_Address.Text = "Address";
            // 
            // lbl_Mob_No
            // 
            this.lbl_Mob_No.AutoSize = true;
            this.lbl_Mob_No.BackColor = System.Drawing.Color.SeaShell;
            this.lbl_Mob_No.Font = new System.Drawing.Font("Lucida Bright", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Mob_No.ForeColor = System.Drawing.Color.DarkRed;
            this.lbl_Mob_No.Location = new System.Drawing.Point(612, 32);
            this.lbl_Mob_No.Name = "lbl_Mob_No";
            this.lbl_Mob_No.Size = new System.Drawing.Size(103, 22);
            this.lbl_Mob_No.TabIndex = 2;
            this.lbl_Mob_No.Text = "Mobile No";
            // 
            // btn_Save
            // 
            this.btn_Save.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.btn_Save.Font = new System.Drawing.Font("Lucida Bright", 27.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Save.ForeColor = System.Drawing.Color.White;
            this.btn_Save.Location = new System.Drawing.Point(351, 624);
            this.btn_Save.Name = "btn_Save";
            this.btn_Save.Size = new System.Drawing.Size(127, 56);
            this.btn_Save.TabIndex = 11;
            this.btn_Save.Text = "Save";
            this.btn_Save.UseVisualStyleBackColor = false;
            this.btn_Save.Click += new System.EventHandler(this.btn_Save_Click);
            // 
            // btn_Refresh
            // 
            this.btn_Refresh.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.btn_Refresh.Font = new System.Drawing.Font("Lucida Bright", 27.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Refresh.ForeColor = System.Drawing.Color.White;
            this.btn_Refresh.Location = new System.Drawing.Point(873, 624);
            this.btn_Refresh.Name = "btn_Refresh";
            this.btn_Refresh.Size = new System.Drawing.Size(170, 56);
            this.btn_Refresh.TabIndex = 12;
            this.btn_Refresh.Text = "Refresh";
            this.btn_Refresh.UseVisualStyleBackColor = false;
            this.btn_Refresh.Click += new System.EventHandler(this.btn_Refresh_Click);
            // 
            // customer_Purchase_DetailsTableAdapter
            // 
            this.customer_Purchase_DetailsTableAdapter.ClearBeforeFill = true;
            // 
            // frm_Add_New_Customer
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(15F, 28F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.ClientSize = new System.Drawing.Size(1344, 712);
            this.Controls.Add(this.gb_Bill_Details);
            this.Controls.Add(this.pnl_Add_new_Customer);
            this.Controls.Add(this.gb_Purchase_Details);
            this.Controls.Add(this.gb_Customer_Details);
            this.Controls.Add(this.btn_Save);
            this.Controls.Add(this.btn_Refresh);
            this.Font = new System.Drawing.Font("Lucida Bright", 18F);
            this.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.Margin = new System.Windows.Forms.Padding(8, 6, 8, 6);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "frm_Add_New_Customer";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Add New Customer";
            this.Load += new System.EventHandler(this.frm_Add_New_Customer_Load);
            this.gb_Bill_Details.ResumeLayout(false);
            this.gb_Bill_Details.PerformLayout();
            this.pnl_Add_new_Customer.ResumeLayout(false);
            this.pnl_Add_new_Customer.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pb_Close)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_Back)).EndInit();
            this.gb_Purchase_Details.ResumeLayout(false);
            this.gb_Purchase_Details.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_Purchase_Details)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.customerPurchaseDetailsBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.computer_And_Mob_Shoppee_Mgt_Sys_DBDataSet3)).EndInit();
            this.gb_Customer_Details.ResumeLayout(false);
            this.gb_Customer_Details.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox gb_Bill_Details;
        private System.Windows.Forms.TextBox tb_Total_Bill;
        private System.Windows.Forms.Label lbl_Total_Bill;
        private System.Windows.Forms.TextBox tb_Discount;
        private System.Windows.Forms.TextBox tb_Total_Price;
        private System.Windows.Forms.TextBox tb_GST_Applied;
        private System.Windows.Forms.Label lbl_GST;
        private System.Windows.Forms.Label lbl_Total_Price;
        private System.Windows.Forms.Label lbl_Discount;
        private System.Windows.Forms.Panel pnl_Add_new_Customer;
        private System.Windows.Forms.PictureBox pb_Close;
        private System.Windows.Forms.PictureBox pb_Back;
        private System.Windows.Forms.Label lbl_Header;
        private System.Windows.Forms.Button btn_Add;
        private System.Windows.Forms.TextBox tb_Price;
        private System.Windows.Forms.GroupBox gb_Purchase_Details;
        private System.Windows.Forms.TextBox tb_Quantity;
        private System.Windows.Forms.ComboBox cb_Product_Subcategory;
        private System.Windows.Forms.ComboBox cb_Product_Category;
        private System.Windows.Forms.ComboBox cb_Product_Name;
        private System.Windows.Forms.Label lbl_Quantity;
        private System.Windows.Forms.Label lbl_Subcategory;
        private System.Windows.Forms.Label lbl_Price;
        private System.Windows.Forms.Label lbl_Category;
        private System.Windows.Forms.Label lbl_Product_Name;
        private System.Windows.Forms.Label lbl_Customer_ID;
        private System.Windows.Forms.Label lbl_Customer_Name;
        private System.Windows.Forms.GroupBox gb_Customer_Details;
        private System.Windows.Forms.TextBox tb_Address;
        private System.Windows.Forms.TextBox tb_Mob_No;
        private System.Windows.Forms.TextBox tb_Customer_Name;
        private System.Windows.Forms.TextBox tb_Customer_ID;
        private System.Windows.Forms.Label lbl_Address;
        private System.Windows.Forms.Label lbl_Mob_No;
        private System.Windows.Forms.Button btn_Save;
        private System.Windows.Forms.Button btn_Refresh;
        private System.Windows.Forms.DataGridView dgv_Purchase_Details;
        private Computer_And_Mob_Shoppee_Mgt_Sys_DBDataSet3 computer_And_Mob_Shoppee_Mgt_Sys_DBDataSet3;
        private System.Windows.Forms.BindingSource customerPurchaseDetailsBindingSource;
        private Computer_And_Mob_Shoppee_Mgt_Sys_DBDataSet3TableAdapters.Customer_Purchase_DetailsTableAdapter customer_Purchase_DetailsTableAdapter;
        private System.Windows.Forms.Button btn_Confirm;
        private System.Windows.Forms.DateTimePicker dtp_Date;
        private System.Windows.Forms.DataGridViewButtonColumn Clear;

    }
}