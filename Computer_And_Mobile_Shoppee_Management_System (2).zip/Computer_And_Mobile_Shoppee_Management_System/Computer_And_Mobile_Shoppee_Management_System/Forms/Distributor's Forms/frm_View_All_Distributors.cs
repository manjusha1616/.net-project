﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Computer_And_Mobile_Shoppee_Management_System
{
    public partial class frm_View_All_Distributors : Form
    {
        Global_ClassFile Gobj = new Global_ClassFile();

        public frm_View_All_Distributors()
        {
            InitializeComponent();
        }

        private void frm_View_All_Distributors_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'computer_And_Mob_Shoppee_Mgt_Sys_DBDataSet2.Distributor_Details' table. You can move, or remove it, as needed.
            this.distributor_DetailsTableAdapter.Fill(this.computer_And_Mob_Shoppee_Mgt_Sys_DBDataSet2.Distributor_Details);

            tb_Distributor_ID.Focus();
        }

        private void tb_Distributor_ID_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!(Char.IsDigit(e.KeyChar) || (e.KeyChar == (char)Keys.Back)))
            {
                e.Handled = true;
            }
        }

        private void btn_Search_Click(object sender, EventArgs e)
        {
            tb_Distributor_ID.Enabled = false;

            Gobj.ConnectDB();

            SqlDataAdapter sda = new SqlDataAdapter("Select * from Distributor_Details where Distributor_ID = " + tb_Distributor_ID.Text + " ", Gobj.Con);

            DataTable dt = new DataTable();
            sda.Fill(dt);

            dgv_Distributors_Details.DataSource = dt;

            Gobj.DisconnectDB();
        }

        private void btn_Refresh_Click(object sender, EventArgs e)
        {
            tb_Distributor_ID.Enabled = true;
            tb_Distributor_ID.Focus();
            tb_Distributor_ID.Text = " ";

            SqlDataAdapter sda = new SqlDataAdapter("Select * From Distributor_Details", Gobj.Con);

            DataTable dt = new DataTable();
            sda.Fill(dt);

            dgv_Distributors_Details.DataSource = dt;
        }

        private void pb_Back_Click(object sender, EventArgs e)
        {
            frm_Distributor_Entry_Form obj = new frm_Distributor_Entry_Form();

            obj.WindowState = FormWindowState.Maximized;
            this.Hide();
            obj.Show();
        }

        private void pb_Close_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show("Do You Want To Close This Appllication?", "close Application", MessageBoxButtons.YesNo);

            if (result == DialogResult.Yes)
            {
                frm_Login obj = new frm_Login();
                this.Hide();
                obj.Show();
            }
            else
            {
                this.Show();
            }
        }

    }
}
