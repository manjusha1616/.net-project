﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Computer_And_Mobile_Shoppee_Management_System
{
    public partial class frm_Add_New_Product : Form
    {
        Global_ClassFile Gobj = new Global_ClassFile();

        public frm_Add_New_Product()
        {
            InitializeComponent();
        }      

        private void frm_Add_New_Product_Load(object sender, EventArgs e)
        {
            Clear_Controls();        
        }

        int Auto_Incr_ID()
        {
            Gobj.ConnectDB();

            int Cnt = 0;

            SqlCommand Cmd = new SqlCommand();

            Cmd.CommandText = "Select Count(Product_ID) from Product_Details";
            Cmd.Connection = Gobj.Con;

            Cnt = Convert.ToInt32(Cmd.ExecuteScalar());

            Cmd.Dispose();

            if (Cnt > 0)
            {
                Cmd.CommandText = "Select Max(Product_ID) from Product_Details";
                Cmd.Connection = Gobj.Con;
            }

            Cnt = 1 + Cnt;

            Gobj.DisconnectDB();

            return Cnt;
        }

        void Clear_Controls()
        {
            tb_Product_ID.Text = Convert.ToString(Auto_Incr_ID());
            cb_Category.Text = " ";
            cb_Subcategory.Text = "";
            cb_Distributor_Name.Text = "";
            cb_Subcategory.Items.Clear();
            cb_Category.Items.Clear();
            cb_Distributor_Name.Items.Clear();
            tb_Product_Name.Text = "";
            cb_Distributor_Name.Text = "";
            dtp_Date.ResetText();
            tb_Sales_Rate.Text = "";
            tb_Purchase_Prize.Text = "";
            tb_Stock_Quantity.Text = "";
            tb_GST.Text = "";
            tb_Description.Text = "";
            cb_Category.Enabled = true;
            cb_Category.Focus();
            Bind_categories_To_ComboBox();
        }

        void Bind_categories_To_ComboBox()
        {
            Gobj.ConnectDB();

            SqlCommand Cmd = new SqlCommand("Select Distinct(Category_Name) From Category_Details", Gobj.Con);

            var obj = Cmd.ExecuteReader();

            while (obj.Read())
            {
                cb_Category.Items.Add(obj.GetString(obj.GetOrdinal("Category_Name")));
            }

            obj.Dispose();

            Gobj.DisconnectDB();
        }

        private void tb_Product_ID_TextChanged(object sender, EventArgs e)
        {
            cb_Category.Focus();
        }

        void Bind_Subcategories_To_Combobox()
        {
            Gobj.ConnectDB();

            SqlCommand cmd = new SqlCommand();

            cmd.CommandText = "Select Subcategory_Name From Subcategory_Details where Category_Name = '" + cb_Category.Text + "' ";
            cmd.Connection = Gobj.Con;

            var Obj = cmd.ExecuteReader();

            while (Obj.Read())
            {
                cb_Subcategory.Items.Add(Obj.GetString(Obj.GetOrdinal("Subcategory_Name")));
            }

            Gobj.DisconnectDB();
        }

        private void cb_Category_SelectedIndexChanged(object sender, EventArgs e)
        {
            cb_Subcategory.Items.Clear();
            cb_Subcategory.Text = "";
            cb_Subcategory.Enabled = true;

            Bind_Subcategories_To_Combobox();
        }

        void Bind_Distributors_To_CMB()
        {
            Gobj.ConnectDB();

            SqlCommand Cmd = new SqlCommand("Select Distinct(Distributor_Name) From Distributor_Details", Gobj.Con);

            var obj = Cmd.ExecuteReader();

            while (obj.Read())
            {
                cb_Distributor_Name.Items.Add(obj.GetString(obj.GetOrdinal("Distributor_Name")));
            }

            obj.Dispose();

            Gobj.DisconnectDB();
        }

        private void tb_Product_Name_TextChanged(object sender, EventArgs e)
        {
            cb_Distributor_Name.Items.Clear();
            cb_Distributor_Name.Text = "";

            Bind_Distributors_To_CMB();

            cb_Category.Enabled = false;
            cb_Subcategory.Enabled = false;
        }

        private void cb_Subcategory_SelectedIndexChanged(object sender, EventArgs e)
        {
            tb_Product_Name.Enabled = true;
        }

        private void tb_Sales_Rate_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!(Char.IsDigit(e.KeyChar) || (e.KeyChar == (char)Keys.Back)))
            {
                e.Handled = true;
            }
        }

        private void tb_Purchase_Prize_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!(Char.IsDigit(e.KeyChar) || (e.KeyChar == (char)Keys.Back)))
            {
                e.Handled = true;
            }
        }

        private void tb_Stock_Quantity_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!(Char.IsDigit(e.KeyChar) || (e.KeyChar == (char)Keys.Back)))
            {
                e.Handled = true;
            }
        }

        private void btn_Save_Click(object sender, EventArgs e)
        {
            Gobj.ConnectDB();

            SqlDataAdapter Sda = new SqlDataAdapter("select * from Product_Details where Product_Name = '" + tb_Product_Name.Text + "'", Gobj.Con);
            DataTable dt = new DataTable();
            Sda.Fill(dt);

            if (dt.Rows.Count >= 1)
            {
                MessageBox.Show("This Product Is Already Exist", "Failure", MessageBoxButtons.OK, MessageBoxIcon.Error);
                Clear_Controls();
            }
            else if (tb_Product_ID.Text!= "" && cb_Category.Text != ""  && cb_Subcategory.Text != "" && cb_Distributor_Name.Text != "" && tb_Product_Name.Text != "" && tb_Sales_Rate.Text != "" && tb_Purchase_Prize.Text != "" && tb_Stock_Quantity.Text != "" && tb_GST.Text != "")
            {
                SqlDataAdapter sda = new SqlDataAdapter("Insert into Product_Details(Cateogory ,Subcategory ,Product_Name ,Distributor_Name ,Date ,Sales_Rate ,Purchase_Prize ,Stock_Quantity ,GST ,Description ,Username) values('" + cb_Category.Text + "','" + cb_Subcategory.Text + "','" + tb_Product_Name.Text + "','" + cb_Distributor_Name.Text + "','" + dtp_Date.Text + "'," + tb_Sales_Rate.Text + "," + tb_Purchase_Prize.Text + "," + tb_Stock_Quantity.Text + ",'" + tb_GST.Text + "','" + tb_Description.Text + "','" + Global_ClassFile.Uname + "')", Gobj.Con);
                DataTable DT = new DataTable();
                sda.Fill(DT);

                SqlDataAdapter sda2 = new SqlDataAdapter("Insert into Stock_Details (Product_ID,Category,Subcategory,Product_Name,Date,Stock_Quantity,Username) values(" + tb_Product_ID.Text + ",'" + cb_Category.Text + "','" + cb_Subcategory.Text + "','" + tb_Product_Name.Text + "','" + dtp_Date.Text + "'," + tb_Stock_Quantity.Text + ",'" + Global_ClassFile.Uname + "')", Gobj.Con);
                DataTable DT2 = new DataTable();
                sda2.Fill(DT2);

                MessageBox.Show("Record Saved Successfully...", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);

                Clear_Controls();
            }
            else
            {
                MessageBox.Show("Please, Fill All The Fields", "Failure", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

            Gobj.DisconnectDB();
        }

        private void btn_Refresh_Click(object sender, EventArgs e)
        {
            Clear_Controls();
        }

        private void pb_Back_Click(object sender, EventArgs e)
        {
            frm_Product_Entry_Form obj = new frm_Product_Entry_Form();

            obj.WindowState = FormWindowState.Maximized;
            this.Hide();
            obj.Show();
        }

        private void pb_Close_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show("Do You Want To Close This Appllication?", "close Application", MessageBoxButtons.YesNo);

            if (result == DialogResult.Yes)
            {
                frm_Login obj = new frm_Login();
                this.Hide();
                obj.Show();
            }
            else
            {
                this.Show();
            }
        }       
    }
}
