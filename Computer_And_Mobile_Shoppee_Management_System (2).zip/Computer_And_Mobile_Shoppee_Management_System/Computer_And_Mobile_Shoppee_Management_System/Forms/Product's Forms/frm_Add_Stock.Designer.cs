﻿namespace Computer_And_Mobile_Shoppee_Management_System
{
    partial class frm_Add_Stock
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frm_Add_Stock));
            this.pnl_Add_Stock = new System.Windows.Forms.Panel();
            this.pb_Close = new System.Windows.Forms.PictureBox();
            this.pb_Back = new System.Windows.Forms.PictureBox();
            this.lbl_Header = new System.Windows.Forms.Label();
            this.cb_Category = new System.Windows.Forms.ComboBox();
            this.dtp_Date = new System.Windows.Forms.DateTimePicker();
            this.tb_Current_Stock = new System.Windows.Forms.TextBox();
            this.lbl_Subcategory = new System.Windows.Forms.Label();
            this.tb_New_Stock_Quantity = new System.Windows.Forms.TextBox();
            this.lbl_Category = new System.Windows.Forms.Label();
            this.lbl_Product_Name = new System.Windows.Forms.Label();
            this.btn_Submit = new System.Windows.Forms.Button();
            this.lbl_Product_ID = new System.Windows.Forms.Label();
            this.lbl_Date = new System.Windows.Forms.Label();
            this.lbl_Current_Stock_Quantity = new System.Windows.Forms.Label();
            this.cb_Subcategory = new System.Windows.Forms.ComboBox();
            this.cb_Product_Name = new System.Windows.Forms.ComboBox();
            this.btn_Refresh = new System.Windows.Forms.Button();
            this.tb_Product_ID = new System.Windows.Forms.TextBox();
            this.gb_Stock_Details = new System.Windows.Forms.GroupBox();
            this.lbl_New_Stock_Quantity = new System.Windows.Forms.Label();
            this.pnl_Stock_Details = new System.Windows.Forms.Panel();
            this.pnl_Add_Stock.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pb_Close)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_Back)).BeginInit();
            this.gb_Stock_Details.SuspendLayout();
            this.pnl_Stock_Details.SuspendLayout();
            this.SuspendLayout();
            // 
            // pnl_Add_Stock
            // 
            this.pnl_Add_Stock.BackColor = System.Drawing.Color.Indigo;
            this.pnl_Add_Stock.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pnl_Add_Stock.Controls.Add(this.pb_Close);
            this.pnl_Add_Stock.Controls.Add(this.pb_Back);
            this.pnl_Add_Stock.Controls.Add(this.lbl_Header);
            this.pnl_Add_Stock.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnl_Add_Stock.Location = new System.Drawing.Point(0, 0);
            this.pnl_Add_Stock.Name = "pnl_Add_Stock";
            this.pnl_Add_Stock.Size = new System.Drawing.Size(1344, 98);
            this.pnl_Add_Stock.TabIndex = 14;
            // 
            // pb_Close
            // 
            this.pb_Close.Image = ((System.Drawing.Image)(resources.GetObject("pb_Close.Image")));
            this.pb_Close.Location = new System.Drawing.Point(1232, 22);
            this.pb_Close.Name = "pb_Close";
            this.pb_Close.Size = new System.Drawing.Size(105, 55);
            this.pb_Close.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pb_Close.TabIndex = 1;
            this.pb_Close.TabStop = false;
            this.pb_Close.Click += new System.EventHandler(this.pb_Close_Click);
            // 
            // pb_Back
            // 
            this.pb_Back.Image = ((System.Drawing.Image)(resources.GetObject("pb_Back.Image")));
            this.pb_Back.Location = new System.Drawing.Point(13, 22);
            this.pb_Back.Name = "pb_Back";
            this.pb_Back.Size = new System.Drawing.Size(100, 50);
            this.pb_Back.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pb_Back.TabIndex = 1;
            this.pb_Back.TabStop = false;
            this.pb_Back.Click += new System.EventHandler(this.pb_Back_Click);
            // 
            // lbl_Header
            // 
            this.lbl_Header.AutoSize = true;
            this.lbl_Header.Font = new System.Drawing.Font("Lucida Bright", 27.75F, System.Drawing.FontStyle.Bold);
            this.lbl_Header.ForeColor = System.Drawing.Color.LavenderBlush;
            this.lbl_Header.Location = new System.Drawing.Point(576, 30);
            this.lbl_Header.Name = "lbl_Header";
            this.lbl_Header.Size = new System.Drawing.Size(209, 42);
            this.lbl_Header.TabIndex = 0;
            this.lbl_Header.Text = "Add Stock";
            // 
            // cb_Category
            // 
            this.cb_Category.Font = new System.Drawing.Font("Lucida Bright", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cb_Category.FormattingEnabled = true;
            this.cb_Category.Location = new System.Drawing.Point(243, 45);
            this.cb_Category.Name = "cb_Category";
            this.cb_Category.Size = new System.Drawing.Size(254, 30);
            this.cb_Category.TabIndex = 1;
            this.cb_Category.SelectedIndexChanged += new System.EventHandler(this.cb_Category_SelectedIndexChanged);
            // 
            // dtp_Date
            // 
            this.dtp_Date.Enabled = false;
            this.dtp_Date.Font = new System.Drawing.Font("Lucida Bright", 14.25F);
            this.dtp_Date.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtp_Date.Location = new System.Drawing.Point(708, 465);
            this.dtp_Date.Name = "dtp_Date";
            this.dtp_Date.Size = new System.Drawing.Size(254, 30);
            this.dtp_Date.TabIndex = 7;
            // 
            // tb_Current_Stock
            // 
            this.tb_Current_Stock.Enabled = false;
            this.tb_Current_Stock.Location = new System.Drawing.Point(708, 338);
            this.tb_Current_Stock.Name = "tb_Current_Stock";
            this.tb_Current_Stock.Size = new System.Drawing.Size(254, 29);
            this.tb_Current_Stock.TabIndex = 8;
            // 
            // lbl_Subcategory
            // 
            this.lbl_Subcategory.AutoSize = true;
            this.lbl_Subcategory.BackColor = System.Drawing.Color.SeaShell;
            this.lbl_Subcategory.Font = new System.Drawing.Font("Lucida Bright", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Subcategory.ForeColor = System.Drawing.Color.DarkRed;
            this.lbl_Subcategory.Location = new System.Drawing.Point(550, 48);
            this.lbl_Subcategory.Name = "lbl_Subcategory";
            this.lbl_Subcategory.Size = new System.Drawing.Size(123, 22);
            this.lbl_Subcategory.TabIndex = 8;
            this.lbl_Subcategory.Text = "Subcategory";
            // 
            // tb_New_Stock_Quantity
            // 
            this.tb_New_Stock_Quantity.Font = new System.Drawing.Font("Lucida Bright", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_New_Stock_Quantity.Location = new System.Drawing.Point(708, 399);
            this.tb_New_Stock_Quantity.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.tb_New_Stock_Quantity.Name = "tb_New_Stock_Quantity";
            this.tb_New_Stock_Quantity.Size = new System.Drawing.Size(254, 30);
            this.tb_New_Stock_Quantity.TabIndex = 4;
            this.tb_New_Stock_Quantity.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tb_New_Stock_Quantity_KeyPress);
            // 
            // lbl_Category
            // 
            this.lbl_Category.AutoSize = true;
            this.lbl_Category.BackColor = System.Drawing.Color.SeaShell;
            this.lbl_Category.Font = new System.Drawing.Font("Lucida Bright", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Category.ForeColor = System.Drawing.Color.DarkRed;
            this.lbl_Category.Location = new System.Drawing.Point(41, 51);
            this.lbl_Category.Name = "lbl_Category";
            this.lbl_Category.Size = new System.Drawing.Size(93, 22);
            this.lbl_Category.TabIndex = 6;
            this.lbl_Category.Text = "Category";
            // 
            // lbl_Product_Name
            // 
            this.lbl_Product_Name.AutoSize = true;
            this.lbl_Product_Name.BackColor = System.Drawing.Color.SeaShell;
            this.lbl_Product_Name.Font = new System.Drawing.Font("Lucida Bright", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Product_Name.ForeColor = System.Drawing.Color.DarkRed;
            this.lbl_Product_Name.Location = new System.Drawing.Point(41, 145);
            this.lbl_Product_Name.Name = "lbl_Product_Name";
            this.lbl_Product_Name.Size = new System.Drawing.Size(141, 22);
            this.lbl_Product_Name.TabIndex = 5;
            this.lbl_Product_Name.Text = "Product Name";
            // 
            // btn_Submit
            // 
            this.btn_Submit.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.btn_Submit.Font = new System.Drawing.Font("Lucida Bright", 27.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Submit.ForeColor = System.Drawing.Color.White;
            this.btn_Submit.Location = new System.Drawing.Point(403, 628);
            this.btn_Submit.Name = "btn_Submit";
            this.btn_Submit.Size = new System.Drawing.Size(170, 56);
            this.btn_Submit.TabIndex = 16;
            this.btn_Submit.Text = "Submit";
            this.btn_Submit.UseVisualStyleBackColor = false;
            this.btn_Submit.Click += new System.EventHandler(this.btn_Submit_Click);
            // 
            // lbl_Product_ID
            // 
            this.lbl_Product_ID.AutoSize = true;
            this.lbl_Product_ID.BackColor = System.Drawing.Color.SeaShell;
            this.lbl_Product_ID.Font = new System.Drawing.Font("Lucida Bright", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Product_ID.ForeColor = System.Drawing.Color.DarkRed;
            this.lbl_Product_ID.Location = new System.Drawing.Point(557, 145);
            this.lbl_Product_ID.Name = "lbl_Product_ID";
            this.lbl_Product_ID.Size = new System.Drawing.Size(108, 22);
            this.lbl_Product_ID.TabIndex = 5;
            this.lbl_Product_ID.Text = "Product ID";
            // 
            // lbl_Date
            // 
            this.lbl_Date.AutoSize = true;
            this.lbl_Date.BackColor = System.Drawing.Color.SeaShell;
            this.lbl_Date.Font = new System.Drawing.Font("Lucida Bright", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Date.ForeColor = System.Drawing.Color.DarkRed;
            this.lbl_Date.Location = new System.Drawing.Point(442, 465);
            this.lbl_Date.Name = "lbl_Date";
            this.lbl_Date.Size = new System.Drawing.Size(52, 22);
            this.lbl_Date.TabIndex = 6;
            this.lbl_Date.Text = "Date";
            // 
            // lbl_Current_Stock_Quantity
            // 
            this.lbl_Current_Stock_Quantity.AutoSize = true;
            this.lbl_Current_Stock_Quantity.BackColor = System.Drawing.Color.SeaShell;
            this.lbl_Current_Stock_Quantity.Font = new System.Drawing.Font("Lucida Bright", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Current_Stock_Quantity.ForeColor = System.Drawing.Color.DarkRed;
            this.lbl_Current_Stock_Quantity.Location = new System.Drawing.Point(395, 337);
            this.lbl_Current_Stock_Quantity.Name = "lbl_Current_Stock_Quantity";
            this.lbl_Current_Stock_Quantity.Size = new System.Drawing.Size(224, 22);
            this.lbl_Current_Stock_Quantity.TabIndex = 6;
            this.lbl_Current_Stock_Quantity.Text = "Current Stock Quantity";
            // 
            // cb_Subcategory
            // 
            this.cb_Subcategory.Font = new System.Drawing.Font("Lucida Bright", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cb_Subcategory.FormattingEnabled = true;
            this.cb_Subcategory.Location = new System.Drawing.Point(752, 45);
            this.cb_Subcategory.Name = "cb_Subcategory";
            this.cb_Subcategory.Size = new System.Drawing.Size(254, 30);
            this.cb_Subcategory.TabIndex = 2;
            this.cb_Subcategory.SelectedIndexChanged += new System.EventHandler(this.cb_Subcategory_SelectedIndexChanged);
            // 
            // cb_Product_Name
            // 
            this.cb_Product_Name.Font = new System.Drawing.Font("Lucida Bright", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cb_Product_Name.FormattingEnabled = true;
            this.cb_Product_Name.Location = new System.Drawing.Point(243, 140);
            this.cb_Product_Name.Name = "cb_Product_Name";
            this.cb_Product_Name.Size = new System.Drawing.Size(254, 30);
            this.cb_Product_Name.TabIndex = 3;
            this.cb_Product_Name.SelectedIndexChanged += new System.EventHandler(this.cb_Product_Name_SelectedIndexChanged);
            // 
            // btn_Refresh
            // 
            this.btn_Refresh.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.btn_Refresh.Font = new System.Drawing.Font("Lucida Bright", 27.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Refresh.ForeColor = System.Drawing.Color.White;
            this.btn_Refresh.Location = new System.Drawing.Point(778, 628);
            this.btn_Refresh.Name = "btn_Refresh";
            this.btn_Refresh.Size = new System.Drawing.Size(170, 56);
            this.btn_Refresh.TabIndex = 17;
            this.btn_Refresh.Text = "Refresh";
            this.btn_Refresh.UseVisualStyleBackColor = false;
            this.btn_Refresh.Click += new System.EventHandler(this.btn_Refresh_Click);
            // 
            // tb_Product_ID
            // 
            this.tb_Product_ID.Enabled = false;
            this.tb_Product_ID.Location = new System.Drawing.Point(752, 138);
            this.tb_Product_ID.Name = "tb_Product_ID";
            this.tb_Product_ID.Size = new System.Drawing.Size(254, 29);
            this.tb_Product_ID.TabIndex = 8;
            this.tb_Product_ID.TextChanged += new System.EventHandler(this.tb_Product_ID_TextChanged);
            // 
            // gb_Stock_Details
            // 
            this.gb_Stock_Details.Controls.Add(this.tb_Current_Stock);
            this.gb_Stock_Details.Controls.Add(this.dtp_Date);
            this.gb_Stock_Details.Controls.Add(this.tb_New_Stock_Quantity);
            this.gb_Stock_Details.Controls.Add(this.lbl_Date);
            this.gb_Stock_Details.Controls.Add(this.lbl_Current_Stock_Quantity);
            this.gb_Stock_Details.Controls.Add(this.lbl_New_Stock_Quantity);
            this.gb_Stock_Details.Controls.Add(this.pnl_Stock_Details);
            this.gb_Stock_Details.Font = new System.Drawing.Font("Georgia", 14.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))));
            this.gb_Stock_Details.Location = new System.Drawing.Point(13, 104);
            this.gb_Stock_Details.Name = "gb_Stock_Details";
            this.gb_Stock_Details.Size = new System.Drawing.Size(1320, 518);
            this.gb_Stock_Details.TabIndex = 15;
            this.gb_Stock_Details.TabStop = false;
            this.gb_Stock_Details.Text = "Stock Details";
            // 
            // lbl_New_Stock_Quantity
            // 
            this.lbl_New_Stock_Quantity.AutoSize = true;
            this.lbl_New_Stock_Quantity.BackColor = System.Drawing.Color.SeaShell;
            this.lbl_New_Stock_Quantity.Font = new System.Drawing.Font("Lucida Bright", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_New_Stock_Quantity.ForeColor = System.Drawing.Color.DarkRed;
            this.lbl_New_Stock_Quantity.Location = new System.Drawing.Point(395, 402);
            this.lbl_New_Stock_Quantity.Name = "lbl_New_Stock_Quantity";
            this.lbl_New_Stock_Quantity.Size = new System.Drawing.Size(191, 22);
            this.lbl_New_Stock_Quantity.TabIndex = 5;
            this.lbl_New_Stock_Quantity.Text = "New Stock Quantity";
            // 
            // pnl_Stock_Details
            // 
            this.pnl_Stock_Details.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.pnl_Stock_Details.BackColor = System.Drawing.Color.Silver;
            this.pnl_Stock_Details.Controls.Add(this.tb_Product_ID);
            this.pnl_Stock_Details.Controls.Add(this.cb_Product_Name);
            this.pnl_Stock_Details.Controls.Add(this.cb_Subcategory);
            this.pnl_Stock_Details.Controls.Add(this.cb_Category);
            this.pnl_Stock_Details.Controls.Add(this.lbl_Subcategory);
            this.pnl_Stock_Details.Controls.Add(this.lbl_Category);
            this.pnl_Stock_Details.Controls.Add(this.lbl_Product_ID);
            this.pnl_Stock_Details.Controls.Add(this.lbl_Product_Name);
            this.pnl_Stock_Details.Location = new System.Drawing.Point(147, 59);
            this.pnl_Stock_Details.Name = "pnl_Stock_Details";
            this.pnl_Stock_Details.Size = new System.Drawing.Size(1021, 243);
            this.pnl_Stock_Details.TabIndex = 0;
            // 
            // frm_Add_Stock
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(15F, 28F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.ClientSize = new System.Drawing.Size(1344, 712);
            this.Controls.Add(this.pnl_Add_Stock);
            this.Controls.Add(this.btn_Submit);
            this.Controls.Add(this.btn_Refresh);
            this.Controls.Add(this.gb_Stock_Details);
            this.Font = new System.Drawing.Font("Lucida Bright", 18F);
            this.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.Margin = new System.Windows.Forms.Padding(8, 6, 8, 6);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "frm_Add_Stock";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Add Stock";
            this.Load += new System.EventHandler(this.frm_Add_Stock_Load);
            this.pnl_Add_Stock.ResumeLayout(false);
            this.pnl_Add_Stock.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pb_Close)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_Back)).EndInit();
            this.gb_Stock_Details.ResumeLayout(false);
            this.gb_Stock_Details.PerformLayout();
            this.pnl_Stock_Details.ResumeLayout(false);
            this.pnl_Stock_Details.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel pnl_Add_Stock;
        private System.Windows.Forms.PictureBox pb_Close;
        private System.Windows.Forms.PictureBox pb_Back;
        private System.Windows.Forms.Label lbl_Header;
        private System.Windows.Forms.ComboBox cb_Category;
        private System.Windows.Forms.DateTimePicker dtp_Date;
        private System.Windows.Forms.TextBox tb_Current_Stock;
        private System.Windows.Forms.Label lbl_Subcategory;
        private System.Windows.Forms.TextBox tb_New_Stock_Quantity;
        private System.Windows.Forms.Label lbl_Category;
        private System.Windows.Forms.Label lbl_Product_Name;
        private System.Windows.Forms.Button btn_Submit;
        private System.Windows.Forms.Label lbl_Product_ID;
        private System.Windows.Forms.Label lbl_Date;
        private System.Windows.Forms.Label lbl_Current_Stock_Quantity;
        private System.Windows.Forms.ComboBox cb_Subcategory;
        private System.Windows.Forms.ComboBox cb_Product_Name;
        private System.Windows.Forms.Button btn_Refresh;
        private System.Windows.Forms.TextBox tb_Product_ID;
        private System.Windows.Forms.GroupBox gb_Stock_Details;
        private System.Windows.Forms.Label lbl_New_Stock_Quantity;
        private System.Windows.Forms.Panel pnl_Stock_Details;
    }
}