﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Computer_And_Mobile_Shoppee_Management_System
{
    public partial class frm_Login : Form
    {
        Global_ClassFile Gobj = new Global_ClassFile();

        public frm_Login()
        {
            InitializeComponent();
        }

        private void tb_Username_TextChanged_1(object sender, EventArgs e)
        {
            tb_Password.Enabled = true;
        }

        private void tb_Password_TextChanged_1(object sender, EventArgs e)
        {
            btn_Submit.Enabled = true;
        }

        private void frm_Login_Load(object sender, EventArgs e)
        {
            tb_Username.Focus();
        }

        private void btn_Submit_Click_1(object sender, EventArgs e)
        {
            Gobj.ConnectDB();

            SqlCommand cmd = new SqlCommand("Select Count(*) From Login_Details Where Username = '" + tb_Username.Text + "' And Password = '" + tb_Password.Text + "' ", Gobj.Con);

            if (Convert.ToInt32(cmd.ExecuteScalar()) > 0)
            {
                DialogResult Result = MessageBox.Show("Welcome To The Shree Mobile & Computer Shoppee", "Login Successfull", MessageBoxButtons.OKCancel, MessageBoxIcon.Asterisk);

                if (Result == DialogResult.OK)
                {
                    Global_ClassFile.Uname = tb_Username.Text;

                    frm_Entry_Form Obj = new frm_Entry_Form();
                    Obj.Show();
                    this.Hide();
                }
                else
                {
                    this.Show();
                }
            }
            else
            {
                DialogResult Result = MessageBox.Show("Invalid Username Or Password", "Something Went Wrong", MessageBoxButtons.OKCancel, MessageBoxIcon.Error);
            }

            tb_Username.Text = "";
            tb_Password.Text = "";
            tb_Username.Focus();

            Gobj.DisconnectDB();
        }
    }
}
