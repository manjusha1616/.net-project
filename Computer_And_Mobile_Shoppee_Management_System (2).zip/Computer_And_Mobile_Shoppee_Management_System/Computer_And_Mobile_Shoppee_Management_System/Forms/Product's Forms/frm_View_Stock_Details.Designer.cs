﻿namespace Computer_And_Mobile_Shoppee_Management_System
{
    partial class frm_View_Stock_Details
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frm_View_Stock_Details));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            this.pb_Back = new System.Windows.Forms.PictureBox();
            this.cb_Subcategory_Name = new System.Windows.Forms.ComboBox();
            this.lbl_Header = new System.Windows.Forms.Label();
            this.pb_Close = new System.Windows.Forms.PictureBox();
            this.lbl_Subcategory_Name = new System.Windows.Forms.Label();
            this.btn_Refresh = new System.Windows.Forms.Button();
            this.lbl_Category_Name = new System.Windows.Forms.Label();
            this.cb_Product_Name = new System.Windows.Forms.ComboBox();
            this.pnl_View_Stock = new System.Windows.Forms.Panel();
            this.cb_Category_Name = new System.Windows.Forms.ComboBox();
            this.pnl_Stock_Details = new System.Windows.Forms.Panel();
            this.lbl_Product_Name = new System.Windows.Forms.Label();
            this.gb_Stock_Details = new System.Windows.Forms.GroupBox();
            this.dgv_View_Stock_Details = new System.Windows.Forms.DataGridView();
            this.productIDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.categoryDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.subcategoryDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.productNameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dateDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.stockQuantityDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.stockDetailsBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.computer_And_Mob_Shoppee_Mgt_Sys_DBDataSet = new Computer_And_Mobile_Shoppee_Management_System.Computer_And_Mob_Shoppee_Mgt_Sys_DBDataSet();
            this.stock_DetailsTableAdapter = new Computer_And_Mobile_Shoppee_Management_System.Computer_And_Mob_Shoppee_Mgt_Sys_DBDataSetTableAdapters.Stock_DetailsTableAdapter();
            ((System.ComponentModel.ISupportInitialize)(this.pb_Back)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_Close)).BeginInit();
            this.pnl_View_Stock.SuspendLayout();
            this.pnl_Stock_Details.SuspendLayout();
            this.gb_Stock_Details.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_View_Stock_Details)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.stockDetailsBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.computer_And_Mob_Shoppee_Mgt_Sys_DBDataSet)).BeginInit();
            this.SuspendLayout();
            // 
            // pb_Back
            // 
            this.pb_Back.Image = ((System.Drawing.Image)(resources.GetObject("pb_Back.Image")));
            this.pb_Back.Location = new System.Drawing.Point(11, 31);
            this.pb_Back.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pb_Back.Name = "pb_Back";
            this.pb_Back.Size = new System.Drawing.Size(93, 52);
            this.pb_Back.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pb_Back.TabIndex = 1;
            this.pb_Back.TabStop = false;
            this.pb_Back.Click += new System.EventHandler(this.pb_Back_Click);
            // 
            // cb_Subcategory_Name
            // 
            this.cb_Subcategory_Name.FormattingEnabled = true;
            this.cb_Subcategory_Name.Location = new System.Drawing.Point(409, 75);
            this.cb_Subcategory_Name.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.cb_Subcategory_Name.Name = "cb_Subcategory_Name";
            this.cb_Subcategory_Name.Size = new System.Drawing.Size(246, 31);
            this.cb_Subcategory_Name.TabIndex = 3;
            this.cb_Subcategory_Name.SelectedIndexChanged += new System.EventHandler(this.cb_Subcategory_Name_SelectedIndexChanged);
            // 
            // lbl_Header
            // 
            this.lbl_Header.AutoSize = true;
            this.lbl_Header.Font = new System.Drawing.Font("Lucida Bright", 27.75F, System.Drawing.FontStyle.Bold);
            this.lbl_Header.ForeColor = System.Drawing.Color.LavenderBlush;
            this.lbl_Header.Location = new System.Drawing.Point(462, 31);
            this.lbl_Header.Name = "lbl_Header";
            this.lbl_Header.Size = new System.Drawing.Size(363, 42);
            this.lbl_Header.TabIndex = 0;
            this.lbl_Header.Text = "View Stock Details";
            // 
            // pb_Close
            // 
            this.pb_Close.Image = ((System.Drawing.Image)(resources.GetObject("pb_Close.Image")));
            this.pb_Close.Location = new System.Drawing.Point(1232, 21);
            this.pb_Close.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pb_Close.Name = "pb_Close";
            this.pb_Close.Size = new System.Drawing.Size(98, 52);
            this.pb_Close.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pb_Close.TabIndex = 2;
            this.pb_Close.TabStop = false;
            this.pb_Close.Click += new System.EventHandler(this.pb_Close_Click);
            // 
            // lbl_Subcategory_Name
            // 
            this.lbl_Subcategory_Name.AutoSize = true;
            this.lbl_Subcategory_Name.BackColor = System.Drawing.Color.SeaShell;
            this.lbl_Subcategory_Name.Font = new System.Drawing.Font("Lucida Bright", 14.25F);
            this.lbl_Subcategory_Name.ForeColor = System.Drawing.Color.DarkRed;
            this.lbl_Subcategory_Name.Location = new System.Drawing.Point(119, 75);
            this.lbl_Subcategory_Name.Name = "lbl_Subcategory_Name";
            this.lbl_Subcategory_Name.Size = new System.Drawing.Size(182, 22);
            this.lbl_Subcategory_Name.TabIndex = 0;
            this.lbl_Subcategory_Name.Text = "Subcategory Name";
            // 
            // btn_Refresh
            // 
            this.btn_Refresh.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.btn_Refresh.Font = new System.Drawing.Font("Lucida Bright", 27.75F, System.Drawing.FontStyle.Bold);
            this.btn_Refresh.ForeColor = System.Drawing.Color.White;
            this.btn_Refresh.Location = new System.Drawing.Point(774, 56);
            this.btn_Refresh.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btn_Refresh.Name = "btn_Refresh";
            this.btn_Refresh.Size = new System.Drawing.Size(169, 54);
            this.btn_Refresh.TabIndex = 5;
            this.btn_Refresh.Text = "Refresh";
            this.btn_Refresh.UseVisualStyleBackColor = false;
            this.btn_Refresh.Click += new System.EventHandler(this.btn_Refresh_Click);
            // 
            // lbl_Category_Name
            // 
            this.lbl_Category_Name.AutoSize = true;
            this.lbl_Category_Name.BackColor = System.Drawing.Color.SeaShell;
            this.lbl_Category_Name.Font = new System.Drawing.Font("Lucida Bright", 14.25F);
            this.lbl_Category_Name.ForeColor = System.Drawing.Color.DarkRed;
            this.lbl_Category_Name.Location = new System.Drawing.Point(119, 19);
            this.lbl_Category_Name.Name = "lbl_Category_Name";
            this.lbl_Category_Name.Size = new System.Drawing.Size(152, 22);
            this.lbl_Category_Name.TabIndex = 0;
            this.lbl_Category_Name.Text = "Category Name";
            // 
            // cb_Product_Name
            // 
            this.cb_Product_Name.FormattingEnabled = true;
            this.cb_Product_Name.Location = new System.Drawing.Point(409, 132);
            this.cb_Product_Name.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.cb_Product_Name.Name = "cb_Product_Name";
            this.cb_Product_Name.Size = new System.Drawing.Size(246, 31);
            this.cb_Product_Name.TabIndex = 1;
            this.cb_Product_Name.SelectedIndexChanged += new System.EventHandler(this.cb_Product_Name_SelectedIndexChanged);
            // 
            // pnl_View_Stock
            // 
            this.pnl_View_Stock.BackColor = System.Drawing.Color.Indigo;
            this.pnl_View_Stock.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pnl_View_Stock.Controls.Add(this.pb_Close);
            this.pnl_View_Stock.Controls.Add(this.pb_Back);
            this.pnl_View_Stock.Controls.Add(this.lbl_Header);
            this.pnl_View_Stock.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnl_View_Stock.Location = new System.Drawing.Point(0, 0);
            this.pnl_View_Stock.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pnl_View_Stock.Name = "pnl_View_Stock";
            this.pnl_View_Stock.Size = new System.Drawing.Size(1344, 101);
            this.pnl_View_Stock.TabIndex = 6;
            // 
            // cb_Category_Name
            // 
            this.cb_Category_Name.FormattingEnabled = true;
            this.cb_Category_Name.Location = new System.Drawing.Point(409, 18);
            this.cb_Category_Name.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.cb_Category_Name.Name = "cb_Category_Name";
            this.cb_Category_Name.Size = new System.Drawing.Size(246, 31);
            this.cb_Category_Name.TabIndex = 2;
            this.cb_Category_Name.SelectedIndexChanged += new System.EventHandler(this.cb_Category_Name_SelectedIndexChanged);
            // 
            // pnl_Stock_Details
            // 
            this.pnl_Stock_Details.BackColor = System.Drawing.Color.Silver;
            this.pnl_Stock_Details.Controls.Add(this.cb_Subcategory_Name);
            this.pnl_Stock_Details.Controls.Add(this.lbl_Subcategory_Name);
            this.pnl_Stock_Details.Controls.Add(this.btn_Refresh);
            this.pnl_Stock_Details.Controls.Add(this.lbl_Category_Name);
            this.pnl_Stock_Details.Controls.Add(this.cb_Product_Name);
            this.pnl_Stock_Details.Controls.Add(this.cb_Category_Name);
            this.pnl_Stock_Details.Controls.Add(this.lbl_Product_Name);
            this.pnl_Stock_Details.Font = new System.Drawing.Font("Georgia", 14.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))));
            this.pnl_Stock_Details.Location = new System.Drawing.Point(99, 141);
            this.pnl_Stock_Details.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pnl_Stock_Details.Name = "pnl_Stock_Details";
            this.pnl_Stock_Details.Size = new System.Drawing.Size(1107, 178);
            this.pnl_Stock_Details.TabIndex = 7;
            // 
            // lbl_Product_Name
            // 
            this.lbl_Product_Name.AutoSize = true;
            this.lbl_Product_Name.BackColor = System.Drawing.Color.SeaShell;
            this.lbl_Product_Name.Font = new System.Drawing.Font("Lucida Bright", 14.25F);
            this.lbl_Product_Name.ForeColor = System.Drawing.Color.DarkRed;
            this.lbl_Product_Name.Location = new System.Drawing.Point(119, 133);
            this.lbl_Product_Name.Name = "lbl_Product_Name";
            this.lbl_Product_Name.Size = new System.Drawing.Size(141, 22);
            this.lbl_Product_Name.TabIndex = 0;
            this.lbl_Product_Name.Text = "Product Name";
            // 
            // gb_Stock_Details
            // 
            this.gb_Stock_Details.Controls.Add(this.dgv_View_Stock_Details);
            this.gb_Stock_Details.Font = new System.Drawing.Font("Georgia", 14.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))));
            this.gb_Stock_Details.ForeColor = System.Drawing.Color.Black;
            this.gb_Stock_Details.Location = new System.Drawing.Point(11, 346);
            this.gb_Stock_Details.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.gb_Stock_Details.Name = "gb_Stock_Details";
            this.gb_Stock_Details.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.gb_Stock_Details.Size = new System.Drawing.Size(1321, 355);
            this.gb_Stock_Details.TabIndex = 8;
            this.gb_Stock_Details.TabStop = false;
            this.gb_Stock_Details.Text = "Stock Details";
            // 
            // dgv_View_Stock_Details
            // 
            this.dgv_View_Stock_Details.AllowUserToAddRows = false;
            this.dgv_View_Stock_Details.AllowUserToDeleteRows = false;
            this.dgv_View_Stock_Details.AutoGenerateColumns = false;
            this.dgv_View_Stock_Details.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Georgia", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgv_View_Stock_Details.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dgv_View_Stock_Details.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv_View_Stock_Details.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.productIDDataGridViewTextBoxColumn,
            this.categoryDataGridViewTextBoxColumn,
            this.subcategoryDataGridViewTextBoxColumn,
            this.productNameDataGridViewTextBoxColumn,
            this.dateDataGridViewTextBoxColumn,
            this.stockQuantityDataGridViewTextBoxColumn});
            this.dgv_View_Stock_Details.DataSource = this.stockDetailsBindingSource;
            this.dgv_View_Stock_Details.Location = new System.Drawing.Point(24, 52);
            this.dgv_View_Stock_Details.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.dgv_View_Stock_Details.Name = "dgv_View_Stock_Details";
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Georgia", 14.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))));
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgv_View_Stock_Details.RowHeadersDefaultCellStyle = dataGridViewCellStyle2;
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dgv_View_Stock_Details.RowsDefaultCellStyle = dataGridViewCellStyle3;
            this.dgv_View_Stock_Details.Size = new System.Drawing.Size(1277, 273);
            this.dgv_View_Stock_Details.TabIndex = 0;
            // 
            // productIDDataGridViewTextBoxColumn
            // 
            this.productIDDataGridViewTextBoxColumn.DataPropertyName = "Product_ID";
            this.productIDDataGridViewTextBoxColumn.HeaderText = "Product_ID";
            this.productIDDataGridViewTextBoxColumn.Name = "productIDDataGridViewTextBoxColumn";
            // 
            // categoryDataGridViewTextBoxColumn
            // 
            this.categoryDataGridViewTextBoxColumn.DataPropertyName = "Category";
            this.categoryDataGridViewTextBoxColumn.HeaderText = "Category";
            this.categoryDataGridViewTextBoxColumn.Name = "categoryDataGridViewTextBoxColumn";
            // 
            // subcategoryDataGridViewTextBoxColumn
            // 
            this.subcategoryDataGridViewTextBoxColumn.DataPropertyName = "Subcategory";
            this.subcategoryDataGridViewTextBoxColumn.HeaderText = "Subcategory";
            this.subcategoryDataGridViewTextBoxColumn.Name = "subcategoryDataGridViewTextBoxColumn";
            // 
            // productNameDataGridViewTextBoxColumn
            // 
            this.productNameDataGridViewTextBoxColumn.DataPropertyName = "Product_Name";
            this.productNameDataGridViewTextBoxColumn.HeaderText = "Product_Name";
            this.productNameDataGridViewTextBoxColumn.Name = "productNameDataGridViewTextBoxColumn";
            // 
            // dateDataGridViewTextBoxColumn
            // 
            this.dateDataGridViewTextBoxColumn.DataPropertyName = "Date";
            this.dateDataGridViewTextBoxColumn.HeaderText = "Date";
            this.dateDataGridViewTextBoxColumn.Name = "dateDataGridViewTextBoxColumn";
            // 
            // stockQuantityDataGridViewTextBoxColumn
            // 
            this.stockQuantityDataGridViewTextBoxColumn.DataPropertyName = "Stock_Quantity";
            this.stockQuantityDataGridViewTextBoxColumn.HeaderText = "Stock_Quantity";
            this.stockQuantityDataGridViewTextBoxColumn.Name = "stockQuantityDataGridViewTextBoxColumn";
            // 
            // stockDetailsBindingSource
            // 
            this.stockDetailsBindingSource.DataMember = "Stock_Details";
            this.stockDetailsBindingSource.DataSource = this.computer_And_Mob_Shoppee_Mgt_Sys_DBDataSet;
            // 
            // computer_And_Mob_Shoppee_Mgt_Sys_DBDataSet
            // 
            this.computer_And_Mob_Shoppee_Mgt_Sys_DBDataSet.DataSetName = "Computer_And_Mob_Shoppee_Mgt_Sys_DBDataSet";
            this.computer_And_Mob_Shoppee_Mgt_Sys_DBDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // stock_DetailsTableAdapter
            // 
            this.stock_DetailsTableAdapter.ClearBeforeFill = true;
            // 
            // frm_View_Stock_Details
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(14F, 29F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.ClientSize = new System.Drawing.Size(1344, 712);
            this.Controls.Add(this.gb_Stock_Details);
            this.Controls.Add(this.pnl_View_Stock);
            this.Controls.Add(this.pnl_Stock_Details);
            this.Font = new System.Drawing.Font("Georgia", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.Margin = new System.Windows.Forms.Padding(7, 6, 7, 6);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "frm_View_Stock_Details";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "View Stock Details";
            this.Load += new System.EventHandler(this.frm_View_Stock_Details_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pb_Back)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_Close)).EndInit();
            this.pnl_View_Stock.ResumeLayout(false);
            this.pnl_View_Stock.PerformLayout();
            this.pnl_Stock_Details.ResumeLayout(false);
            this.pnl_Stock_Details.PerformLayout();
            this.gb_Stock_Details.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgv_View_Stock_Details)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.stockDetailsBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.computer_And_Mob_Shoppee_Mgt_Sys_DBDataSet)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.PictureBox pb_Back;
        private System.Windows.Forms.ComboBox cb_Subcategory_Name;
        private System.Windows.Forms.Label lbl_Header;
        private System.Windows.Forms.PictureBox pb_Close;
        private System.Windows.Forms.Label lbl_Subcategory_Name;
        private System.Windows.Forms.Button btn_Refresh;
        private System.Windows.Forms.Label lbl_Category_Name;
        private System.Windows.Forms.ComboBox cb_Product_Name;
        private System.Windows.Forms.Panel pnl_View_Stock;
        private System.Windows.Forms.ComboBox cb_Category_Name;
        private System.Windows.Forms.Panel pnl_Stock_Details;
        private System.Windows.Forms.Label lbl_Product_Name;
        private System.Windows.Forms.GroupBox gb_Stock_Details;
        private System.Windows.Forms.DataGridView dgv_View_Stock_Details;
        private Computer_And_Mob_Shoppee_Mgt_Sys_DBDataSet computer_And_Mob_Shoppee_Mgt_Sys_DBDataSet;
        private System.Windows.Forms.BindingSource stockDetailsBindingSource;
        private Computer_And_Mob_Shoppee_Mgt_Sys_DBDataSetTableAdapters.Stock_DetailsTableAdapter stock_DetailsTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn productIDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn categoryDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn subcategoryDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn productNameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn dateDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn stockQuantityDataGridViewTextBoxColumn;
    }
}