﻿namespace Computer_And_Mobile_Shoppee_Management_System
{
    partial class frm_Add_New_Employee
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frm_Add_New_Employee));
            this.gb_Gender = new System.Windows.Forms.GroupBox();
            this.rb_Female = new System.Windows.Forms.RadioButton();
            this.rb_Male = new System.Windows.Forms.RadioButton();
            this.dtp_Joining_Date = new System.Windows.Forms.DateTimePicker();
            this.dtp_DOB = new System.Windows.Forms.DateTimePicker();
            this.tb_Salary = new System.Windows.Forms.TextBox();
            this.tb_Email_ID = new System.Windows.Forms.TextBox();
            this.tb_Pan_No = new System.Windows.Forms.TextBox();
            this.tb_Aadhar_No = new System.Windows.Forms.TextBox();
            this.tb_Mob_No2 = new System.Windows.Forms.TextBox();
            this.btn_Save = new System.Windows.Forms.Button();
            this.tb_Mob_No1 = new System.Windows.Forms.TextBox();
            this.tb_Address = new System.Windows.Forms.TextBox();
            this.pb_Close = new System.Windows.Forms.PictureBox();
            this.tb_Emp_Name = new System.Windows.Forms.TextBox();
            this.pnl_Add_New_Employee = new System.Windows.Forms.Panel();
            this.pb_Back = new System.Windows.Forms.PictureBox();
            this.btn_Exit = new System.Windows.Forms.Button();
            this.lbl_Header = new System.Windows.Forms.Label();
            this.tb_Emp_ID = new System.Windows.Forms.TextBox();
            this.btn_Refresh = new System.Windows.Forms.Button();
            this.gb_Add_New_Employee = new System.Windows.Forms.GroupBox();
            this.lbl_Gender = new System.Windows.Forms.Label();
            this.lbl_Pan_No = new System.Windows.Forms.Label();
            this.lbl_Aadhar_No = new System.Windows.Forms.Label();
            this.lbl_Mob_No2 = new System.Windows.Forms.Label();
            this.lbl_Mob_No1 = new System.Windows.Forms.Label();
            this.lbl_Joining_Date = new System.Windows.Forms.Label();
            this.lbl_Email_ID = new System.Windows.Forms.Label();
            this.lbl_Salary = new System.Windows.Forms.Label();
            this.lbl_Address = new System.Windows.Forms.Label();
            this.lbl_DOB = new System.Windows.Forms.Label();
            this.lbl_Emp_Name = new System.Windows.Forms.Label();
            this.lbl_Emp_ID = new System.Windows.Forms.Label();
            this.gb_Gender.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pb_Close)).BeginInit();
            this.pnl_Add_New_Employee.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pb_Back)).BeginInit();
            this.gb_Add_New_Employee.SuspendLayout();
            this.SuspendLayout();
            // 
            // gb_Gender
            // 
            this.gb_Gender.BackColor = System.Drawing.SystemColors.Window;
            this.gb_Gender.Controls.Add(this.rb_Female);
            this.gb_Gender.Controls.Add(this.rb_Male);
            this.gb_Gender.Font = new System.Drawing.Font("Lucida Bright", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gb_Gender.Location = new System.Drawing.Point(331, 254);
            this.gb_Gender.Name = "gb_Gender";
            this.gb_Gender.Size = new System.Drawing.Size(263, 39);
            this.gb_Gender.TabIndex = 3;
            this.gb_Gender.TabStop = false;
            // 
            // rb_Female
            // 
            this.rb_Female.AutoSize = true;
            this.rb_Female.Font = new System.Drawing.Font("Lucida Bright", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rb_Female.Location = new System.Drawing.Point(146, 8);
            this.rb_Female.Name = "rb_Female";
            this.rb_Female.Size = new System.Drawing.Size(81, 24);
            this.rb_Female.TabIndex = 0;
            this.rb_Female.TabStop = true;
            this.rb_Female.Text = "Female";
            this.rb_Female.UseVisualStyleBackColor = true;
            // 
            // rb_Male
            // 
            this.rb_Male.AutoSize = true;
            this.rb_Male.Font = new System.Drawing.Font("Lucida Bright", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rb_Male.Location = new System.Drawing.Point(40, 8);
            this.rb_Male.Name = "rb_Male";
            this.rb_Male.Size = new System.Drawing.Size(64, 24);
            this.rb_Male.TabIndex = 0;
            this.rb_Male.TabStop = true;
            this.rb_Male.Text = "Male";
            this.rb_Male.UseVisualStyleBackColor = true;
            // 
            // dtp_Joining_Date
            // 
            this.dtp_Joining_Date.Font = new System.Drawing.Font("Lucida Bright", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtp_Joining_Date.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtp_Joining_Date.Location = new System.Drawing.Point(1006, 53);
            this.dtp_Joining_Date.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.dtp_Joining_Date.Name = "dtp_Joining_Date";
            this.dtp_Joining_Date.Size = new System.Drawing.Size(263, 30);
            this.dtp_Joining_Date.TabIndex = 6;
            // 
            // dtp_DOB
            // 
            this.dtp_DOB.Font = new System.Drawing.Font("Lucida Bright", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtp_DOB.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtp_DOB.Location = new System.Drawing.Point(331, 188);
            this.dtp_DOB.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.dtp_DOB.Name = "dtp_DOB";
            this.dtp_DOB.Size = new System.Drawing.Size(263, 30);
            this.dtp_DOB.TabIndex = 2;
            // 
            // tb_Salary
            // 
            this.tb_Salary.Font = new System.Drawing.Font("Lucida Bright", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_Salary.Location = new System.Drawing.Point(1006, 417);
            this.tb_Salary.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.tb_Salary.Name = "tb_Salary";
            this.tb_Salary.Size = new System.Drawing.Size(263, 30);
            this.tb_Salary.TabIndex = 11;
            // 
            // tb_Email_ID
            // 
            this.tb_Email_ID.Font = new System.Drawing.Font("Lucida Bright", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_Email_ID.Location = new System.Drawing.Point(331, 415);
            this.tb_Email_ID.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.tb_Email_ID.Name = "tb_Email_ID";
            this.tb_Email_ID.Size = new System.Drawing.Size(263, 30);
            this.tb_Email_ID.TabIndex = 5;
            // 
            // tb_Pan_No
            // 
            this.tb_Pan_No.Font = new System.Drawing.Font("Lucida Bright", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_Pan_No.Location = new System.Drawing.Point(1006, 336);
            this.tb_Pan_No.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.tb_Pan_No.MaxLength = 10;
            this.tb_Pan_No.Name = "tb_Pan_No";
            this.tb_Pan_No.Size = new System.Drawing.Size(263, 30);
            this.tb_Pan_No.TabIndex = 10;
            // 
            // tb_Aadhar_No
            // 
            this.tb_Aadhar_No.Font = new System.Drawing.Font("Lucida Bright", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_Aadhar_No.Location = new System.Drawing.Point(1006, 263);
            this.tb_Aadhar_No.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.tb_Aadhar_No.MaxLength = 12;
            this.tb_Aadhar_No.Name = "tb_Aadhar_No";
            this.tb_Aadhar_No.Size = new System.Drawing.Size(263, 30);
            this.tb_Aadhar_No.TabIndex = 9;
            this.tb_Aadhar_No.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tb_Aadhar_No_KeyPress);
            // 
            // tb_Mob_No2
            // 
            this.tb_Mob_No2.Font = new System.Drawing.Font("Lucida Bright", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_Mob_No2.Location = new System.Drawing.Point(1006, 191);
            this.tb_Mob_No2.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.tb_Mob_No2.MaxLength = 10;
            this.tb_Mob_No2.Name = "tb_Mob_No2";
            this.tb_Mob_No2.Size = new System.Drawing.Size(263, 30);
            this.tb_Mob_No2.TabIndex = 8;
            this.tb_Mob_No2.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tb_Mob_No2_KeyPress);
            // 
            // btn_Save
            // 
            this.btn_Save.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.btn_Save.Font = new System.Drawing.Font("Lucida Bright", 27.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Save.ForeColor = System.Drawing.Color.White;
            this.btn_Save.Location = new System.Drawing.Point(354, 638);
            this.btn_Save.Name = "btn_Save";
            this.btn_Save.Size = new System.Drawing.Size(127, 56);
            this.btn_Save.TabIndex = 67;
            this.btn_Save.Text = "Save";
            this.btn_Save.UseVisualStyleBackColor = false;
            this.btn_Save.Click += new System.EventHandler(this.btn_Save_Click);
            // 
            // tb_Mob_No1
            // 
            this.tb_Mob_No1.Font = new System.Drawing.Font("Lucida Bright", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_Mob_No1.Location = new System.Drawing.Point(1006, 120);
            this.tb_Mob_No1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.tb_Mob_No1.MaxLength = 10;
            this.tb_Mob_No1.Name = "tb_Mob_No1";
            this.tb_Mob_No1.Size = new System.Drawing.Size(263, 30);
            this.tb_Mob_No1.TabIndex = 7;
            this.tb_Mob_No1.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tb_Mob_No1_KeyPress);
            // 
            // tb_Address
            // 
            this.tb_Address.Font = new System.Drawing.Font("Lucida Bright", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_Address.Location = new System.Drawing.Point(331, 341);
            this.tb_Address.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.tb_Address.MaxLength = 20;
            this.tb_Address.Name = "tb_Address";
            this.tb_Address.Size = new System.Drawing.Size(263, 30);
            this.tb_Address.TabIndex = 4;
            // 
            // pb_Close
            // 
            this.pb_Close.Image = ((System.Drawing.Image)(resources.GetObject("pb_Close.Image")));
            this.pb_Close.Location = new System.Drawing.Point(1232, 22);
            this.pb_Close.Name = "pb_Close";
            this.pb_Close.Size = new System.Drawing.Size(105, 55);
            this.pb_Close.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pb_Close.TabIndex = 4;
            this.pb_Close.TabStop = false;
            this.pb_Close.Click += new System.EventHandler(this.pb_Close_Click);
            // 
            // tb_Emp_Name
            // 
            this.tb_Emp_Name.Font = new System.Drawing.Font("Lucida Bright", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_Emp_Name.Location = new System.Drawing.Point(331, 116);
            this.tb_Emp_Name.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.tb_Emp_Name.MaxLength = 20;
            this.tb_Emp_Name.Name = "tb_Emp_Name";
            this.tb_Emp_Name.Size = new System.Drawing.Size(263, 30);
            this.tb_Emp_Name.TabIndex = 1;
            // 
            // pnl_Add_New_Employee
            // 
            this.pnl_Add_New_Employee.BackColor = System.Drawing.Color.Indigo;
            this.pnl_Add_New_Employee.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pnl_Add_New_Employee.Controls.Add(this.pb_Close);
            this.pnl_Add_New_Employee.Controls.Add(this.pb_Back);
            this.pnl_Add_New_Employee.Controls.Add(this.btn_Exit);
            this.pnl_Add_New_Employee.Controls.Add(this.lbl_Header);
            this.pnl_Add_New_Employee.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnl_Add_New_Employee.Location = new System.Drawing.Point(0, 0);
            this.pnl_Add_New_Employee.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.pnl_Add_New_Employee.Name = "pnl_Add_New_Employee";
            this.pnl_Add_New_Employee.Size = new System.Drawing.Size(1344, 98);
            this.pnl_Add_New_Employee.TabIndex = 66;
            // 
            // pb_Back
            // 
            this.pb_Back.Image = ((System.Drawing.Image)(resources.GetObject("pb_Back.Image")));
            this.pb_Back.Location = new System.Drawing.Point(13, 22);
            this.pb_Back.Name = "pb_Back";
            this.pb_Back.Size = new System.Drawing.Size(100, 50);
            this.pb_Back.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pb_Back.TabIndex = 3;
            this.pb_Back.TabStop = false;
            this.pb_Back.Click += new System.EventHandler(this.pb_Back_Click);
            // 
            // btn_Exit
            // 
            this.btn_Exit.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.btn_Exit.Font = new System.Drawing.Font("Lucida Bright", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Exit.ForeColor = System.Drawing.Color.White;
            this.btn_Exit.Location = new System.Drawing.Point(1402, 34);
            this.btn_Exit.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btn_Exit.Name = "btn_Exit";
            this.btn_Exit.Size = new System.Drawing.Size(106, 40);
            this.btn_Exit.TabIndex = 2;
            this.btn_Exit.Text = "Exit";
            this.btn_Exit.UseVisualStyleBackColor = false;
            // 
            // lbl_Header
            // 
            this.lbl_Header.AutoSize = true;
            this.lbl_Header.BackColor = System.Drawing.Color.Indigo;
            this.lbl_Header.Font = new System.Drawing.Font("Lucida Bright", 27.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Header.ForeColor = System.Drawing.Color.LavenderBlush;
            this.lbl_Header.Location = new System.Drawing.Point(503, 29);
            this.lbl_Header.Name = "lbl_Header";
            this.lbl_Header.Size = new System.Drawing.Size(383, 42);
            this.lbl_Header.TabIndex = 0;
            this.lbl_Header.Text = "Add New Employee";
            // 
            // tb_Emp_ID
            // 
            this.tb_Emp_ID.Enabled = false;
            this.tb_Emp_ID.Font = new System.Drawing.Font("Lucida Bright", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_Emp_ID.Location = new System.Drawing.Point(331, 51);
            this.tb_Emp_ID.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.tb_Emp_ID.Name = "tb_Emp_ID";
            this.tb_Emp_ID.Size = new System.Drawing.Size(263, 30);
            this.tb_Emp_ID.TabIndex = 0;
            // 
            // btn_Refresh
            // 
            this.btn_Refresh.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.btn_Refresh.Font = new System.Drawing.Font("Lucida Bright", 27.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Refresh.ForeColor = System.Drawing.Color.White;
            this.btn_Refresh.Location = new System.Drawing.Point(879, 635);
            this.btn_Refresh.Name = "btn_Refresh";
            this.btn_Refresh.Size = new System.Drawing.Size(170, 56);
            this.btn_Refresh.TabIndex = 68;
            this.btn_Refresh.Text = "Refresh";
            this.btn_Refresh.UseVisualStyleBackColor = false;
            this.btn_Refresh.Click += new System.EventHandler(this.btn_Refresh_Click);
            // 
            // gb_Add_New_Employee
            // 
            this.gb_Add_New_Employee.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.gb_Add_New_Employee.Controls.Add(this.gb_Gender);
            this.gb_Add_New_Employee.Controls.Add(this.dtp_Joining_Date);
            this.gb_Add_New_Employee.Controls.Add(this.dtp_DOB);
            this.gb_Add_New_Employee.Controls.Add(this.tb_Salary);
            this.gb_Add_New_Employee.Controls.Add(this.tb_Email_ID);
            this.gb_Add_New_Employee.Controls.Add(this.tb_Pan_No);
            this.gb_Add_New_Employee.Controls.Add(this.tb_Aadhar_No);
            this.gb_Add_New_Employee.Controls.Add(this.tb_Mob_No2);
            this.gb_Add_New_Employee.Controls.Add(this.tb_Mob_No1);
            this.gb_Add_New_Employee.Controls.Add(this.tb_Address);
            this.gb_Add_New_Employee.Controls.Add(this.tb_Emp_Name);
            this.gb_Add_New_Employee.Controls.Add(this.tb_Emp_ID);
            this.gb_Add_New_Employee.Controls.Add(this.lbl_Gender);
            this.gb_Add_New_Employee.Controls.Add(this.lbl_Pan_No);
            this.gb_Add_New_Employee.Controls.Add(this.lbl_Aadhar_No);
            this.gb_Add_New_Employee.Controls.Add(this.lbl_Mob_No2);
            this.gb_Add_New_Employee.Controls.Add(this.lbl_Mob_No1);
            this.gb_Add_New_Employee.Controls.Add(this.lbl_Joining_Date);
            this.gb_Add_New_Employee.Controls.Add(this.lbl_Email_ID);
            this.gb_Add_New_Employee.Controls.Add(this.lbl_Salary);
            this.gb_Add_New_Employee.Controls.Add(this.lbl_Address);
            this.gb_Add_New_Employee.Controls.Add(this.lbl_DOB);
            this.gb_Add_New_Employee.Controls.Add(this.lbl_Emp_Name);
            this.gb_Add_New_Employee.Controls.Add(this.lbl_Emp_ID);
            this.gb_Add_New_Employee.Font = new System.Drawing.Font("Georgia", 14.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))));
            this.gb_Add_New_Employee.ForeColor = System.Drawing.Color.Black;
            this.gb_Add_New_Employee.Location = new System.Drawing.Point(12, 105);
            this.gb_Add_New_Employee.Name = "gb_Add_New_Employee";
            this.gb_Add_New_Employee.Size = new System.Drawing.Size(1310, 507);
            this.gb_Add_New_Employee.TabIndex = 69;
            this.gb_Add_New_Employee.TabStop = false;
            this.gb_Add_New_Employee.Text = "Employee Details";
            // 
            // lbl_Gender
            // 
            this.lbl_Gender.AutoSize = true;
            this.lbl_Gender.BackColor = System.Drawing.Color.SeaShell;
            this.lbl_Gender.Font = new System.Drawing.Font("Lucida Bright", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Gender.ForeColor = System.Drawing.Color.DarkRed;
            this.lbl_Gender.Location = new System.Drawing.Point(60, 265);
            this.lbl_Gender.Name = "lbl_Gender";
            this.lbl_Gender.Size = new System.Drawing.Size(82, 23);
            this.lbl_Gender.TabIndex = 76;
            this.lbl_Gender.Text = "Gender";
            // 
            // lbl_Pan_No
            // 
            this.lbl_Pan_No.AutoSize = true;
            this.lbl_Pan_No.BackColor = System.Drawing.Color.SeaShell;
            this.lbl_Pan_No.Font = new System.Drawing.Font("Lucida Bright", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Pan_No.ForeColor = System.Drawing.Color.DarkRed;
            this.lbl_Pan_No.Location = new System.Drawing.Point(746, 343);
            this.lbl_Pan_No.Name = "lbl_Pan_No";
            this.lbl_Pan_No.Size = new System.Drawing.Size(135, 23);
            this.lbl_Pan_No.TabIndex = 75;
            this.lbl_Pan_No.Text = "Pan Card No";
            // 
            // lbl_Aadhar_No
            // 
            this.lbl_Aadhar_No.AutoSize = true;
            this.lbl_Aadhar_No.BackColor = System.Drawing.Color.SeaShell;
            this.lbl_Aadhar_No.Font = new System.Drawing.Font("Lucida Bright", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Aadhar_No.ForeColor = System.Drawing.Color.DarkRed;
            this.lbl_Aadhar_No.Location = new System.Drawing.Point(746, 270);
            this.lbl_Aadhar_No.Name = "lbl_Aadhar_No";
            this.lbl_Aadhar_No.Size = new System.Drawing.Size(172, 23);
            this.lbl_Aadhar_No.TabIndex = 74;
            this.lbl_Aadhar_No.Text = "Aadhar Card No";
            // 
            // lbl_Mob_No2
            // 
            this.lbl_Mob_No2.AutoSize = true;
            this.lbl_Mob_No2.BackColor = System.Drawing.Color.SeaShell;
            this.lbl_Mob_No2.Font = new System.Drawing.Font("Lucida Bright", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Mob_No2.ForeColor = System.Drawing.Color.DarkRed;
            this.lbl_Mob_No2.Location = new System.Drawing.Point(746, 193);
            this.lbl_Mob_No2.Name = "lbl_Mob_No2";
            this.lbl_Mob_No2.Size = new System.Drawing.Size(133, 23);
            this.lbl_Mob_No2.TabIndex = 73;
            this.lbl_Mob_No2.Text = "Mobile No 2";
            // 
            // lbl_Mob_No1
            // 
            this.lbl_Mob_No1.AutoSize = true;
            this.lbl_Mob_No1.BackColor = System.Drawing.Color.SeaShell;
            this.lbl_Mob_No1.Font = new System.Drawing.Font("Lucida Bright", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Mob_No1.ForeColor = System.Drawing.Color.DarkRed;
            this.lbl_Mob_No1.Location = new System.Drawing.Point(746, 122);
            this.lbl_Mob_No1.Name = "lbl_Mob_No1";
            this.lbl_Mob_No1.Size = new System.Drawing.Size(133, 23);
            this.lbl_Mob_No1.TabIndex = 72;
            this.lbl_Mob_No1.Text = "Mobile No 1";
            // 
            // lbl_Joining_Date
            // 
            this.lbl_Joining_Date.AutoSize = true;
            this.lbl_Joining_Date.BackColor = System.Drawing.Color.SeaShell;
            this.lbl_Joining_Date.Font = new System.Drawing.Font("Lucida Bright", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Joining_Date.ForeColor = System.Drawing.Color.DarkRed;
            this.lbl_Joining_Date.Location = new System.Drawing.Point(746, 53);
            this.lbl_Joining_Date.Name = "lbl_Joining_Date";
            this.lbl_Joining_Date.Size = new System.Drawing.Size(136, 23);
            this.lbl_Joining_Date.TabIndex = 71;
            this.lbl_Joining_Date.Text = "Joining Date";
            // 
            // lbl_Email_ID
            // 
            this.lbl_Email_ID.AutoSize = true;
            this.lbl_Email_ID.BackColor = System.Drawing.Color.SeaShell;
            this.lbl_Email_ID.Font = new System.Drawing.Font("Lucida Bright", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Email_ID.ForeColor = System.Drawing.Color.DarkRed;
            this.lbl_Email_ID.Location = new System.Drawing.Point(60, 422);
            this.lbl_Email_ID.Name = "lbl_Email_ID";
            this.lbl_Email_ID.Size = new System.Drawing.Size(96, 23);
            this.lbl_Email_ID.TabIndex = 70;
            this.lbl_Email_ID.Text = "Email ID";
            // 
            // lbl_Salary
            // 
            this.lbl_Salary.AutoSize = true;
            this.lbl_Salary.BackColor = System.Drawing.Color.SeaShell;
            this.lbl_Salary.Font = new System.Drawing.Font("Lucida Bright", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Salary.ForeColor = System.Drawing.Color.DarkRed;
            this.lbl_Salary.Location = new System.Drawing.Point(746, 424);
            this.lbl_Salary.Name = "lbl_Salary";
            this.lbl_Salary.Size = new System.Drawing.Size(70, 23);
            this.lbl_Salary.TabIndex = 69;
            this.lbl_Salary.Text = "Salary";
            // 
            // lbl_Address
            // 
            this.lbl_Address.AutoSize = true;
            this.lbl_Address.BackColor = System.Drawing.Color.SeaShell;
            this.lbl_Address.Font = new System.Drawing.Font("Lucida Bright", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Address.ForeColor = System.Drawing.Color.DarkRed;
            this.lbl_Address.Location = new System.Drawing.Point(60, 342);
            this.lbl_Address.Name = "lbl_Address";
            this.lbl_Address.Size = new System.Drawing.Size(92, 23);
            this.lbl_Address.TabIndex = 68;
            this.lbl_Address.Text = "Address";
            // 
            // lbl_DOB
            // 
            this.lbl_DOB.AutoSize = true;
            this.lbl_DOB.BackColor = System.Drawing.Color.SeaShell;
            this.lbl_DOB.Font = new System.Drawing.Font("Lucida Bright", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_DOB.ForeColor = System.Drawing.Color.DarkRed;
            this.lbl_DOB.Location = new System.Drawing.Point(52, 188);
            this.lbl_DOB.Name = "lbl_DOB";
            this.lbl_DOB.Size = new System.Drawing.Size(143, 23);
            this.lbl_DOB.TabIndex = 67;
            this.lbl_DOB.Text = "Date Of Birth";
            // 
            // lbl_Emp_Name
            // 
            this.lbl_Emp_Name.AutoSize = true;
            this.lbl_Emp_Name.BackColor = System.Drawing.Color.SeaShell;
            this.lbl_Emp_Name.Font = new System.Drawing.Font("Lucida Bright", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Emp_Name.ForeColor = System.Drawing.Color.DarkRed;
            this.lbl_Emp_Name.Location = new System.Drawing.Point(52, 120);
            this.lbl_Emp_Name.Name = "lbl_Emp_Name";
            this.lbl_Emp_Name.Size = new System.Drawing.Size(173, 23);
            this.lbl_Emp_Name.TabIndex = 66;
            this.lbl_Emp_Name.Text = "Employee Name";
            // 
            // lbl_Emp_ID
            // 
            this.lbl_Emp_ID.AutoSize = true;
            this.lbl_Emp_ID.BackColor = System.Drawing.Color.SeaShell;
            this.lbl_Emp_ID.Font = new System.Drawing.Font("Lucida Bright", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Emp_ID.ForeColor = System.Drawing.Color.DarkRed;
            this.lbl_Emp_ID.Location = new System.Drawing.Point(52, 55);
            this.lbl_Emp_ID.Name = "lbl_Emp_ID";
            this.lbl_Emp_ID.Size = new System.Drawing.Size(139, 23);
            this.lbl_Emp_ID.TabIndex = 65;
            this.lbl_Emp_ID.Text = "Employee ID";
            // 
            // frm_Add_New_Employee
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(15F, 28F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.ClientSize = new System.Drawing.Size(1344, 712);
            this.Controls.Add(this.btn_Save);
            this.Controls.Add(this.pnl_Add_New_Employee);
            this.Controls.Add(this.btn_Refresh);
            this.Controls.Add(this.gb_Add_New_Employee);
            this.Font = new System.Drawing.Font("Lucida Bright", 18F);
            this.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.Margin = new System.Windows.Forms.Padding(8, 6, 8, 6);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "frm_Add_New_Employee";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Add New Employee";
            this.Load += new System.EventHandler(this.frm_Add_New_Employee_Load);
            this.gb_Gender.ResumeLayout(false);
            this.gb_Gender.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pb_Close)).EndInit();
            this.pnl_Add_New_Employee.ResumeLayout(false);
            this.pnl_Add_New_Employee.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pb_Back)).EndInit();
            this.gb_Add_New_Employee.ResumeLayout(false);
            this.gb_Add_New_Employee.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox gb_Gender;
        private System.Windows.Forms.RadioButton rb_Female;
        private System.Windows.Forms.RadioButton rb_Male;
        private System.Windows.Forms.DateTimePicker dtp_Joining_Date;
        private System.Windows.Forms.DateTimePicker dtp_DOB;
        private System.Windows.Forms.TextBox tb_Salary;
        private System.Windows.Forms.TextBox tb_Email_ID;
        private System.Windows.Forms.TextBox tb_Pan_No;
        private System.Windows.Forms.TextBox tb_Aadhar_No;
        private System.Windows.Forms.TextBox tb_Mob_No2;
        private System.Windows.Forms.Button btn_Save;
        private System.Windows.Forms.TextBox tb_Mob_No1;
        private System.Windows.Forms.TextBox tb_Address;
        private System.Windows.Forms.PictureBox pb_Close;
        private System.Windows.Forms.TextBox tb_Emp_Name;
        private System.Windows.Forms.Panel pnl_Add_New_Employee;
        private System.Windows.Forms.PictureBox pb_Back;
        private System.Windows.Forms.Button btn_Exit;
        private System.Windows.Forms.Label lbl_Header;
        private System.Windows.Forms.TextBox tb_Emp_ID;
        private System.Windows.Forms.Button btn_Refresh;
        private System.Windows.Forms.GroupBox gb_Add_New_Employee;
        private System.Windows.Forms.Label lbl_Gender;
        private System.Windows.Forms.Label lbl_Pan_No;
        private System.Windows.Forms.Label lbl_Aadhar_No;
        private System.Windows.Forms.Label lbl_Mob_No2;
        private System.Windows.Forms.Label lbl_Mob_No1;
        private System.Windows.Forms.Label lbl_Joining_Date;
        private System.Windows.Forms.Label lbl_Email_ID;
        private System.Windows.Forms.Label lbl_Salary;
        private System.Windows.Forms.Label lbl_Address;
        private System.Windows.Forms.Label lbl_DOB;
        private System.Windows.Forms.Label lbl_Emp_Name;
        private System.Windows.Forms.Label lbl_Emp_ID;
    }
}