﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Computer_And_Mobile_Shoppee_Management_System
{
    public partial class frm_View_Customer_Details : Form
    {
        Global_ClassFile Gobj = new Global_ClassFile();

        public frm_View_Customer_Details()
        {
            InitializeComponent();
        }

        private void btn_Search_Click(object sender, EventArgs e)
        {
            Gobj.ConnectDB();

            SqlDataAdapter sda = new SqlDataAdapter("Select * From Customer_Bill_Details where Date BETWEEN '" + dtp_Date.Text + "' and '" + dtp_Date2.Text + "' ",Gobj.Con);
            DataTable dt = new DataTable();
            sda.Fill(dt);

            dgv_Customer_Details.DataSource = dt;

            Gobj.DisconnectDB();
        }

        private void btn_Refresh_Click(object sender, EventArgs e)
        {
            dtp_Date.ResetText();

            SqlDataAdapter sda = new SqlDataAdapter("Select * From Customer_Bill_Details",Gobj.Con);
            DataTable dt = new DataTable();
            sda.Fill(dt);

            dgv_Customer_Details.DataSource = dt;
        }

        private void pb_Back_Click(object sender, EventArgs e)
        {
            frm_Customer_Entry_Form obj = new frm_Customer_Entry_Form();
            obj.WindowState = FormWindowState.Maximized;
            obj.Show();
            this.Hide();
        }

        private void pb_Close_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show("Do You Want To Close This Appllication?", "close Application", MessageBoxButtons.YesNo);

            if (result == DialogResult.Yes)
            {
                frm_Login obj = new frm_Login();
                this.Hide();
                obj.Show();
            }
            else
            {
                this.Show();
            }
        }

        private void frm_View_Customer_Details_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'computer_And_Mob_Shoppee_Mgt_Sys_DBDataSet4.Customer_Bill_Details' table. You can move, or remove it, as needed.
            this.customer_Bill_DetailsTableAdapter.Fill(this.computer_And_Mob_Shoppee_Mgt_Sys_DBDataSet4.Customer_Bill_Details);

        }
    }
}
