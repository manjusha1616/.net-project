﻿namespace Computer_And_Mobile_Shoppee_Management_System
{
    partial class frm_Product_Entry_Form
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frm_Product_Entry_Form));
            this.btn_Add_Stock = new System.Windows.Forms.Button();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pb_View_Stock_Details = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.pb_Add_New_Product = new System.Windows.Forms.PictureBox();
            this.btn_Add_New_Subcategory = new System.Windows.Forms.Button();
            this.btn_View_Stock_Details = new System.Windows.Forms.Button();
            this.btn_Add_New_Category = new System.Windows.Forms.Button();
            this.btn_Add_New_Product = new System.Windows.Forms.Button();
            this.pb_Close = new System.Windows.Forms.PictureBox();
            this.pb_Back = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_View_Stock_Details)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_Add_New_Product)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_Close)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_Back)).BeginInit();
            this.SuspendLayout();
            // 
            // btn_Add_Stock
            // 
            this.btn_Add_Stock.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.btn_Add_Stock.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn_Add_Stock.Font = new System.Drawing.Font("Lucida Bright", 24F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))));
            this.btn_Add_Stock.ForeColor = System.Drawing.Color.White;
            this.btn_Add_Stock.Location = new System.Drawing.Point(387, 392);
            this.btn_Add_Stock.Name = "btn_Add_Stock";
            this.btn_Add_Stock.Size = new System.Drawing.Size(466, 78);
            this.btn_Add_Stock.TabIndex = 15;
            this.btn_Add_Stock.Text = "Add Stock";
            this.btn_Add_Stock.UseVisualStyleBackColor = false;
            this.btn_Add_Stock.Click += new System.EventHandler(this.btn_Add_Stock_Click);
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(860, 224);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(100, 78);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox2.TabIndex = 14;
            this.pictureBox2.TabStop = false;
            // 
            // pb_View_Stock_Details
            // 
            this.pb_View_Stock_Details.Image = ((System.Drawing.Image)(resources.GetObject("pb_View_Stock_Details.Image")));
            this.pb_View_Stock_Details.Location = new System.Drawing.Point(859, 477);
            this.pb_View_Stock_Details.Name = "pb_View_Stock_Details";
            this.pb_View_Stock_Details.Size = new System.Drawing.Size(100, 78);
            this.pb_View_Stock_Details.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pb_View_Stock_Details.TabIndex = 16;
            this.pb_View_Stock_Details.TabStop = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(860, 139);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(100, 78);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 12;
            this.pictureBox1.TabStop = false;
            // 
            // pictureBox3
            // 
            this.pictureBox3.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox3.Image")));
            this.pictureBox3.Location = new System.Drawing.Point(859, 392);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(100, 78);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox3.TabIndex = 13;
            this.pictureBox3.TabStop = false;
            // 
            // pb_Add_New_Product
            // 
            this.pb_Add_New_Product.Image = ((System.Drawing.Image)(resources.GetObject("pb_Add_New_Product.Image")));
            this.pb_Add_New_Product.Location = new System.Drawing.Point(859, 308);
            this.pb_Add_New_Product.Name = "pb_Add_New_Product";
            this.pb_Add_New_Product.Size = new System.Drawing.Size(100, 61);
            this.pb_Add_New_Product.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pb_Add_New_Product.TabIndex = 11;
            this.pb_Add_New_Product.TabStop = false;
            // 
            // btn_Add_New_Subcategory
            // 
            this.btn_Add_New_Subcategory.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.btn_Add_New_Subcategory.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn_Add_New_Subcategory.ForeColor = System.Drawing.Color.White;
            this.btn_Add_New_Subcategory.Location = new System.Drawing.Point(386, 224);
            this.btn_Add_New_Subcategory.Name = "btn_Add_New_Subcategory";
            this.btn_Add_New_Subcategory.Size = new System.Drawing.Size(467, 78);
            this.btn_Add_New_Subcategory.TabIndex = 9;
            this.btn_Add_New_Subcategory.Text = "Add New Subcategory";
            this.btn_Add_New_Subcategory.UseVisualStyleBackColor = false;
            this.btn_Add_New_Subcategory.Click += new System.EventHandler(this.btn_Add_New_Subcategory_Click);
            // 
            // btn_View_Stock_Details
            // 
            this.btn_View_Stock_Details.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.btn_View_Stock_Details.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn_View_Stock_Details.ForeColor = System.Drawing.Color.White;
            this.btn_View_Stock_Details.Location = new System.Drawing.Point(385, 477);
            this.btn_View_Stock_Details.Name = "btn_View_Stock_Details";
            this.btn_View_Stock_Details.Size = new System.Drawing.Size(467, 78);
            this.btn_View_Stock_Details.TabIndex = 17;
            this.btn_View_Stock_Details.Text = "View Stock Details";
            this.btn_View_Stock_Details.UseVisualStyleBackColor = false;
            this.btn_View_Stock_Details.Click += new System.EventHandler(this.btn_View_Stock_Details_Click);
            // 
            // btn_Add_New_Category
            // 
            this.btn_Add_New_Category.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.btn_Add_New_Category.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn_Add_New_Category.Font = new System.Drawing.Font("Lucida Bright", 24F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))));
            this.btn_Add_New_Category.ForeColor = System.Drawing.Color.White;
            this.btn_Add_New_Category.Location = new System.Drawing.Point(387, 139);
            this.btn_Add_New_Category.Name = "btn_Add_New_Category";
            this.btn_Add_New_Category.Size = new System.Drawing.Size(467, 78);
            this.btn_Add_New_Category.TabIndex = 7;
            this.btn_Add_New_Category.Text = "Add New Category";
            this.btn_Add_New_Category.UseVisualStyleBackColor = false;
            this.btn_Add_New_Category.Click += new System.EventHandler(this.btn_Add_New_Category_Click);
            // 
            // btn_Add_New_Product
            // 
            this.btn_Add_New_Product.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.btn_Add_New_Product.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn_Add_New_Product.Font = new System.Drawing.Font("Lucida Bright", 24F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))));
            this.btn_Add_New_Product.ForeColor = System.Drawing.Color.White;
            this.btn_Add_New_Product.Location = new System.Drawing.Point(386, 308);
            this.btn_Add_New_Product.Name = "btn_Add_New_Product";
            this.btn_Add_New_Product.Size = new System.Drawing.Size(467, 78);
            this.btn_Add_New_Product.TabIndex = 10;
            this.btn_Add_New_Product.Text = "Add New Product";
            this.btn_Add_New_Product.UseVisualStyleBackColor = false;
            this.btn_Add_New_Product.Click += new System.EventHandler(this.btn_Add_New_Product_Click);
            // 
            // pb_Close
            // 
            this.pb_Close.Image = ((System.Drawing.Image)(resources.GetObject("pb_Close.Image")));
            this.pb_Close.Location = new System.Drawing.Point(1193, 25);
            this.pb_Close.Name = "pb_Close";
            this.pb_Close.Size = new System.Drawing.Size(105, 50);
            this.pb_Close.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pb_Close.TabIndex = 8;
            this.pb_Close.TabStop = false;
            this.pb_Close.Click += new System.EventHandler(this.pb_Close_Click);
            // 
            // pb_Back
            // 
            this.pb_Back.Image = ((System.Drawing.Image)(resources.GetObject("pb_Back.Image")));
            this.pb_Back.Location = new System.Drawing.Point(42, 25);
            this.pb_Back.Name = "pb_Back";
            this.pb_Back.Size = new System.Drawing.Size(100, 50);
            this.pb_Back.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pb_Back.TabIndex = 6;
            this.pb_Back.TabStop = false;
            this.pb_Back.Click += new System.EventHandler(this.pb_Back_Click);
            // 
            // frm_Product_Entry_Form
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(21F, 36F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.MediumPurple;
            this.ClientSize = new System.Drawing.Size(1344, 712);
            this.Controls.Add(this.btn_Add_Stock);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.pb_View_Stock_Details);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.pictureBox3);
            this.Controls.Add(this.pb_Add_New_Product);
            this.Controls.Add(this.btn_Add_New_Subcategory);
            this.Controls.Add(this.btn_View_Stock_Details);
            this.Controls.Add(this.btn_Add_New_Category);
            this.Controls.Add(this.btn_Add_New_Product);
            this.Controls.Add(this.pb_Close);
            this.Controls.Add(this.pb_Back);
            this.Font = new System.Drawing.Font("Lucida Bright", 24F, System.Drawing.FontStyle.Bold);
            this.Margin = new System.Windows.Forms.Padding(10, 8, 10, 8);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "frm_Product_Entry_Form";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Product Entry Form";
            this.Load += new System.EventHandler(this.frm_Product_Entry_Form_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_View_Stock_Details)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_Add_New_Product)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_Close)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_Back)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btn_Add_Stock;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.PictureBox pb_View_Stock_Details;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.PictureBox pb_Add_New_Product;
        private System.Windows.Forms.Button btn_Add_New_Subcategory;
        private System.Windows.Forms.Button btn_View_Stock_Details;
        private System.Windows.Forms.Button btn_Add_New_Category;
        private System.Windows.Forms.Button btn_Add_New_Product;
        private System.Windows.Forms.PictureBox pb_Close;
        private System.Windows.Forms.PictureBox pb_Back;
    }
}