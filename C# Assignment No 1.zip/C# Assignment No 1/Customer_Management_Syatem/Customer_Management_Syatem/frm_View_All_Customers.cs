﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Customer_Management_Syatem
{
    public partial class frm_View_All_Customers : Form
    {
        public frm_View_All_Customers()
        {
            InitializeComponent();
        }

        private void frm_View_All_Customers_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'customer_Data_System_DBDataSet1.Customer_Details' table. You can move, or remove it, as needed.
            this.customer_DetailsTableAdapter.Fill(this.customer_Data_System_DBDataSet1.Customer_Details);
    
        }

        private void btn_Add_New_Customer_Click(object sender, EventArgs e)
        {
            frm_Add_New_Customer obj = new frm_Add_New_Customer();
            obj.Show();
            this.Hide();
        }

        private void btn_Log_Out_Click(object sender, EventArgs e)
        {
            frm_Login a = new frm_Login();
            a.Show();
            this.Hide();
        }
    }
}
