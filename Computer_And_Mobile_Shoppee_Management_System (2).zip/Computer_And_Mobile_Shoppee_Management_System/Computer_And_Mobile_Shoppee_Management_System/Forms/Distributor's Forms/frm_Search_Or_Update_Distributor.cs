﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Computer_And_Mobile_Shoppee_Management_System
{
    public partial class frm_Search_Or_Update_Distributor : Form
    {
        Global_ClassFile Gobj = new Global_ClassFile();

        public frm_Search_Or_Update_Distributor()
        {
            InitializeComponent();
        }

        private void frm_Search_Or_Update_Distributor_Load(object sender, EventArgs e)
        {
            tb_Distributor_ID.Focus();
            Clear_Controls();
        }

        void Clear_Controls()
        {
            tb_Distributor_ID.Text = "";
            tb_Distributor_Name.Text = " ";
            cb_Brand_Delivered.Text = "";
            tb_Address.Text = "";
            tb_Mob_No1.Text = "";
            tb_Mob_No2.Text = "";
            dtp_Tie_Up_Date.ResetText();
            tb_Registration_No.Text = " ";
            tb_Aadhar_Card_No.Text = "";
            tb_Pan_Card_No.Text = "";
            tb_Email_ID.Text = "";
            tb_Distributor_ID.Enabled = true;
            tb_Distributor_Name.Enabled = false;
            cb_Brand_Delivered.Enabled = false;
            tb_Address.Enabled = false;
            tb_Mob_No1.Enabled = false;
            tb_Mob_No2.Enabled = false;
            dtp_Tie_Up_Date.Enabled = false;
            tb_Registration_No.Enabled = false;
            tb_Aadhar_Card_No.Enabled = false;
            tb_Pan_Card_No.Enabled = false;
            tb_Email_ID.Enabled = false;
            tb_Distributor_ID.Focus();
            tb_Distributor_ID.Enabled = true;
            btn_Search.Enabled = false;
            btn_Update.Enabled = false;
        }

        private void tb_Distributor_ID_TextChanged(object sender, EventArgs e)
        {
            btn_Search.Enabled = true;
        }


        private void tb_Distributor_ID_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!(Char.IsDigit(e.KeyChar) || (e.KeyChar == (char)Keys.Back)))
            {
                e.Handled = true;
            }
        }

        private void tb_Mob_No1_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!(Char.IsDigit(e.KeyChar) || (e.KeyChar == (char)Keys.Back)))
            {
                e.Handled = true;
            }
        }

        private void tb_Mob_No2_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!(Char.IsDigit(e.KeyChar) || (e.KeyChar == (char)Keys.Back)))
            {
                e.Handled = true;
            }
        }

        private void tb_Aadhar_Card_No_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!(Char.IsDigit(e.KeyChar) || (e.KeyChar == (char)Keys.Back)))
            {
                e.Handled = true;
            }
        }

        void Search_Details()
        {
            tb_Distributor_ID.Enabled = false;

            string Mob_No2 = "";

            if (tb_Mob_No2.Text == "")
            {
                Mob_No2 = " null ";
                tb_Mob_No2.Text = Mob_No2;
            }

            Gobj.ConnectDB();

            SqlCommand cmd = new SqlCommand("Select * from Distributor_Details where Distributor_ID = " + tb_Distributor_ID.Text + " ", Gobj.Con);

            var obj = cmd.ExecuteReader();

            if (obj.Read())
            {
                tb_Distributor_Name.Text = obj.GetString(obj.GetOrdinal("Distributor_Name"));
                tb_Address.Text = obj.GetString(obj.GetOrdinal("Address"));
                tb_Registration_No.Text = (obj["Registration_No"].ToString());
                cb_Brand_Delivered.Text = obj.GetString(obj.GetOrdinal("Brand_Delivered"));
                tb_Email_ID.Text = obj.GetString(obj.GetOrdinal("Email_ID"));
                dtp_Tie_Up_Date.Text = (obj["Tie_Up_Date"].ToString());
                tb_Mob_No1.Text = (obj["Mobile_No_1"].ToString());
                tb_Mob_No2.Text = (obj["Mobile_No_2"].ToString());
                tb_Aadhar_Card_No.Text = (obj["Aadhar_Card_No"].ToString());
                tb_Pan_Card_No.Text = (obj["Pan_Card_No"].ToString());

                tb_Distributor_Name.Enabled = false;
                cb_Brand_Delivered.Enabled = false;
                tb_Address.Enabled = false;
                tb_Mob_No1.Enabled = false;
                tb_Mob_No2.Enabled = false;
                dtp_Tie_Up_Date.Enabled = false;
                tb_Registration_No.Enabled = false;
                tb_Aadhar_Card_No.Enabled = false;
                tb_Pan_Card_No.Enabled = false;
                tb_Email_ID.Enabled = false;
                btn_Update.Enabled = true;

            }
            else
            {
                MessageBox.Show("Invalid Distributor ID", "Failure", MessageBoxButtons.OK, MessageBoxIcon.Error);
                Clear_Controls();
            }

            Gobj.DisconnectDB();
        }

        private void btn_Search_Click(object sender, EventArgs e)
        {
            tb_Distributor_ID.Enabled = false;
            Search_Details();
        }

        private void btn_Update_Click(object sender, EventArgs e)
        {
            tb_Address.Focus();
            tb_Address.Enabled = true;
            tb_Mob_No1.Enabled = true;
            tb_Mob_No2.Enabled = true;
            tb_Email_ID.Enabled = true;
        }

        private void btn_Save_Click(object sender, EventArgs e)
        {
            if (tb_Mob_No1.TextLength < 10)
            {
                MessageBox.Show("Invalid Mobile Number", "Failure", MessageBoxButtons.OK, MessageBoxIcon.Error);
                tb_Mob_No1.Focus();
                goto DWN;
            }

            long Mob_No2 = 0;

            if (tb_Mob_No2.Text != "")
            {                
                Mob_No2 = Convert.ToInt64(tb_Mob_No2.Text);
            }

            Gobj.ConnectDB();

            if (tb_Distributor_ID.Text !="" && tb_Registration_No.Text != "" && tb_Distributor_Name.Text != "" && tb_Address.Text != "" && tb_Mob_No1.Text != "" && tb_Aadhar_Card_No.Text != "" && tb_Pan_Card_No.Text != "")
            {
                SqlDataAdapter sda = new SqlDataAdapter(" Update Distributor_Details Set Distributor_Name = '" + tb_Distributor_Name.Text + "', Address = '" + tb_Address.Text + "', Registration_No = " + tb_Registration_No.Text + ", Brand_Delivered = '" + cb_Brand_Delivered.Text + "', Email_ID = '" + tb_Email_ID.Text + "', Tie_Up_Date = '" + dtp_Tie_Up_Date.Text + "', Mobile_No_1= " + tb_Mob_No1.Text + ",Mobile_No_2 = " + Mob_No2 + ", Aadhar_Card_No= " + tb_Aadhar_Card_No.Text + ", Pan_Card_No= '" + tb_Pan_Card_No.Text + "', Updaters_Uname = '" + Global_ClassFile.Uname + "' Where Distributor_ID = " + tb_Distributor_ID.Text + "", Gobj.Con);

                DataTable dt = new DataTable();
                sda.Fill(dt);

                MessageBox.Show("Record Saved Successfully...", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);

                tb_Distributor_ID.Enabled = true;
                Clear_Controls();
            }
            else
            {
                MessageBox.Show("Please, Fill All The Fields", "Failure", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

            DWN:
            Gobj.DisconnectDB();
        }

        private void btn_Refresh_Click(object sender, EventArgs e)
        {
            Clear_Controls();
            tb_Distributor_ID.Focus();
        }

        private void pb_Back_Click(object sender, EventArgs e)
        {
            frm_Distributor_Entry_Form obj = new frm_Distributor_Entry_Form();

            obj.WindowState = FormWindowState.Maximized;
            this.Hide();
            obj.Show();
        }

        private void pb_Close_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show("Do You Want To Close This Appllication?", "close Application", MessageBoxButtons.YesNo);

            if (result == DialogResult.Yes)
            {
                frm_Login obj = new frm_Login();
                this.Hide();
                obj.Show();
            }
            else
            {
                this.Show();
            }
        }
    }
}
