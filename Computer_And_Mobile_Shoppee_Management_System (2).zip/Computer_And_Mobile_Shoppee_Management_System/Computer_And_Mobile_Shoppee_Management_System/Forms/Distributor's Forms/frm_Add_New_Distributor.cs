﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Configuration;
using System.Data.SqlClient;

namespace Computer_And_Mobile_Shoppee_Management_System
{
    public partial class frm_Add_New_Distributor : Form
    {
        Global_ClassFile Gobj = new Global_ClassFile();

        public frm_Add_New_Distributor()
        {
            InitializeComponent();
        }

        private void frm_Add_New_Distributor_Load(object sender, EventArgs e)
        {
            Clear_Controls();
        }

        int Auto_Incr_ID()
        {
            Gobj.ConnectDB();

            int Cnt = 0;

            SqlCommand Cmd = new SqlCommand();

            Cmd.CommandText = "Select Count(Distributor_ID) from Distributor_Details";
            Cmd.Connection = Gobj.Con;

            Cnt = Convert.ToInt32(Cmd.ExecuteScalar());

            Cmd.Dispose();

            if (Cnt > 0)
            {
                Cmd.CommandText = "Select Max(Distributor_ID) from Distributor_Details";
                Cmd.Connection = Gobj.Con;
            }

            Cnt = 1 + Cnt;

            Gobj.DisconnectDB();

            return Cnt;
        }

        void Clear_Controls()
        {
            tb_Distributor_ID.Text = Convert.ToString(Auto_Incr_ID());
            tb_Distributor_Name.Text = " ";
            tb_Address.Text = "";
            tb_Mob_No1.Text = "";
            tb_Mob_No2.Text = "";
            dtp_Tie_Up_Date.ResetText();
            tb_Registration_No.Text = "";
            tb_Aadhar_No.Text = "";
            tb_Pan_No.Text = "";
            tb_Email_ID.Text = "";
            rb_Female.Checked = false;
            rb_Male.Checked = false;
            tb_Distributor_Name.Focus();
            cb_Other_Accessories.Checked = false;
            cb_Mobile.Checked = false;
            cb_Laptop.Checked = false;
            cb_Desktop_Computer.Checked = false;
        }

        private void tb_Mob_No1_TextChanged(object sender, EventArgs e)
        {
            tb_Mob_No2.Enabled = true;
        }

        private void tb_Mob_No2_TextChanged(object sender, EventArgs e)
        {
            dtp_Tie_Up_Date.Enabled = true;
        }

        private void tb_Mob_No1_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!(Char.IsDigit(e.KeyChar) || (e.KeyChar == (char)Keys.Back)))
            {
                e.Handled = true;
            }
        }

        private void tb_Mob_No2_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!(Char.IsDigit(e.KeyChar) || (e.KeyChar == (char)Keys.Back)))
            {
                e.Handled = true;
            }
        }

        private void tb_Registration_No_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!(Char.IsDigit(e.KeyChar) || (e.KeyChar == (char)Keys.Back)))
            {
                e.Handled = true;
            }
        }

        private void tb_Aadhar_No_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!(Char.IsDigit(e.KeyChar) || (e.KeyChar == (char)Keys.Back)))
            {
                e.Handled = true;
            }
        }       

        private void btn_Save_Click(object sender, EventArgs e)
        {
            Gobj.ConnectDB();

            if (tb_Mob_No1.TextLength < 10)
            {
                MessageBox.Show("Invalid Mobile Number", "Failure", MessageBoxButtons.OK, MessageBoxIcon.Error);
                tb_Mob_No1.Focus();
                goto DWN;
            }

            if (tb_Aadhar_No.TextLength < 12)
            {
                MessageBox.Show("Invalid Aadhar Card Number", "Failure", MessageBoxButtons.OK, MessageBoxIcon.Error);
                tb_Aadhar_No.Focus();
                goto DWN;
            }

            if (tb_Pan_No.TextLength < 10)
            {
                MessageBox.Show("Invalid Pan Card Number", "Failure", MessageBoxButtons.OK, MessageBoxIcon.Error);
                tb_Pan_No.Focus();
                goto DWN;
            }

            if (tb_Registration_No.TextLength < 5)
            {
                MessageBox.Show("Invalid Registration Number", "Failure", MessageBoxButtons.OK, MessageBoxIcon.Error);
                tb_Registration_No.Focus();
                goto DWN;
            }

            string Gender = "";

            if (rb_Male.Checked)
            {
                Gender = rb_Male.Text;
            }
            else if (rb_Female.Checked)
            {
                Gender = rb_Female.Text;
            }

            long Mob_No2 = 0;

            if (tb_Mob_No2.Text != "")
            {
                Mob_No2 = Convert.ToInt64(tb_Mob_No2.Text);
            }

            string Brand_Delivered = "";

            if (cb_Mobile.Checked)
            {
                Brand_Delivered = " Mobile ";
            }
            if (cb_Desktop_Computer.Checked)
            {
                Brand_Delivered += "Desktop Computer ";
            }
            if (cb_Laptop.Checked)
            {
                Brand_Delivered += "Laptop ";
            }
            if (cb_Other_Accessories.Checked)
            {
                Brand_Delivered += "Other_Accessories ";
            }

            if (tb_Distributor_ID.Text !="" && tb_Registration_No.Text != "" && tb_Distributor_Name.Text != "" && tb_Address.Text != "" && tb_Mob_No1.Text != "" && tb_Aadhar_No.Text != "" && tb_Pan_No.Text != "")
            {
                Gobj.ConnectDB();

                SqlDataAdapter sda = new SqlDataAdapter("Insert into Distributor_Details(Distributor_Name ,Address ,Gender ,Mobile_No_1 ,Mobile_No_2 ,Tie_Up_Date ,Registration_No ,Aadhar_Card_No ,Pan_Card_No ,Email_ID,Brand_Delivered ,Username) values('" + tb_Distributor_Name.Text + "','" + tb_Address.Text + "','" + Gender + "'," + tb_Mob_No1.Text + "," + Mob_No2 + ",'" + dtp_Tie_Up_Date.Text + "'," + tb_Registration_No.Text + "," + tb_Aadhar_No.Text + ",'" + tb_Pan_No.Text + "','" + tb_Email_ID.Text + "','" + Brand_Delivered + "','" + Global_ClassFile.Uname + "')", Gobj.Con);
                DataTable DT = new DataTable();
                sda.Fill(DT);

                MessageBox.Show("Record Saved Successfully...", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);

                Clear_Controls();
            }
            else
            {
                MessageBox.Show("Please, Fill All The Fields", "Failure", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            
            DWN:
            Gobj.DisconnectDB();
        }

        private void btn_Refresh_Click(object sender, EventArgs e)
        {
            Clear_Controls();
            pb_Back.Focus();
        }

        private void pb_Back_Click(object sender, EventArgs e)
        {
            frm_Distributor_Entry_Form obj = new frm_Distributor_Entry_Form();

            obj.WindowState = FormWindowState.Maximized;
            this.Hide();
            obj.Show();
        }

        private void pb_Close_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show("Do You Want To Close This Appllication?", "close Application", MessageBoxButtons.YesNo);

            if (result == DialogResult.Yes)
            {
                frm_Login obj = new frm_Login();
                this.Hide();
                obj.Show();
            }
            else
            {
                this.Show();
            }
        }
    }        
}
