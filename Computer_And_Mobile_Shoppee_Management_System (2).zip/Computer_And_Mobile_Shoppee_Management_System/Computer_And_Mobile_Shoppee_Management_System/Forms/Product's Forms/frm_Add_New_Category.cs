﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Computer_And_Mobile_Shoppee_Management_System
{
    public partial class frm_Add_New_Category : Form
    {
        Global_ClassFile Gobj = new Global_ClassFile();

        public frm_Add_New_Category()
        {
            InitializeComponent();
        }

        int Auto_Incr()
        {
            Gobj.ConnectDB();

            int Cnt = 0;

            SqlCommand Cmd = new SqlCommand();

            Cmd.CommandText = "Select Count(Category_ID) from Category_Details";
            Cmd.Connection = Gobj.Con;

            Cnt = Convert.ToInt32(Cmd.ExecuteScalar());

            Cmd.Dispose();

            if (Cnt > 0)
            {
                Cmd.CommandText = "Select Max(Category_ID) from Category_Details";
                Cmd.Connection = Gobj.Con;
            }

            Cnt = 1 + Cnt;

            Gobj.DisconnectDB();

            return Cnt;
        }

        void Clear_Controls()
        {
            tb_Category_ID.Text = Convert.ToString(Auto_Incr());
            tb_Category_Name.Text = " ";
            tb_Category_Name.Focus();
        }

        private void frm_Add_New_Category_Load(object sender, EventArgs e)
        {
            tb_Category_Name.Focus();
            tb_Category_ID.Text = Convert.ToString(Auto_Incr());
            pb_Back.Focus();
        }

        private void tb_Category_ID_TextChanged(object sender, EventArgs e)
        {
            tb_Category_Name.Enabled = true;
        }

        private void tb_Category_Name_TextChanged(object sender, EventArgs e)
        {
            btn_Save.Enabled = true;
        }

        private void btn_Save_Click(object sender, EventArgs e)
        {
            Gobj.ConnectDB();

            if (tb_Category_Name.Text != " ")
            {
                SqlDataAdapter sda = new SqlDataAdapter("Insert into Category_Details values('" + tb_Category_Name.Text + "','" + Global_ClassFile.Uname + "')", Gobj.Con);

                DataTable dt = new DataTable();
                sda.Fill(dt);

                MessageBox.Show("Record Saved Successfully...", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);

                Clear_Controls();
            }
            else
            {
                MessageBox.Show("Please, Fill All The Fields", "Failure", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

            Gobj.DisconnectDB();
        }

        private void pb_Back_Click(object sender, EventArgs e)
        {
            this.Hide();
        }
    }
}
