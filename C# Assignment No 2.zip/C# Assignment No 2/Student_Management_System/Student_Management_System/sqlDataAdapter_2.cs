﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Student_Management_System
{
    class sqlDataAdapter
    { }
}
