﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Computer_And_Mobile_Shoppee_Management_System
{
    public partial class frm_Add_New_Customer : Form
    {
        Global_ClassFile Gobj = new Global_ClassFile();
        DataTable table = new DataTable();
 
        public frm_Add_New_Customer()
        {
            InitializeComponent();
        }

        private void frm_Add_New_Customer_Load(object sender, EventArgs e)
        {
            DataBindToGrid();
        }

        int Auto_Incr_ID()
        {
            Gobj.ConnectDB();

            int Cnt = 0;

            SqlCommand Cmd = new SqlCommand();

            Cmd.CommandText = "Select Count(Customer_ID) from Customer_Details";
            Cmd.Connection = Gobj.Con;

            Cnt = Convert.ToInt32(Cmd.ExecuteScalar());

            Cmd.Dispose();

            if (Cnt > 0)
            {
                Cmd.CommandText = "Select Max(Customer_ID) from Customer_Details";
                Cmd.Connection = Gobj.Con;
            }

            Cnt = 1 + Cnt;

            Gobj.DisconnectDB();

            return Cnt;
        }

        void Clear_Controls()
        {
            tb_Customer_ID.Text = "";
            tb_Customer_ID.Text = Convert.ToString(Auto_Incr_ID());
            tb_Customer_Name.Text = "";
            tb_Mob_No.Text = "";
            tb_Address.Text = "";
            cb_Product_Category.Items.Clear();
            cb_Product_Subcategory.Items.Clear();
            cb_Product_Name.Items.Clear();
            Bind_categories_To_ComboBox();
            tb_Quantity.Text = "";
            tb_Price.Text = "";
            tb_GST_Applied.Text = "";
            tb_Total_Price.Text = "";
            tb_Discount.Text = "";
            tb_Total_Bill.Text = "";
            cb_Product_Category.Text = "";
            cb_Product_Subcategory.Text = "";
            cb_Product_Name.Text = "";
            cb_Product_Name.Enabled=true;
            cb_Product_Subcategory.Enabled=true;
            cb_Product_Category.Enabled=true;
            tb_Quantity.Enabled = true;
            btn_Add.Enabled = false;
            btn_Confirm.Enabled = false;
            tb_Customer_Name.Focus();
            dgv_Purchase_Details.AllowUserToAddRows = false;
            btn_Save.Enabled = false;
        }

        void Add_Click_ClearControls()
        {
            cb_Product_Category.Text = "";
            cb_Product_Name.Text = "";
            cb_Product_Subcategory.Text = "";
            tb_Quantity.Text = "";
            tb_Price.Text = "";
            tb_GST_Applied.Text = "";
            cb_Product_Category.Enabled = true;
            cb_Product_Subcategory.Enabled = true;
            cb_Product_Name.Enabled = true;
            cb_Product_Subcategory.Items.Clear();
            tb_GST_Applied.Enabled = true;
            cb_Product_Name.Items.Clear();
            cb_Product_Category.Focus();
            btn_Confirm.Enabled = true;
            dgv_Purchase_Details.AllowUserToAddRows = false;
        }

        void DataBindToGrid()
        {
            table.Columns.Add("Cat");
            table.Columns.Add("Subcat");
            table.Columns.Add("Product");
            table.Columns.Add("GST");
            table.Columns.Add("Qty");
            table.Columns.Add("Price");

            dgv_Purchase_Details.DataSource = table;

            Clear_Controls();
        }

        void Bind_categories_To_ComboBox()
        {
            Gobj.ConnectDB();

            SqlCommand Cmd = new SqlCommand("Select Distinct(Category_Name) From Category_Details", Gobj.Con);

            var obj = Cmd.ExecuteReader();

            while (obj.Read())
            {
                cb_Product_Category.Items.Add(obj.GetString(obj.GetOrdinal("Category_Name")));
            }

            obj.Dispose();

            Gobj.DisconnectDB();
        }

        void Bind_Subcategories_To_Combobox()
        {
            Gobj.ConnectDB();

            SqlCommand cmd = new SqlCommand();

            cmd.CommandText = "Select Subcategory_Name From Subcategory_Details where Category_Name = '" + cb_Product_Category.Text + "' ";
            cmd.Connection = Gobj.Con;

            var Obj = cmd.ExecuteReader();

            while (Obj.Read())
            {
                cb_Product_Subcategory.Items.Add(Obj.GetString(Obj.GetOrdinal("Subcategory_Name")));
            }

            Gobj.DisconnectDB();
        }

        void Bind_Products_To_Combobox()
        {
            Gobj.ConnectDB();

            SqlCommand cmd = new SqlCommand();

            cmd.CommandText = "Select Product_Name From Product_Details where Subcategory = '" + cb_Product_Subcategory.Text + "' ";
            cmd.Connection = Gobj.Con;

            var Obj = cmd.ExecuteReader();

            while (Obj.Read())
            {
                cb_Product_Name.Items.Add(Obj.GetString(Obj.GetOrdinal("Product_Name")));
            }

            Gobj.DisconnectDB();
        }

        void Quantity_Conditions()
        {
            Gobj.ConnectDB();

            SqlCommand cmd = new SqlCommand();

            cmd.CommandText = "Select Stock_Quantity From Product_Details where Product_Name = '" + cb_Product_Name.Text + "' ";
            cmd.Connection = Gobj.Con;

            var Obj = cmd.ExecuteReader();

            string qty;

            if (Obj.Read())
            {
                qty = Obj["Stock_Quantity"].ToString();

                Obj.Dispose();

                if (Convert.ToInt32(qty) <= 0)
                {
                    MessageBox.Show("There Is 0 Quantity Available In Stock Of Entered Product", "Failure", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    Add_Click_ClearControls();
                }
                else if (Convert.ToInt32(qty) < Convert.ToInt32(tb_Quantity.Text))
                {
                    tb_Quantity.Text = Convert.ToInt32(qty).ToString();

                    MessageBox.Show("Entered Quantity Is Not Available In Stock", "Failure", MessageBoxButtons.OK, MessageBoxIcon.Error);

                    Gobj.ConnectDB();

                    SqlCommand Cmd = new SqlCommand();

                    Cmd.CommandText = "Select Sales_Rate From Product_Details where Product_Name = '" + cb_Product_Name.Text + "' ";
                    Cmd.Connection = Gobj.Con;

                    var obj = Cmd.ExecuteReader();

                    if (obj.Read())
                    {
                        tb_Price.Text = (obj["Sales_Rate"].ToString());

                        tb_Price.Text = (float.Parse(tb_Quantity.Text) * float.Parse(tb_Price.Text)).ToString();
                        double gst = Convert.ToDouble(tb_GST_Applied.Text);
                        double price = Convert.ToDouble(tb_Price.Text);
                        gst = (gst * price) / 100;
                        price = Convert.ToDouble(gst + price);
                        tb_Price.Text = price.ToString();
                    }

                    Gobj.DisconnectDB();
                }
                else if (Convert.ToInt32(qty) >= Convert.ToInt32(tb_Quantity.Text))
                {
                    Gobj.ConnectDB();

                    SqlCommand Cmd = new SqlCommand();

                    Cmd.CommandText = "Select Sales_Rate From Product_Details where Product_Name = '" + cb_Product_Name.Text + "' ";
                    Cmd.Connection = Gobj.Con;

                    var obj = Cmd.ExecuteReader();

                    if (obj.Read())
                    {
                        tb_Price.Text = (obj["Sales_Rate"].ToString());

                        tb_Price.Text = (float.Parse(tb_Quantity.Text) * float.Parse(tb_Price.Text)).ToString();
                        double gst = Convert.ToDouble(tb_GST_Applied.Text);
                        double price = Convert.ToDouble(tb_Price.Text);
                        gst = (gst * price) / 100;
                        price = Convert.ToDouble(gst + price);
                        tb_Price.Text = price.ToString();
                    }

                    Gobj.DisconnectDB();
                }
            }
            Gobj.DisconnectDB();
        }

        void Calculate_Discount()
        {
            if (tb_Total_Bill.Text != "")
            {
                double Discount = Convert.ToDouble(tb_Discount.Text);
                double Total_Bill = Convert.ToDouble(tb_Total_Bill.Text);
                Discount = (Total_Bill * Discount) / 100;
                tb_Total_Bill.Text = (Total_Bill - Discount).ToString();
            }
        }

        void Calculate_Total()
        {
            int Total = 0;
            int i;
            for (i = 0; i <= dgv_Purchase_Details.RowCount - 1; i++)
            {
                Total += Convert.ToInt32(dgv_Purchase_Details.Rows[i].Cells[6].Value);

            }
            tb_Total_Price.Text = Convert.ToString(Total);
            tb_Total_Bill.Text = Convert.ToString(Total);
        }

        private void btn_Refresh_Click(object sender, EventArgs e)
        {
            Clear_Controls();
            if (dgv_Purchase_Details.RowCount > 0)
            {
                for (int i = 0; i <= dgv_Purchase_Details.RowCount; i++)
                {
                    dgv_Purchase_Details.Rows.RemoveAt(i);
                }
            }
        } 

        private void cb_Product_Category_SelectedIndexChanged(object sender, EventArgs e)
        {
            cb_Product_Subcategory.Items.Clear();
            cb_Product_Subcategory.Text = "";
            cb_Product_Subcategory.Enabled = true;
            cb_Product_Name.Items.Clear();

            Bind_Subcategories_To_Combobox();
        }

        private void cb_Product_Subcategory_SelectedIndexChanged(object sender, EventArgs e)
        {
            cb_Product_Name.Items.Clear();
            cb_Product_Name.Text = "";
            cb_Product_Name.Enabled = true;

            Bind_Products_To_Combobox();
        }

        private void tb_Quantity_TextChanged(object sender, EventArgs e)
        {
            tb_Price.Enabled = false;
            tb_GST_Applied.Enabled = false;
            btn_Add.Enabled = true;

            Quantity_Conditions();
        }
        
        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (dgv_Purchase_Details.Rows.Count > 0)
            {
                dgv_Purchase_Details.Rows.Remove(dgv_Purchase_Details.CurrentRow); 
            }             
                           
        }

        private void btn_Add_Click(object sender, EventArgs e)
        {
            table.Rows.Add(cb_Product_Category.Text, cb_Product_Subcategory.Text, cb_Product_Name.Text, tb_GST_Applied.Text, tb_Quantity.Text, tb_Price.Text);
            dgv_Purchase_Details.DataSource = "";
            dgv_Purchase_Details.DataSource = table;

            dgv_Purchase_Details.FirstDisplayedScrollingRowIndex = dgv_Purchase_Details.RowCount - 1;

            Add_Click_ClearControls();
        }

        private void tb_GST_Applied_TextChanged(object sender, EventArgs e)
        {
            btn_Add.Enabled = false;
        }

        private void tb_Discount_Leave(object sender, EventArgs e)
        {
            Calculate_Discount();
        }

        private void tb_Mob_No_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!(Char.IsDigit(e.KeyChar) || (e.KeyChar == (char)Keys.Back)))
            {
                e.Handled = true;
            }
        }

        private void cb_Product_Name_SelectedIndexChanged(object sender, EventArgs e)
        {
            cb_Product_Subcategory.Enabled = false;
            cb_Product_Name.Enabled = false;
        }

        private void tb_Quantity_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!(Char.IsDigit(e.KeyChar) || (e.KeyChar == (char)Keys.Back)))
            {
                e.Handled = true;
            }
        }

        private void tb_Discount_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!(Char.IsDigit(e.KeyChar) || (e.KeyChar == (char)Keys.Back)))
            {
                e.Handled = true;
            }
        }

        private void tb_GST_Applied_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!(Char.IsDigit(e.KeyChar) || (e.KeyChar == (char)Keys.Back)))
            {
                e.Handled = true;
            }
        }

        private void tb_Total_Bill_TextChanged(object sender, EventArgs e)
        {
            btn_Save.Enabled = true;
        }

        private void btn_Confirm_Click(object sender, EventArgs e)
        {
            cb_Product_Category.Enabled = false;
            cb_Product_Subcategory.Enabled = false;
            cb_Product_Name.Enabled = false;
            tb_Quantity.Enabled = false;
            dgv_Purchase_Details.Enabled = false;

            Calculate_Total();
        }

        private void tb_Price_TextChanged(object sender, EventArgs e)
        {
            btn_Add.Enabled = true;
        }

        private void btn_Save_Click(object sender, EventArgs e)
        {
            try
            {
                Gobj.ConnectDB();

                if (tb_Mob_No.Text.Length < 10)
                {
                    MessageBox.Show("Invalid Mobile Number", "Failure", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    tb_Mob_No.Focus();
                    goto DWN;
                }

                float Discount = 0;

                if (tb_Discount.Text == "")
                {
                    tb_Discount.Text = Discount.ToString();
                }

                if (tb_Customer_ID.Text != "" && tb_Customer_Name.Text != "" && tb_Mob_No.Text != "" && tb_Address.Text != "" && tb_Total_Price.Text != "" && tb_Total_Bill.Text != "")
                {
                    SqlCommand Cmd = new SqlCommand();
                    Cmd.CommandText = "INSERT INTO Customer_Details VALUES(" + tb_Customer_ID.Text + ",'" + tb_Customer_Name.Text + "'," + tb_Mob_No.Text + ",'" + tb_Address.Text + "'," + tb_Total_Bill.Text + ",'" + dtp_Date.Text + "','" + Global_ClassFile.Uname + "')";
                    Cmd.Connection = Gobj.Con;
                    Cmd.ExecuteNonQuery();

                    for (int i = 0; i < dgv_Purchase_Details.Rows.Count; i++)
                    {
                        int Qty = 0;
                        string P_Name = "";

                        Cmd.CommandText = "INSERT INTO Customer_Bill_Details VALUES(" + tb_Customer_ID.Text + " , '" + dgv_Purchase_Details.Rows[i].Cells[1].Value + "' , '" + dgv_Purchase_Details.Rows[i].Cells[2].Value + "' , '" + dgv_Purchase_Details.Rows[i].Cells[3].Value + "' , '" + dgv_Purchase_Details.Rows[i].Cells[5].Value + "' , '" + dgv_Purchase_Details.Rows[i].Cells[4].Value + "' , '" + dgv_Purchase_Details.Rows[i].Cells[6].Value + "' , '" + dtp_Date.Text + "','" + Global_ClassFile.Uname + "')";
                        Cmd.Connection = Gobj.Con;
                        Cmd.ExecuteNonQuery();

                        Qty = Convert.ToInt32(dgv_Purchase_Details.Rows[i].Cells[5].Value);
                        Qty.ToString();

                        P_Name = (dgv_Purchase_Details.Rows[i].Cells[3].Value).ToString();

                        SqlCommand Cmd2 = new SqlCommand();
                        Cmd2.CommandText = "Update Product_Details set Stock_Quantity = Stock_Quantity - " + Qty + " where Product_Name = '" + P_Name.ToString() + "' ";
                        Cmd2.Connection = Gobj.Con;
                        Cmd2.ExecuteNonQuery();
                    }

                    MessageBox.Show("Record Saved Successfully...", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);

                    Clear_Controls();
                    Add_Click_ClearControls();

                    if (dgv_Purchase_Details.RowCount > 0)
                    {
                        for (int i = 0; i <= dgv_Purchase_Details.RowCount; i++)
                        {
                            dgv_Purchase_Details.Rows.RemoveAt(i);
                        }
                    }
                }
                else
                {
                    MessageBox.Show("Please, Fill All The Fields", "Failure", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                DWN:
                Gobj.DisconnectDB();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void pb_Back_Click(object sender, EventArgs e)
        {
            frm_Customer_Entry_Form Obj = new frm_Customer_Entry_Form();

            Obj.WindowState = FormWindowState.Maximized;
            this.Hide();
            Obj.Show();
        }

        private void pb_Close_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show("Do You Want To Close This Appllication?", "close Application", MessageBoxButtons.YesNo);

            if (result == DialogResult.Yes)
            {
                frm_Login obj = new frm_Login();
                this.Hide();
                obj.Show();
            }
            else
            {
                this.Show();
            }
        }
    }
}