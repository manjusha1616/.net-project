﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Computer_And_Mobile_Shoppee_Management_System
{
    public partial class frm_View_Stock_Details : Form
    {
        Global_ClassFile Gobj = new Global_ClassFile();

        public frm_View_Stock_Details()
        {
            InitializeComponent();
        }
       
        private void frm_View_Stock_Details_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'computer_And_Mob_Shoppee_Mgt_Sys_DBDataSet.Stock_Details' table. You can move, or remove it, as needed.
            this.stock_DetailsTableAdapter.Fill(this.computer_And_Mob_Shoppee_Mgt_Sys_DBDataSet.Stock_Details);

            Clear_Controls();
        }

        void Clear_Controls()
        {
            cb_Category_Name.Focus();
            cb_Category_Name.Items.Clear();
            cb_Subcategory_Name.Items.Clear();
            cb_Category_Name.Text = "";
            cb_Product_Name.Text = "";
            cb_Subcategory_Name.Text = "";
            cb_Product_Name.Items.Clear();
            cb_Category_Name.Enabled = true;
            Bind_categories_To_ComboBox();
        }

        void Bind_categories_To_ComboBox()
        {
            Gobj.ConnectDB();

            SqlCommand Cmd = new SqlCommand("Select Distinct(Category_Name) From Category_Details", Gobj.Con);

            var obj = Cmd.ExecuteReader();

            while (obj.Read())
            {
                cb_Category_Name.Items.Add(obj.GetString(obj.GetOrdinal("Category_Name")));
            }

            obj.Dispose();

            Gobj.DisconnectDB();
        }

        void Bind_Subcategories_To_ComboBox()
        {
            Gobj.ConnectDB();

            SqlDataAdapter sda = new SqlDataAdapter("Select * From Stock_Details where  Category = '" + cb_Category_Name.Text + "' ", Gobj.Con);

            DataTable dt = new DataTable();
            sda.Fill(dt);

            dgv_View_Stock_Details.DataSource = dt;

            SqlCommand cmd = new SqlCommand();

            cmd.CommandText = "Select Subcategory_Name From Subcategory_Details where Category_Name = '" + cb_Category_Name.Text + "' ";
            cmd.Connection = Gobj.Con;

            var Obj = cmd.ExecuteReader();

            while (Obj.Read())
            {
                cb_Subcategory_Name.Items.Add(Obj.GetString(Obj.GetOrdinal("Subcategory_Name")));
            }

            Gobj.DisconnectDB();
        }

        void Bind_Products_To_ComboBox()
        {
            Gobj.ConnectDB();

            SqlDataAdapter sda = new SqlDataAdapter("Select * From Stock_Details where  Subcategory = '" + cb_Subcategory_Name.Text + "' ", Gobj.Con);

            DataTable dt = new DataTable();
            sda.Fill(dt);

            dgv_View_Stock_Details.DataSource = dt;

            SqlCommand cmd = new SqlCommand();

            cmd.CommandText = "Select Product_Name From Product_Details where Subcategory = '" + cb_Subcategory_Name.Text + "' ";
            cmd.Connection = Gobj.Con;

            var Obj = cmd.ExecuteReader();

            while (Obj.Read())
            {
                cb_Product_Name.Items.Add(Obj.GetString(Obj.GetOrdinal("Product_Name")));
            }

            Gobj.DisconnectDB();
        }

        private void cb_Category_Name_SelectedIndexChanged(object sender, EventArgs e)
        {
            cb_Subcategory_Name.Items.Clear();
            cb_Subcategory_Name.Text = "";
            cb_Subcategory_Name.Enabled = true;
            cb_Product_Name.Items.Clear();

            Bind_Subcategories_To_ComboBox();
        }

        private void cb_Subcategory_Name_SelectedIndexChanged(object sender, EventArgs e)
        {
            cb_Product_Name.Items.Clear();
            cb_Product_Name.Text = "";
            cb_Product_Name.Enabled = true;

            Bind_Products_To_ComboBox();
        }

        private void cb_Product_Name_SelectedIndexChanged(object sender, EventArgs e)
        {
            cb_Category_Name.Enabled = false;
            cb_Subcategory_Name.Enabled = false;
            cb_Product_Name.Enabled = false;

            SqlDataAdapter sda = new SqlDataAdapter("Select * From Stock_Details where  Product_Name = '" + cb_Product_Name.Text + "' ", Gobj.Con);

            DataTable dt = new DataTable();
            sda.Fill(dt);

            dgv_View_Stock_Details.DataSource = dt;

            btn_Refresh.Enabled = true;
        }

        private void btn_Refresh_Click(object sender, EventArgs e)
        {
            Clear_Controls();

            SqlDataAdapter sda = new SqlDataAdapter("Select * From Stock_Details", Gobj.Con);

            DataTable dt = new DataTable();
            sda.Fill(dt);

            dgv_View_Stock_Details.DataSource = dt;
        }

        private void pb_Back_Click(object sender, EventArgs e)
        {
            frm_Product_Entry_Form obj = new frm_Product_Entry_Form();

            obj.WindowState = FormWindowState.Maximized;
            this.Hide();
            obj.Show();
        }

        private void pb_Close_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show("Do You Want To Close This Appllication?", "close Application", MessageBoxButtons.YesNo);

            if (result == DialogResult.Yes)
            {
                frm_Login obj = new frm_Login();
                this.Hide();
                obj.Show();
            }
            else
            {
                this.Show();
            }
        }
    }
}
