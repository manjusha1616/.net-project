﻿namespace Computer_And_Mobile_Shoppee_Management_System
{
    partial class frm_Search_Or_Update_Employee
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frm_Search_Or_Update_Employee));
            this.dtp_Joining_Date = new System.Windows.Forms.DateTimePicker();
            this.pnl_Search_Or_Update_Emp = new System.Windows.Forms.Panel();
            this.pb_Close = new System.Windows.Forms.PictureBox();
            this.lbl_Header = new System.Windows.Forms.Label();
            this.pb_Back = new System.Windows.Forms.PictureBox();
            this.dtp_DOB = new System.Windows.Forms.DateTimePicker();
            this.tb_Email_ID = new System.Windows.Forms.TextBox();
            this.btn_Search = new System.Windows.Forms.Button();
            this.tb_Salary = new System.Windows.Forms.TextBox();
            this.lbl_Emp_ID = new System.Windows.Forms.Label();
            this.tb_Aadhar_Card_No = new System.Windows.Forms.TextBox();
            this.tb_Pan_Card_No = new System.Windows.Forms.TextBox();
            this.btn_Save = new System.Windows.Forms.Button();
            this.tb_Mob_No2 = new System.Windows.Forms.TextBox();
            this.tb_Mob_No1 = new System.Windows.Forms.TextBox();
            this.tb_Emp_ID = new System.Windows.Forms.TextBox();
            this.tb_Address = new System.Windows.Forms.TextBox();
            this.btn_Update = new System.Windows.Forms.Button();
            this.tb_Emp_Name = new System.Windows.Forms.TextBox();
            this.pnl_Search_Emp_ID = new System.Windows.Forms.Panel();
            this.lbl_Pan_Card_No = new System.Windows.Forms.Label();
            this.lbl_Aadhar_Card_No = new System.Windows.Forms.Label();
            this.lbl_Salary = new System.Windows.Forms.Label();
            this.btn_Refresh = new System.Windows.Forms.Button();
            this.lbl_Mob_No2 = new System.Windows.Forms.Label();
            this.lbl_Address = new System.Windows.Forms.Label();
            this.lbl_Mob_No1 = new System.Windows.Forms.Label();
            this.lbl_DOB = new System.Windows.Forms.Label();
            this.gb_Search_Or_Update_Emp = new System.Windows.Forms.GroupBox();
            this.lbl_Email_ID = new System.Windows.Forms.Label();
            this.lbl_Joining_Date = new System.Windows.Forms.Label();
            this.lbl_Emp_Name = new System.Windows.Forms.Label();
            this.pnl_Search_Or_Update_Emp.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pb_Close)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_Back)).BeginInit();
            this.pnl_Search_Emp_ID.SuspendLayout();
            this.gb_Search_Or_Update_Emp.SuspendLayout();
            this.SuspendLayout();
            // 
            // dtp_Joining_Date
            // 
            this.dtp_Joining_Date.Enabled = false;
            this.dtp_Joining_Date.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtp_Joining_Date.Location = new System.Drawing.Point(962, 252);
            this.dtp_Joining_Date.Name = "dtp_Joining_Date";
            this.dtp_Joining_Date.Size = new System.Drawing.Size(263, 29);
            this.dtp_Joining_Date.TabIndex = 0;
            // 
            // pnl_Search_Or_Update_Emp
            // 
            this.pnl_Search_Or_Update_Emp.BackColor = System.Drawing.Color.Indigo;
            this.pnl_Search_Or_Update_Emp.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pnl_Search_Or_Update_Emp.Controls.Add(this.pb_Close);
            this.pnl_Search_Or_Update_Emp.Controls.Add(this.lbl_Header);
            this.pnl_Search_Or_Update_Emp.Controls.Add(this.pb_Back);
            this.pnl_Search_Or_Update_Emp.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnl_Search_Or_Update_Emp.Location = new System.Drawing.Point(0, 0);
            this.pnl_Search_Or_Update_Emp.Name = "pnl_Search_Or_Update_Emp";
            this.pnl_Search_Or_Update_Emp.Size = new System.Drawing.Size(1344, 98);
            this.pnl_Search_Or_Update_Emp.TabIndex = 16;
            // 
            // pb_Close
            // 
            this.pb_Close.Image = ((System.Drawing.Image)(resources.GetObject("pb_Close.Image")));
            this.pb_Close.Location = new System.Drawing.Point(1227, 24);
            this.pb_Close.Name = "pb_Close";
            this.pb_Close.Size = new System.Drawing.Size(105, 55);
            this.pb_Close.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pb_Close.TabIndex = 15;
            this.pb_Close.TabStop = false;
            this.pb_Close.Click += new System.EventHandler(this.pb_Close_Click);
            // 
            // lbl_Header
            // 
            this.lbl_Header.AutoSize = true;
            this.lbl_Header.Font = new System.Drawing.Font("Lucida Bright", 27.75F, System.Drawing.FontStyle.Bold);
            this.lbl_Header.ForeColor = System.Drawing.Color.LavenderBlush;
            this.lbl_Header.Location = new System.Drawing.Point(412, 24);
            this.lbl_Header.Name = "lbl_Header";
            this.lbl_Header.Size = new System.Drawing.Size(536, 42);
            this.lbl_Header.TabIndex = 0;
            this.lbl_Header.Text = "Search Or Update Employee";
            // 
            // pb_Back
            // 
            this.pb_Back.Image = ((System.Drawing.Image)(resources.GetObject("pb_Back.Image")));
            this.pb_Back.Location = new System.Drawing.Point(12, 24);
            this.pb_Back.Name = "pb_Back";
            this.pb_Back.Size = new System.Drawing.Size(100, 50);
            this.pb_Back.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pb_Back.TabIndex = 14;
            this.pb_Back.TabStop = false;
            this.pb_Back.Click += new System.EventHandler(this.pb_Back_Click);
            // 
            // dtp_DOB
            // 
            this.dtp_DOB.Enabled = false;
            this.dtp_DOB.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtp_DOB.Location = new System.Drawing.Point(330, 253);
            this.dtp_DOB.Name = "dtp_DOB";
            this.dtp_DOB.Size = new System.Drawing.Size(263, 29);
            this.dtp_DOB.TabIndex = 0;
            // 
            // tb_Email_ID
            // 
            this.tb_Email_ID.Font = new System.Drawing.Font("Lucida Bright", 14.25F);
            this.tb_Email_ID.Location = new System.Drawing.Point(962, 191);
            this.tb_Email_ID.Name = "tb_Email_ID";
            this.tb_Email_ID.Size = new System.Drawing.Size(263, 30);
            this.tb_Email_ID.TabIndex = 7;
            // 
            // btn_Search
            // 
            this.btn_Search.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.btn_Search.Font = new System.Drawing.Font("Lucida Bright", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Search.ForeColor = System.Drawing.Color.White;
            this.btn_Search.Location = new System.Drawing.Point(583, 5);
            this.btn_Search.Name = "btn_Search";
            this.btn_Search.Size = new System.Drawing.Size(138, 50);
            this.btn_Search.TabIndex = 2;
            this.btn_Search.Text = "Search";
            this.btn_Search.UseVisualStyleBackColor = false;
            this.btn_Search.Click += new System.EventHandler(this.btn_Search_Click);
            // 
            // tb_Salary
            // 
            this.tb_Salary.Font = new System.Drawing.Font("Lucida Bright", 14.25F);
            this.tb_Salary.Location = new System.Drawing.Point(962, 308);
            this.tb_Salary.Name = "tb_Salary";
            this.tb_Salary.Size = new System.Drawing.Size(263, 30);
            this.tb_Salary.TabIndex = 8;
            // 
            // lbl_Emp_ID
            // 
            this.lbl_Emp_ID.AutoSize = true;
            this.lbl_Emp_ID.BackColor = System.Drawing.Color.SeaShell;
            this.lbl_Emp_ID.Font = new System.Drawing.Font("Lucida Bright", 14.25F);
            this.lbl_Emp_ID.ForeColor = System.Drawing.Color.DarkRed;
            this.lbl_Emp_ID.Location = new System.Drawing.Point(40, 19);
            this.lbl_Emp_ID.Name = "lbl_Emp_ID";
            this.lbl_Emp_ID.Size = new System.Drawing.Size(125, 22);
            this.lbl_Emp_ID.TabIndex = 0;
            this.lbl_Emp_ID.Text = "Employee ID";
            // 
            // tb_Aadhar_Card_No
            // 
            this.tb_Aadhar_Card_No.Enabled = false;
            this.tb_Aadhar_Card_No.Font = new System.Drawing.Font("Lucida Bright", 14.25F);
            this.tb_Aadhar_Card_No.Location = new System.Drawing.Point(962, 372);
            this.tb_Aadhar_Card_No.MaxLength = 14;
            this.tb_Aadhar_Card_No.Name = "tb_Aadhar_Card_No";
            this.tb_Aadhar_Card_No.Size = new System.Drawing.Size(263, 30);
            this.tb_Aadhar_Card_No.TabIndex = 0;
            // 
            // tb_Pan_Card_No
            // 
            this.tb_Pan_Card_No.Enabled = false;
            this.tb_Pan_Card_No.Font = new System.Drawing.Font("Lucida Bright", 14.25F);
            this.tb_Pan_Card_No.Location = new System.Drawing.Point(962, 428);
            this.tb_Pan_Card_No.MaxLength = 10;
            this.tb_Pan_Card_No.Name = "tb_Pan_Card_No";
            this.tb_Pan_Card_No.Size = new System.Drawing.Size(263, 30);
            this.tb_Pan_Card_No.TabIndex = 0;
            // 
            // btn_Save
            // 
            this.btn_Save.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.btn_Save.Font = new System.Drawing.Font("Lucida Bright", 27.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Save.ForeColor = System.Drawing.Color.White;
            this.btn_Save.Location = new System.Drawing.Point(373, 630);
            this.btn_Save.Name = "btn_Save";
            this.btn_Save.Size = new System.Drawing.Size(127, 56);
            this.btn_Save.TabIndex = 9;
            this.btn_Save.Text = "Save";
            this.btn_Save.UseVisualStyleBackColor = false;
            this.btn_Save.Click += new System.EventHandler(this.btn_Save_Click);
            // 
            // tb_Mob_No2
            // 
            this.tb_Mob_No2.Font = new System.Drawing.Font("Lucida Bright", 14.25F);
            this.tb_Mob_No2.Location = new System.Drawing.Point(330, 428);
            this.tb_Mob_No2.MaxLength = 10;
            this.tb_Mob_No2.Name = "tb_Mob_No2";
            this.tb_Mob_No2.Size = new System.Drawing.Size(263, 30);
            this.tb_Mob_No2.TabIndex = 6;
            this.tb_Mob_No2.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tb_Mob_No2_KeyPress);
            // 
            // tb_Mob_No1
            // 
            this.tb_Mob_No1.Font = new System.Drawing.Font("Lucida Bright", 14.25F);
            this.tb_Mob_No1.Location = new System.Drawing.Point(330, 369);
            this.tb_Mob_No1.MaxLength = 10;
            this.tb_Mob_No1.Name = "tb_Mob_No1";
            this.tb_Mob_No1.Size = new System.Drawing.Size(263, 30);
            this.tb_Mob_No1.TabIndex = 5;
            this.tb_Mob_No1.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tb_Mob_No1_KeyPress);
            // 
            // tb_Emp_ID
            // 
            this.tb_Emp_ID.Location = new System.Drawing.Point(196, 15);
            this.tb_Emp_ID.Name = "tb_Emp_ID";
            this.tb_Emp_ID.Size = new System.Drawing.Size(263, 29);
            this.tb_Emp_ID.TabIndex = 1;
            this.tb_Emp_ID.TextChanged += new System.EventHandler(this.tb_Emp_ID_TextChanged);
            this.tb_Emp_ID.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tb_Emp_ID_KeyPress);
            // 
            // tb_Address
            // 
            this.tb_Address.Enabled = false;
            this.tb_Address.Font = new System.Drawing.Font("Lucida Bright", 14.25F);
            this.tb_Address.Location = new System.Drawing.Point(330, 305);
            this.tb_Address.Name = "tb_Address";
            this.tb_Address.Size = new System.Drawing.Size(263, 30);
            this.tb_Address.TabIndex = 4;
            // 
            // btn_Update
            // 
            this.btn_Update.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.btn_Update.Font = new System.Drawing.Font("Lucida Bright", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Update.ForeColor = System.Drawing.Color.White;
            this.btn_Update.Location = new System.Drawing.Point(845, 5);
            this.btn_Update.Name = "btn_Update";
            this.btn_Update.Size = new System.Drawing.Size(150, 50);
            this.btn_Update.TabIndex = 3;
            this.btn_Update.Text = "Update";
            this.btn_Update.UseVisualStyleBackColor = false;
            this.btn_Update.Click += new System.EventHandler(this.btn_Update_Click);
            // 
            // tb_Emp_Name
            // 
            this.tb_Emp_Name.Enabled = false;
            this.tb_Emp_Name.Font = new System.Drawing.Font("Lucida Bright", 14.25F);
            this.tb_Emp_Name.Location = new System.Drawing.Point(330, 194);
            this.tb_Emp_Name.Name = "tb_Emp_Name";
            this.tb_Emp_Name.Size = new System.Drawing.Size(263, 30);
            this.tb_Emp_Name.TabIndex = 0;
            // 
            // pnl_Search_Emp_ID
            // 
            this.pnl_Search_Emp_ID.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.pnl_Search_Emp_ID.BackColor = System.Drawing.Color.Silver;
            this.pnl_Search_Emp_ID.Controls.Add(this.btn_Update);
            this.pnl_Search_Emp_ID.Controls.Add(this.btn_Search);
            this.pnl_Search_Emp_ID.Controls.Add(this.lbl_Emp_ID);
            this.pnl_Search_Emp_ID.Controls.Add(this.tb_Emp_ID);
            this.pnl_Search_Emp_ID.Location = new System.Drawing.Point(91, 67);
            this.pnl_Search_Emp_ID.Name = "pnl_Search_Emp_ID";
            this.pnl_Search_Emp_ID.Size = new System.Drawing.Size(1148, 63);
            this.pnl_Search_Emp_ID.TabIndex = 3;
            // 
            // lbl_Pan_Card_No
            // 
            this.lbl_Pan_Card_No.AutoSize = true;
            this.lbl_Pan_Card_No.BackColor = System.Drawing.Color.SeaShell;
            this.lbl_Pan_Card_No.Font = new System.Drawing.Font("Lucida Bright", 14.25F);
            this.lbl_Pan_Card_No.ForeColor = System.Drawing.Color.DarkRed;
            this.lbl_Pan_Card_No.Location = new System.Drawing.Point(724, 428);
            this.lbl_Pan_Card_No.Name = "lbl_Pan_Card_No";
            this.lbl_Pan_Card_No.Size = new System.Drawing.Size(126, 22);
            this.lbl_Pan_Card_No.TabIndex = 0;
            this.lbl_Pan_Card_No.Text = "Pan Card No";
            // 
            // lbl_Aadhar_Card_No
            // 
            this.lbl_Aadhar_Card_No.AutoSize = true;
            this.lbl_Aadhar_Card_No.BackColor = System.Drawing.Color.SeaShell;
            this.lbl_Aadhar_Card_No.Font = new System.Drawing.Font("Lucida Bright", 14.25F);
            this.lbl_Aadhar_Card_No.ForeColor = System.Drawing.Color.DarkRed;
            this.lbl_Aadhar_Card_No.Location = new System.Drawing.Point(724, 372);
            this.lbl_Aadhar_Card_No.Name = "lbl_Aadhar_Card_No";
            this.lbl_Aadhar_Card_No.Size = new System.Drawing.Size(162, 22);
            this.lbl_Aadhar_Card_No.TabIndex = 0;
            this.lbl_Aadhar_Card_No.Text = "Aadhar Card No";
            // 
            // lbl_Salary
            // 
            this.lbl_Salary.AutoSize = true;
            this.lbl_Salary.BackColor = System.Drawing.Color.SeaShell;
            this.lbl_Salary.Font = new System.Drawing.Font("Lucida Bright", 14.25F);
            this.lbl_Salary.ForeColor = System.Drawing.Color.DarkRed;
            this.lbl_Salary.Location = new System.Drawing.Point(724, 308);
            this.lbl_Salary.Name = "lbl_Salary";
            this.lbl_Salary.Size = new System.Drawing.Size(67, 22);
            this.lbl_Salary.TabIndex = 0;
            this.lbl_Salary.Text = "Salary";
            // 
            // btn_Refresh
            // 
            this.btn_Refresh.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.btn_Refresh.Font = new System.Drawing.Font("Lucida Bright", 27.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Refresh.ForeColor = System.Drawing.Color.White;
            this.btn_Refresh.Location = new System.Drawing.Point(879, 630);
            this.btn_Refresh.Name = "btn_Refresh";
            this.btn_Refresh.Size = new System.Drawing.Size(170, 56);
            this.btn_Refresh.TabIndex = 10;
            this.btn_Refresh.Text = "Refresh";
            this.btn_Refresh.UseVisualStyleBackColor = false;
            this.btn_Refresh.Click += new System.EventHandler(this.btn_Refresh_Click);
            // 
            // lbl_Mob_No2
            // 
            this.lbl_Mob_No2.AutoSize = true;
            this.lbl_Mob_No2.BackColor = System.Drawing.Color.SeaShell;
            this.lbl_Mob_No2.Font = new System.Drawing.Font("Lucida Bright", 14.25F);
            this.lbl_Mob_No2.ForeColor = System.Drawing.Color.DarkRed;
            this.lbl_Mob_No2.Location = new System.Drawing.Point(107, 428);
            this.lbl_Mob_No2.Name = "lbl_Mob_No2";
            this.lbl_Mob_No2.Size = new System.Drawing.Size(121, 22);
            this.lbl_Mob_No2.TabIndex = 0;
            this.lbl_Mob_No2.Text = "Mobile No 2";
            // 
            // lbl_Address
            // 
            this.lbl_Address.AutoSize = true;
            this.lbl_Address.BackColor = System.Drawing.Color.SeaShell;
            this.lbl_Address.Font = new System.Drawing.Font("Lucida Bright", 14.25F);
            this.lbl_Address.ForeColor = System.Drawing.Color.DarkRed;
            this.lbl_Address.Location = new System.Drawing.Point(107, 308);
            this.lbl_Address.Name = "lbl_Address";
            this.lbl_Address.Size = new System.Drawing.Size(85, 22);
            this.lbl_Address.TabIndex = 0;
            this.lbl_Address.Text = "Address";
            // 
            // lbl_Mob_No1
            // 
            this.lbl_Mob_No1.AutoSize = true;
            this.lbl_Mob_No1.BackColor = System.Drawing.Color.SeaShell;
            this.lbl_Mob_No1.Font = new System.Drawing.Font("Lucida Bright", 14.25F);
            this.lbl_Mob_No1.ForeColor = System.Drawing.Color.DarkRed;
            this.lbl_Mob_No1.Location = new System.Drawing.Point(107, 372);
            this.lbl_Mob_No1.Name = "lbl_Mob_No1";
            this.lbl_Mob_No1.Size = new System.Drawing.Size(121, 22);
            this.lbl_Mob_No1.TabIndex = 0;
            this.lbl_Mob_No1.Text = "Mobile No 1";
            // 
            // lbl_DOB
            // 
            this.lbl_DOB.AutoSize = true;
            this.lbl_DOB.BackColor = System.Drawing.Color.SeaShell;
            this.lbl_DOB.Font = new System.Drawing.Font("Lucida Bright", 14.25F);
            this.lbl_DOB.ForeColor = System.Drawing.Color.DarkRed;
            this.lbl_DOB.Location = new System.Drawing.Point(107, 252);
            this.lbl_DOB.Name = "lbl_DOB";
            this.lbl_DOB.Size = new System.Drawing.Size(131, 22);
            this.lbl_DOB.TabIndex = 0;
            this.lbl_DOB.Text = "Date Of Birth";
            // 
            // gb_Search_Or_Update_Emp
            // 
            this.gb_Search_Or_Update_Emp.Controls.Add(this.dtp_Joining_Date);
            this.gb_Search_Or_Update_Emp.Controls.Add(this.dtp_DOB);
            this.gb_Search_Or_Update_Emp.Controls.Add(this.tb_Email_ID);
            this.gb_Search_Or_Update_Emp.Controls.Add(this.tb_Salary);
            this.gb_Search_Or_Update_Emp.Controls.Add(this.tb_Aadhar_Card_No);
            this.gb_Search_Or_Update_Emp.Controls.Add(this.tb_Pan_Card_No);
            this.gb_Search_Or_Update_Emp.Controls.Add(this.tb_Mob_No2);
            this.gb_Search_Or_Update_Emp.Controls.Add(this.tb_Mob_No1);
            this.gb_Search_Or_Update_Emp.Controls.Add(this.tb_Address);
            this.gb_Search_Or_Update_Emp.Controls.Add(this.tb_Emp_Name);
            this.gb_Search_Or_Update_Emp.Controls.Add(this.pnl_Search_Emp_ID);
            this.gb_Search_Or_Update_Emp.Controls.Add(this.lbl_Pan_Card_No);
            this.gb_Search_Or_Update_Emp.Controls.Add(this.lbl_Aadhar_Card_No);
            this.gb_Search_Or_Update_Emp.Controls.Add(this.lbl_Salary);
            this.gb_Search_Or_Update_Emp.Controls.Add(this.lbl_Mob_No2);
            this.gb_Search_Or_Update_Emp.Controls.Add(this.lbl_Address);
            this.gb_Search_Or_Update_Emp.Controls.Add(this.lbl_Mob_No1);
            this.gb_Search_Or_Update_Emp.Controls.Add(this.lbl_DOB);
            this.gb_Search_Or_Update_Emp.Controls.Add(this.lbl_Email_ID);
            this.gb_Search_Or_Update_Emp.Controls.Add(this.lbl_Joining_Date);
            this.gb_Search_Or_Update_Emp.Controls.Add(this.lbl_Emp_Name);
            this.gb_Search_Or_Update_Emp.Font = new System.Drawing.Font("Georgia", 14.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))));
            this.gb_Search_Or_Update_Emp.ForeColor = System.Drawing.Color.Black;
            this.gb_Search_Or_Update_Emp.Location = new System.Drawing.Point(12, 104);
            this.gb_Search_Or_Update_Emp.Name = "gb_Search_Or_Update_Emp";
            this.gb_Search_Or_Update_Emp.Size = new System.Drawing.Size(1320, 508);
            this.gb_Search_Or_Update_Emp.TabIndex = 17;
            this.gb_Search_Or_Update_Emp.TabStop = false;
            this.gb_Search_Or_Update_Emp.Text = "Search Or Update Employee";
            // 
            // lbl_Email_ID
            // 
            this.lbl_Email_ID.AutoSize = true;
            this.lbl_Email_ID.BackColor = System.Drawing.Color.SeaShell;
            this.lbl_Email_ID.Font = new System.Drawing.Font("Lucida Bright", 14.25F);
            this.lbl_Email_ID.ForeColor = System.Drawing.Color.DarkRed;
            this.lbl_Email_ID.Location = new System.Drawing.Point(724, 194);
            this.lbl_Email_ID.Name = "lbl_Email_ID";
            this.lbl_Email_ID.Size = new System.Drawing.Size(88, 22);
            this.lbl_Email_ID.TabIndex = 0;
            this.lbl_Email_ID.Text = "Email ID";
            // 
            // lbl_Joining_Date
            // 
            this.lbl_Joining_Date.AutoSize = true;
            this.lbl_Joining_Date.BackColor = System.Drawing.Color.SeaShell;
            this.lbl_Joining_Date.Font = new System.Drawing.Font("Lucida Bright", 14.25F);
            this.lbl_Joining_Date.ForeColor = System.Drawing.Color.DarkRed;
            this.lbl_Joining_Date.Location = new System.Drawing.Point(724, 248);
            this.lbl_Joining_Date.Name = "lbl_Joining_Date";
            this.lbl_Joining_Date.Size = new System.Drawing.Size(125, 22);
            this.lbl_Joining_Date.TabIndex = 0;
            this.lbl_Joining_Date.Text = "Joining Date";
            // 
            // lbl_Emp_Name
            // 
            this.lbl_Emp_Name.AutoSize = true;
            this.lbl_Emp_Name.BackColor = System.Drawing.Color.SeaShell;
            this.lbl_Emp_Name.Font = new System.Drawing.Font("Lucida Bright", 14.25F);
            this.lbl_Emp_Name.ForeColor = System.Drawing.Color.DarkRed;
            this.lbl_Emp_Name.Location = new System.Drawing.Point(107, 194);
            this.lbl_Emp_Name.Name = "lbl_Emp_Name";
            this.lbl_Emp_Name.Size = new System.Drawing.Size(158, 22);
            this.lbl_Emp_Name.TabIndex = 0;
            this.lbl_Emp_Name.Text = "Employee Name";
            // 
            // frm_Search_Or_Update_Employee
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(15F, 28F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.ClientSize = new System.Drawing.Size(1344, 712);
            this.Controls.Add(this.pnl_Search_Or_Update_Emp);
            this.Controls.Add(this.btn_Save);
            this.Controls.Add(this.btn_Refresh);
            this.Controls.Add(this.gb_Search_Or_Update_Emp);
            this.Font = new System.Drawing.Font("Lucida Bright", 18F);
            this.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.Margin = new System.Windows.Forms.Padding(8, 6, 8, 6);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "frm_Search_Or_Update_Employee";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Search Or Update Employee";
            this.Load += new System.EventHandler(this.frm_Search_Or_Update_Employee_Load);
            this.pnl_Search_Or_Update_Emp.ResumeLayout(false);
            this.pnl_Search_Or_Update_Emp.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pb_Close)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_Back)).EndInit();
            this.pnl_Search_Emp_ID.ResumeLayout(false);
            this.pnl_Search_Emp_ID.PerformLayout();
            this.gb_Search_Or_Update_Emp.ResumeLayout(false);
            this.gb_Search_Or_Update_Emp.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DateTimePicker dtp_Joining_Date;
        private System.Windows.Forms.Panel pnl_Search_Or_Update_Emp;
        private System.Windows.Forms.PictureBox pb_Close;
        private System.Windows.Forms.Label lbl_Header;
        private System.Windows.Forms.PictureBox pb_Back;
        private System.Windows.Forms.DateTimePicker dtp_DOB;
        private System.Windows.Forms.TextBox tb_Email_ID;
        private System.Windows.Forms.Button btn_Search;
        private System.Windows.Forms.TextBox tb_Salary;
        private System.Windows.Forms.Label lbl_Emp_ID;
        private System.Windows.Forms.TextBox tb_Aadhar_Card_No;
        private System.Windows.Forms.TextBox tb_Pan_Card_No;
        private System.Windows.Forms.Button btn_Save;
        private System.Windows.Forms.TextBox tb_Mob_No2;
        private System.Windows.Forms.TextBox tb_Mob_No1;
        private System.Windows.Forms.TextBox tb_Emp_ID;
        private System.Windows.Forms.TextBox tb_Address;
        private System.Windows.Forms.Button btn_Update;
        private System.Windows.Forms.TextBox tb_Emp_Name;
        private System.Windows.Forms.Panel pnl_Search_Emp_ID;
        private System.Windows.Forms.Label lbl_Pan_Card_No;
        private System.Windows.Forms.Label lbl_Aadhar_Card_No;
        private System.Windows.Forms.Label lbl_Salary;
        private System.Windows.Forms.Button btn_Refresh;
        private System.Windows.Forms.Label lbl_Mob_No2;
        private System.Windows.Forms.Label lbl_Address;
        private System.Windows.Forms.Label lbl_Mob_No1;
        private System.Windows.Forms.Label lbl_DOB;
        private System.Windows.Forms.GroupBox gb_Search_Or_Update_Emp;
        private System.Windows.Forms.Label lbl_Email_ID;
        private System.Windows.Forms.Label lbl_Joining_Date;
        private System.Windows.Forms.Label lbl_Emp_Name;
    }
}