﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Computer_And_Mobile_Shoppee_Management_System
{
    public partial class frm_Search_Or_Update_Employee : Form
    {
        Global_ClassFile Gobj = new Global_ClassFile();

        public frm_Search_Or_Update_Employee()
        {
            InitializeComponent();
        }       

        private void frm_Search_Or_Update_Employee_Load(object sender, EventArgs e)
        {
            Clear_Controls();
        }

        void Clear_Controls()
        {
            tb_Emp_ID.Focus();
            tb_Emp_ID.Text = "";
            tb_Emp_Name.Text = " ";
            dtp_DOB.ResetText();
            tb_Address.Text = "";
            tb_Mob_No1.Text = "";
            tb_Mob_No2.Text = "";
            tb_Email_ID.Text = "";
            dtp_Joining_Date.ResetText();
            tb_Salary.Text = "";
            tb_Aadhar_Card_No.Text = "";
            tb_Pan_Card_No.Text = "";
            tb_Emp_Name.Enabled = false;
            dtp_DOB.Enabled = false;
            tb_Address.Enabled = false;
            tb_Mob_No1.Enabled = false;
            tb_Mob_No2.Enabled = false;
            tb_Email_ID.Enabled = false;
            dtp_Joining_Date.Enabled = false;
            tb_Salary.Enabled = false;
            tb_Aadhar_Card_No.Enabled = false;
            tb_Pan_Card_No.Enabled = false;
            tb_Emp_ID.Enabled = true;
            btn_Search.Enabled = false;
            btn_Update.Enabled = false;
        }

        void Search_Details()
        {
            Gobj.ConnectDB();

            SqlCommand cmd = new SqlCommand("Select * from Employee_Details where Employee_ID = " + tb_Emp_ID.Text + " ", Gobj.Con);

            var obj = cmd.ExecuteReader();

            if (obj.Read())
            {
                tb_Emp_Name.Text = obj.GetString(obj.GetOrdinal("Employee_Name"));
                dtp_DOB.Text = (obj["Date_Of_Birth"].ToString());
                tb_Address.Text = obj.GetString(obj.GetOrdinal("Address"));
                tb_Email_ID.Text = obj.GetString(obj.GetOrdinal("Email_ID"));
                dtp_Joining_Date.Text = (obj["Joining_Date"].ToString());
                tb_Mob_No1.Text = (obj["Mobile_No_1"].ToString());
                tb_Mob_No2.Text = (obj["Mobile_No_2"].ToString());
                tb_Aadhar_Card_No.Text = (obj["Aadhar_Card_No"].ToString());
                tb_Pan_Card_No.Text = (obj["Pan_Card_No"].ToString());
                tb_Salary.Text = (obj["Salary"].ToString());

                tb_Email_ID.Enabled = true;
                tb_Emp_Name.Enabled = false;
                dtp_DOB.Enabled = false;
                tb_Address.Enabled = false;
                tb_Mob_No1.Enabled = false;
                tb_Mob_No2.Enabled = false;
                tb_Email_ID.Enabled = false;
                dtp_Joining_Date.Enabled = false;
                tb_Salary.Enabled = false;
                tb_Aadhar_Card_No.Enabled = false;
                tb_Pan_Card_No.Enabled = false;
                btn_Update.Enabled = true;
            }
            else
            {
                MessageBox.Show("Invalid Employee ID", "Failure", MessageBoxButtons.OK, MessageBoxIcon.Error);
                Clear_Controls();
            }

            Gobj.DisconnectDB();
        }

        private void tb_Emp_ID_TextChanged(object sender, EventArgs e)
        {
            btn_Search.Enabled = true;
        }

        private void btn_Search_Click(object sender, EventArgs e)
        {
            tb_Emp_ID.Enabled = false;
            Search_Details();
        }

        private void tb_Mob_No1_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!(Char.IsDigit(e.KeyChar) || (e.KeyChar == (char)Keys.Back)))
            {
                e.Handled = true;
            }
        }

        private void tb_Emp_ID_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!(Char.IsDigit(e.KeyChar) || (e.KeyChar == (char)Keys.Back)))
            {
                e.Handled = true;
            }
        }

        private void tb_Mob_No2_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!(Char.IsDigit(e.KeyChar) || (e.KeyChar == (char)Keys.Back)))
            {
                e.Handled = true;
            }
        }

        private void btn_Update_Click(object sender, EventArgs e)
        {
            tb_Address.Focus();
            tb_Address.Enabled = true;
            tb_Mob_No1.Enabled = true;
            tb_Mob_No2.Enabled = true;
            tb_Email_ID.Enabled = true;
            tb_Salary.Enabled = true;
        }

        private void btn_Save_Click(object sender, EventArgs e)
        {
            if (tb_Mob_No1.TextLength < 10)
            {
                MessageBox.Show("Invalid Mobile Number", "Failure", MessageBoxButtons.OK, MessageBoxIcon.Error);
                tb_Mob_No1.Focus();
                goto DWN;
            }

            long Mob_No2 = 0;
            if (tb_Mob_No2.Text != "")
            {                
                Mob_No2 = Convert.ToInt64(tb_Mob_No2.Text);
            }

            Gobj.ConnectDB();

            if (tb_Emp_ID.Text != "" && tb_Emp_Name.Text != "" && tb_Address.Text != "" && tb_Mob_No1.Text != "" && tb_Aadhar_Card_No.Text != "" && tb_Pan_Card_No.Text != "" && tb_Salary.Text != "")
            {
                SqlDataAdapter sda = new SqlDataAdapter(" Update Employee_Details Set Employee_Name = '" + tb_Emp_Name.Text + "',Date_Of_Birth = '" + dtp_DOB.Text + "', Address = '" + tb_Address.Text + "', Mobile_No_1= " + tb_Mob_No1.Text + ", Mobile_No_2 = " + Mob_No2 + ", Email_ID = '" + tb_Email_ID.Text + "', Joining_Date = '" + dtp_Joining_Date.Text + "', Salary = " + tb_Salary.Text + ", Aadhar_Card_No= " + tb_Aadhar_Card_No.Text + ", Pan_Card_No= '" + tb_Pan_Card_No.Text + "', Updaters_Uname = '" + Global_ClassFile.Uname + "' Where Employee_ID = " + tb_Emp_ID.Text + "", Gobj.Con);

                DataTable dt = new DataTable();
                sda.Fill(dt);

                MessageBox.Show("Record Saved Successfully...", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);

                tb_Emp_ID.Enabled = true;
                Clear_Controls();
            }
            else
            {
                MessageBox.Show("Please, Fill All The Fields", "Failure", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

            DWN:
            Gobj.DisconnectDB();
        }

        private void btn_Refresh_Click(object sender, EventArgs e)
        {
            Clear_Controls();
            tb_Emp_ID.Focus();
        }

        private void pb_Back_Click(object sender, EventArgs e)
        {
            frm_Employee_Entry_Form Obj = new frm_Employee_Entry_Form();

            Obj.WindowState = FormWindowState.Maximized;
            this.Hide();
            Obj.Show();
        }

        private void pb_Close_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show("Do You Want To Close This Appllication?", "close Application", MessageBoxButtons.YesNo);

            if (result == DialogResult.Yes)
            {
                frm_Login obj = new frm_Login();
                this.Hide();
                obj.Show();
            }
            else
            {
                this.Show();
            }
        }
    }
}
