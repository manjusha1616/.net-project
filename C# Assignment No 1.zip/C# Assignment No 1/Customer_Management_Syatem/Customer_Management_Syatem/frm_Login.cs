﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Customer_Management_Syatem
{
    public partial class frm_Login : Form
    {
        public frm_Login()
        {
            InitializeComponent();
        }

        private void btn_Submit_Click(object sender, EventArgs e)
        {
            if (tb_Username.Text == "a" && tb_Password.Text == "a")
            {
                MessageBox.Show("Login Sucessfull!!!");
                frm_Add_New_Customer obj = new frm_Add_New_Customer();
                obj.Show();
                this.Hide();
            }
            else
            {
                MessageBox.Show("Login Failed Please Enter Valid Username & Password");
            }

            tb_Username.Text = "";
            tb_Password.Text = "";
            tb_Username.Focus();
        }
    }
            
}
