﻿namespace Computer_And_Mobile_Shoppee_Management_System
{
    partial class frm_Add_New_Category
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frm_Add_New_Category));
            this.tb_Category_Name = new System.Windows.Forms.TextBox();
            this.tb_Category_ID = new System.Windows.Forms.TextBox();
            this.lbl_Category_Name = new System.Windows.Forms.Label();
            this.gb_Add_New_Category = new System.Windows.Forms.GroupBox();
            this.lbl_Category_ID = new System.Windows.Forms.Label();
            this.btn_Save = new System.Windows.Forms.Button();
            this.pb_Back = new System.Windows.Forms.PictureBox();
            this.pnl_Add_New_Category = new System.Windows.Forms.Panel();
            this.lbl_Header = new System.Windows.Forms.Label();
            this.gb_Add_New_Category.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pb_Back)).BeginInit();
            this.pnl_Add_New_Category.SuspendLayout();
            this.SuspendLayout();
            // 
            // tb_Category_Name
            // 
            this.tb_Category_Name.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_Category_Name.Location = new System.Drawing.Point(403, 168);
            this.tb_Category_Name.Name = "tb_Category_Name";
            this.tb_Category_Name.Size = new System.Drawing.Size(273, 31);
            this.tb_Category_Name.TabIndex = 2;
            this.tb_Category_Name.TextChanged += new System.EventHandler(this.tb_Category_Name_TextChanged);
            // 
            // tb_Category_ID
            // 
            this.tb_Category_ID.Enabled = false;
            this.tb_Category_ID.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_Category_ID.Location = new System.Drawing.Point(403, 73);
            this.tb_Category_ID.Name = "tb_Category_ID";
            this.tb_Category_ID.Size = new System.Drawing.Size(273, 31);
            this.tb_Category_ID.TabIndex = 1;
            this.tb_Category_ID.TextChanged += new System.EventHandler(this.tb_Category_ID_TextChanged);
            // 
            // lbl_Category_Name
            // 
            this.lbl_Category_Name.AutoSize = true;
            this.lbl_Category_Name.BackColor = System.Drawing.Color.SeaShell;
            this.lbl_Category_Name.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Category_Name.ForeColor = System.Drawing.Color.DarkRed;
            this.lbl_Category_Name.Location = new System.Drawing.Point(118, 168);
            this.lbl_Category_Name.Name = "lbl_Category_Name";
            this.lbl_Category_Name.Size = new System.Drawing.Size(161, 25);
            this.lbl_Category_Name.TabIndex = 14;
            this.lbl_Category_Name.Text = "Category Name";
            // 
            // gb_Add_New_Category
            // 
            this.gb_Add_New_Category.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.gb_Add_New_Category.Controls.Add(this.tb_Category_Name);
            this.gb_Add_New_Category.Controls.Add(this.tb_Category_ID);
            this.gb_Add_New_Category.Controls.Add(this.lbl_Category_Name);
            this.gb_Add_New_Category.Controls.Add(this.lbl_Category_ID);
            this.gb_Add_New_Category.Font = new System.Drawing.Font("Georgia", 14.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))));
            this.gb_Add_New_Category.ForeColor = System.Drawing.Color.Black;
            this.gb_Add_New_Category.Location = new System.Drawing.Point(12, 109);
            this.gb_Add_New_Category.Name = "gb_Add_New_Category";
            this.gb_Add_New_Category.Size = new System.Drawing.Size(780, 270);
            this.gb_Add_New_Category.TabIndex = 27;
            this.gb_Add_New_Category.TabStop = false;
            this.gb_Add_New_Category.Text = "Category Details";
            // 
            // lbl_Category_ID
            // 
            this.lbl_Category_ID.AutoSize = true;
            this.lbl_Category_ID.BackColor = System.Drawing.Color.SeaShell;
            this.lbl_Category_ID.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Category_ID.ForeColor = System.Drawing.Color.DarkRed;
            this.lbl_Category_ID.Location = new System.Drawing.Point(118, 73);
            this.lbl_Category_ID.Name = "lbl_Category_ID";
            this.lbl_Category_ID.Size = new System.Drawing.Size(125, 25);
            this.lbl_Category_ID.TabIndex = 13;
            this.lbl_Category_ID.Text = "Category ID";
            // 
            // btn_Save
            // 
            this.btn_Save.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.btn_Save.Font = new System.Drawing.Font("Lucida Bright", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Save.ForeColor = System.Drawing.Color.White;
            this.btn_Save.Location = new System.Drawing.Point(335, 400);
            this.btn_Save.Name = "btn_Save";
            this.btn_Save.Size = new System.Drawing.Size(127, 56);
            this.btn_Save.TabIndex = 26;
            this.btn_Save.Text = "Save";
            this.btn_Save.UseVisualStyleBackColor = false;
            this.btn_Save.Click += new System.EventHandler(this.btn_Save_Click);
            // 
            // pb_Back
            // 
            this.pb_Back.Image = ((System.Drawing.Image)(resources.GetObject("pb_Back.Image")));
            this.pb_Back.Location = new System.Drawing.Point(12, 17);
            this.pb_Back.Name = "pb_Back";
            this.pb_Back.Size = new System.Drawing.Size(95, 45);
            this.pb_Back.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pb_Back.TabIndex = 4;
            this.pb_Back.TabStop = false;
            this.pb_Back.Click += new System.EventHandler(this.pb_Back_Click);
            // 
            // pnl_Add_New_Category
            // 
            this.pnl_Add_New_Category.BackColor = System.Drawing.Color.Indigo;
            this.pnl_Add_New_Category.Controls.Add(this.pb_Back);
            this.pnl_Add_New_Category.Controls.Add(this.lbl_Header);
            this.pnl_Add_New_Category.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnl_Add_New_Category.Location = new System.Drawing.Point(0, 0);
            this.pnl_Add_New_Category.Name = "pnl_Add_New_Category";
            this.pnl_Add_New_Category.Size = new System.Drawing.Size(804, 92);
            this.pnl_Add_New_Category.TabIndex = 25;
            // 
            // lbl_Header
            // 
            this.lbl_Header.AutoSize = true;
            this.lbl_Header.BackColor = System.Drawing.Color.Indigo;
            this.lbl_Header.Font = new System.Drawing.Font("Lucida Bright", 27.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Header.ForeColor = System.Drawing.Color.LavenderBlush;
            this.lbl_Header.Location = new System.Drawing.Point(215, 25);
            this.lbl_Header.Name = "lbl_Header";
            this.lbl_Header.Size = new System.Drawing.Size(369, 42);
            this.lbl_Header.TabIndex = 0;
            this.lbl_Header.Text = "Add New Category";
            // 
            // frm_Add_New_Category
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(15F, 28F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.ClientSize = new System.Drawing.Size(804, 462);
            this.Controls.Add(this.gb_Add_New_Category);
            this.Controls.Add(this.btn_Save);
            this.Controls.Add(this.pnl_Add_New_Category);
            this.Font = new System.Drawing.Font("Lucida Bright", 18F);
            this.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.Margin = new System.Windows.Forms.Padding(8, 6, 8, 6);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "frm_Add_New_Category";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Add New Category";
            this.Load += new System.EventHandler(this.frm_Add_New_Category_Load);
            this.gb_Add_New_Category.ResumeLayout(false);
            this.gb_Add_New_Category.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pb_Back)).EndInit();
            this.pnl_Add_New_Category.ResumeLayout(false);
            this.pnl_Add_New_Category.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TextBox tb_Category_Name;
        private System.Windows.Forms.TextBox tb_Category_ID;
        private System.Windows.Forms.Label lbl_Category_Name;
        private System.Windows.Forms.GroupBox gb_Add_New_Category;
        private System.Windows.Forms.Label lbl_Category_ID;
        private System.Windows.Forms.Button btn_Save;
        private System.Windows.Forms.PictureBox pb_Back;
        private System.Windows.Forms.Panel pnl_Add_New_Category;
        private System.Windows.Forms.Label lbl_Header;
    }
}