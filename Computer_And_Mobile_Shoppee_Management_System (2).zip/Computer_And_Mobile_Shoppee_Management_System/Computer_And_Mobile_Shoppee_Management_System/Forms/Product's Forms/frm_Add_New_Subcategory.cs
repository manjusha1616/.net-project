﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Computer_And_Mobile_Shoppee_Management_System
{
    public partial class frm_Add_New_Subcategory : Form
    {
        Global_ClassFile Gobj = new Global_ClassFile();

        public frm_Add_New_Subcategory()
        {
            InitializeComponent();
        }

        int Auto_Incr()
        {
            Gobj.ConnectDB();

            int Cnt = 0;

            SqlCommand Cmd = new SqlCommand();

            Cmd.CommandText = "Select Count(Subcategory_ID) from Subcategory_Details";
            Cmd.Connection = Gobj.Con;

            Cnt = Convert.ToInt32(Cmd.ExecuteScalar());

            Cmd.Dispose();

            if (Cnt > 0)
            {
                Cmd.CommandText = "Select Max(Subcategory_ID) from Subcategory_Details";
                Cmd.Connection = Gobj.Con;
            }

            Cnt = 1 + Cnt;

            Gobj.DisconnectDB();

            return Cnt;
        }

        void Clear_Controls()
        {
            tb_Subcategory_ID.Text = Convert.ToString(Auto_Incr());
            tb_Subcategory_Name.Text = " ";
            cb_Category_Name.Text = "";
            cb_Category_Name.Focus();
        }

        void Bind_Categories_To_Combobox()
        {
            Gobj.ConnectDB();

            SqlCommand Cmd = new SqlCommand("Select Distinct(Category_Name) From Category_Details", Gobj.Con);

            var obj = Cmd.ExecuteReader();

            while (obj.Read())
            {
                cb_Category_Name.Items.Add(obj.GetString(obj.GetOrdinal("Category_Name")));
            }

            obj.Dispose();

            Gobj.DisconnectDB();
        }

        private void frm_Add_New_Subcategory_Load(object sender, EventArgs e)
        {
            Clear_Controls();

            Bind_Categories_To_Combobox();
        }

        private void cb_Category_Name_SelectedIndexChanged(object sender, EventArgs e)
        {
            tb_Subcategory_Name.Focus();
        }

        private void tb_Subcategory_ID_TextChanged(object sender, EventArgs e)
        {
            tb_Subcategory_Name.Focus();
        }

        private void tb_Subcategory_Name_TextChanged(object sender, EventArgs e)
        {
            btn_Save.Enabled = true;
        }

        private void btn_Save_Click(object sender, EventArgs e)
        {
            Gobj.ConnectDB();

            if (tb_Subcategory_Name.Text != " ")
            {
                SqlDataAdapter sda = new SqlDataAdapter("Insert into Subcategory_Details values('" + cb_Category_Name.Text + "','" + tb_Subcategory_Name.Text + "','" + Global_ClassFile.Uname + "')", Gobj.Con);

                DataTable dt = new DataTable();
                sda.Fill(dt);

                MessageBox.Show("Record Saved Successfully...", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);

                Clear_Controls();
            }
            else
            {
                MessageBox.Show("Please, Fill All The Fields", "Failure", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

            Gobj.DisconnectDB();
        }

        private void pb_Back_Click(object sender, EventArgs e)
        {          
            this.Hide();
        }
    }
}
