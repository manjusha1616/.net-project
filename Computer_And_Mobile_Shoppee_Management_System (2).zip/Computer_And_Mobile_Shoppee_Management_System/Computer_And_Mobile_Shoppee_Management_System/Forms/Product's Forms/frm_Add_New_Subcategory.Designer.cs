﻿namespace Computer_And_Mobile_Shoppee_Management_System
{
    partial class frm_Add_New_Subcategory
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frm_Add_New_Subcategory));
            this.tb_Subcategory_Name = new System.Windows.Forms.TextBox();
            this.tb_Subcategory_ID = new System.Windows.Forms.TextBox();
            this.lbl_Subcategory_Name = new System.Windows.Forms.Label();
            this.lbl_Subcategory_ID = new System.Windows.Forms.Label();
            this.cb_Category_Name = new System.Windows.Forms.ComboBox();
            this.gb_Subcategory_Details = new System.Windows.Forms.GroupBox();
            this.lbl_Category_Name = new System.Windows.Forms.Label();
            this.btn_Save = new System.Windows.Forms.Button();
            this.pb_Back = new System.Windows.Forms.PictureBox();
            this.lbl_Header = new System.Windows.Forms.Label();
            this.pnl_Add_New_Subcategory = new System.Windows.Forms.Panel();
            this.gb_Subcategory_Details.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pb_Back)).BeginInit();
            this.pnl_Add_New_Subcategory.SuspendLayout();
            this.SuspendLayout();
            // 
            // tb_Subcategory_Name
            // 
            this.tb_Subcategory_Name.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_Subcategory_Name.Location = new System.Drawing.Point(401, 207);
            this.tb_Subcategory_Name.Name = "tb_Subcategory_Name";
            this.tb_Subcategory_Name.Size = new System.Drawing.Size(273, 31);
            this.tb_Subcategory_Name.TabIndex = 2;
            this.tb_Subcategory_Name.TextChanged += new System.EventHandler(this.tb_Subcategory_Name_TextChanged);
            // 
            // tb_Subcategory_ID
            // 
            this.tb_Subcategory_ID.Enabled = false;
            this.tb_Subcategory_ID.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_Subcategory_ID.Location = new System.Drawing.Point(401, 134);
            this.tb_Subcategory_ID.Name = "tb_Subcategory_ID";
            this.tb_Subcategory_ID.Size = new System.Drawing.Size(273, 31);
            this.tb_Subcategory_ID.TabIndex = 0;
            this.tb_Subcategory_ID.TextChanged += new System.EventHandler(this.tb_Subcategory_ID_TextChanged);
            // 
            // lbl_Subcategory_Name
            // 
            this.lbl_Subcategory_Name.AutoSize = true;
            this.lbl_Subcategory_Name.BackColor = System.Drawing.Color.SeaShell;
            this.lbl_Subcategory_Name.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Subcategory_Name.ForeColor = System.Drawing.Color.DarkRed;
            this.lbl_Subcategory_Name.Location = new System.Drawing.Point(112, 212);
            this.lbl_Subcategory_Name.Name = "lbl_Subcategory_Name";
            this.lbl_Subcategory_Name.Size = new System.Drawing.Size(195, 25);
            this.lbl_Subcategory_Name.TabIndex = 22;
            this.lbl_Subcategory_Name.Text = "Subcategory Name";
            // 
            // lbl_Subcategory_ID
            // 
            this.lbl_Subcategory_ID.AutoSize = true;
            this.lbl_Subcategory_ID.BackColor = System.Drawing.Color.SeaShell;
            this.lbl_Subcategory_ID.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Subcategory_ID.ForeColor = System.Drawing.Color.DarkRed;
            this.lbl_Subcategory_ID.Location = new System.Drawing.Point(112, 139);
            this.lbl_Subcategory_ID.Name = "lbl_Subcategory_ID";
            this.lbl_Subcategory_ID.Size = new System.Drawing.Size(159, 25);
            this.lbl_Subcategory_ID.TabIndex = 21;
            this.lbl_Subcategory_ID.Text = "Subcategory ID";
            // 
            // cb_Category_Name
            // 
            this.cb_Category_Name.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cb_Category_Name.FormattingEnabled = true;
            this.cb_Category_Name.Location = new System.Drawing.Point(401, 68);
            this.cb_Category_Name.Name = "cb_Category_Name";
            this.cb_Category_Name.Size = new System.Drawing.Size(273, 33);
            this.cb_Category_Name.TabIndex = 1;
            this.cb_Category_Name.SelectedIndexChanged += new System.EventHandler(this.cb_Category_Name_SelectedIndexChanged);
            // 
            // gb_Subcategory_Details
            // 
            this.gb_Subcategory_Details.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.gb_Subcategory_Details.Controls.Add(this.tb_Subcategory_Name);
            this.gb_Subcategory_Details.Controls.Add(this.tb_Subcategory_ID);
            this.gb_Subcategory_Details.Controls.Add(this.lbl_Subcategory_Name);
            this.gb_Subcategory_Details.Controls.Add(this.lbl_Subcategory_ID);
            this.gb_Subcategory_Details.Controls.Add(this.cb_Category_Name);
            this.gb_Subcategory_Details.Controls.Add(this.lbl_Category_Name);
            this.gb_Subcategory_Details.Font = new System.Drawing.Font("Georgia", 14.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))));
            this.gb_Subcategory_Details.ForeColor = System.Drawing.Color.Black;
            this.gb_Subcategory_Details.Location = new System.Drawing.Point(13, 98);
            this.gb_Subcategory_Details.Name = "gb_Subcategory_Details";
            this.gb_Subcategory_Details.Size = new System.Drawing.Size(779, 287);
            this.gb_Subcategory_Details.TabIndex = 9;
            this.gb_Subcategory_Details.TabStop = false;
            this.gb_Subcategory_Details.Text = "Subcategory Details";
            // 
            // lbl_Category_Name
            // 
            this.lbl_Category_Name.AutoSize = true;
            this.lbl_Category_Name.BackColor = System.Drawing.Color.SeaShell;
            this.lbl_Category_Name.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Category_Name.ForeColor = System.Drawing.Color.DarkRed;
            this.lbl_Category_Name.Location = new System.Drawing.Point(112, 72);
            this.lbl_Category_Name.Name = "lbl_Category_Name";
            this.lbl_Category_Name.Size = new System.Drawing.Size(161, 25);
            this.lbl_Category_Name.TabIndex = 20;
            this.lbl_Category_Name.Text = "Category Name";
            // 
            // btn_Save
            // 
            this.btn_Save.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.btn_Save.Font = new System.Drawing.Font("Lucida Bright", 27.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Save.ForeColor = System.Drawing.Color.White;
            this.btn_Save.Location = new System.Drawing.Point(330, 400);
            this.btn_Save.Name = "btn_Save";
            this.btn_Save.Size = new System.Drawing.Size(127, 56);
            this.btn_Save.TabIndex = 8;
            this.btn_Save.Text = "Save";
            this.btn_Save.UseVisualStyleBackColor = false;
            this.btn_Save.Click += new System.EventHandler(this.btn_Save_Click);
            // 
            // pb_Back
            // 
            this.pb_Back.Image = ((System.Drawing.Image)(resources.GetObject("pb_Back.Image")));
            this.pb_Back.Location = new System.Drawing.Point(12, 17);
            this.pb_Back.Name = "pb_Back";
            this.pb_Back.Size = new System.Drawing.Size(90, 45);
            this.pb_Back.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pb_Back.TabIndex = 4;
            this.pb_Back.TabStop = false;
            this.pb_Back.Click += new System.EventHandler(this.pb_Back_Click);
            // 
            // lbl_Header
            // 
            this.lbl_Header.AutoSize = true;
            this.lbl_Header.BackColor = System.Drawing.Color.Indigo;
            this.lbl_Header.Font = new System.Drawing.Font("Lucida Bright", 27.75F, System.Drawing.FontStyle.Bold);
            this.lbl_Header.ForeColor = System.Drawing.Color.LavenderBlush;
            this.lbl_Header.Location = new System.Drawing.Point(215, 20);
            this.lbl_Header.Name = "lbl_Header";
            this.lbl_Header.Size = new System.Drawing.Size(434, 42);
            this.lbl_Header.TabIndex = 0;
            this.lbl_Header.Text = "Add New Subcategory";
            // 
            // pnl_Add_New_Subcategory
            // 
            this.pnl_Add_New_Subcategory.BackColor = System.Drawing.Color.Indigo;
            this.pnl_Add_New_Subcategory.Controls.Add(this.pb_Back);
            this.pnl_Add_New_Subcategory.Controls.Add(this.lbl_Header);
            this.pnl_Add_New_Subcategory.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnl_Add_New_Subcategory.Location = new System.Drawing.Point(0, 0);
            this.pnl_Add_New_Subcategory.Name = "pnl_Add_New_Subcategory";
            this.pnl_Add_New_Subcategory.Size = new System.Drawing.Size(804, 92);
            this.pnl_Add_New_Subcategory.TabIndex = 7;
            // 
            // frm_Add_New_Subcategory
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(15F, 28F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.ClientSize = new System.Drawing.Size(804, 462);
            this.Controls.Add(this.gb_Subcategory_Details);
            this.Controls.Add(this.btn_Save);
            this.Controls.Add(this.pnl_Add_New_Subcategory);
            this.Font = new System.Drawing.Font("Lucida Bright", 18F);
            this.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.Margin = new System.Windows.Forms.Padding(8, 6, 8, 6);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "frm_Add_New_Subcategory";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Add New Subcategory";
            this.Load += new System.EventHandler(this.frm_Add_New_Subcategory_Load);
            this.gb_Subcategory_Details.ResumeLayout(false);
            this.gb_Subcategory_Details.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pb_Back)).EndInit();
            this.pnl_Add_New_Subcategory.ResumeLayout(false);
            this.pnl_Add_New_Subcategory.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TextBox tb_Subcategory_Name;
        private System.Windows.Forms.TextBox tb_Subcategory_ID;
        private System.Windows.Forms.Label lbl_Subcategory_Name;
        private System.Windows.Forms.Label lbl_Subcategory_ID;
        private System.Windows.Forms.ComboBox cb_Category_Name;
        private System.Windows.Forms.GroupBox gb_Subcategory_Details;
        private System.Windows.Forms.Label lbl_Category_Name;
        private System.Windows.Forms.Button btn_Save;
        private System.Windows.Forms.PictureBox pb_Back;
        private System.Windows.Forms.Label lbl_Header;
        private System.Windows.Forms.Panel pnl_Add_New_Subcategory;
    }
}