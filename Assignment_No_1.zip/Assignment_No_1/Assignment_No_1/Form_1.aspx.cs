﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Assignment_No_1
{
    public partial class Form_1 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            tb_Num1.Focus();
        }

        protected void btn_Sum_Click(object sender, EventArgs e)
        {
            lbl_Output.Text = (Convert.ToInt32(tb_Num1.Text) + Convert.ToInt32(tb_Num2.Text)).ToString();
        }
    }
}