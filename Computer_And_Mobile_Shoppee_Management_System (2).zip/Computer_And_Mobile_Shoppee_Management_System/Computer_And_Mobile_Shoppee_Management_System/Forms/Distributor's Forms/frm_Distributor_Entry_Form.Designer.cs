﻿namespace Computer_And_Mobile_Shoppee_Management_System
{
    partial class frm_Distributor_Entry_Form
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frm_Distributor_Entry_Form));
            this.pb_View_All_Distributors = new System.Windows.Forms.PictureBox();
            this.pb_Search_Or_Update_Distributor = new System.Windows.Forms.PictureBox();
            this.pb_Add_New_Distributor = new System.Windows.Forms.PictureBox();
            this.btn_View_Distributor_Details = new System.Windows.Forms.Button();
            this.btn_Search_Or_Update_Distributor = new System.Windows.Forms.Button();
            this.btn_Add_New_Distributor = new System.Windows.Forms.Button();
            this.pb_Close = new System.Windows.Forms.PictureBox();
            this.pb_Back = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pb_View_All_Distributors)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_Search_Or_Update_Distributor)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_Add_New_Distributor)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_Close)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_Back)).BeginInit();
            this.SuspendLayout();
            // 
            // pb_View_All_Distributors
            // 
            this.pb_View_All_Distributors.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.pb_View_All_Distributors.Image = ((System.Drawing.Image)(resources.GetObject("pb_View_All_Distributors.Image")));
            this.pb_View_All_Distributors.Location = new System.Drawing.Point(853, 450);
            this.pb_View_All_Distributors.Name = "pb_View_All_Distributors";
            this.pb_View_All_Distributors.Size = new System.Drawing.Size(100, 78);
            this.pb_View_All_Distributors.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pb_View_All_Distributors.TabIndex = 10;
            this.pb_View_All_Distributors.TabStop = false;
            // 
            // pb_Search_Or_Update_Distributor
            // 
            this.pb_Search_Or_Update_Distributor.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.pb_Search_Or_Update_Distributor.Image = ((System.Drawing.Image)(resources.GetObject("pb_Search_Or_Update_Distributor.Image")));
            this.pb_Search_Or_Update_Distributor.Location = new System.Drawing.Point(853, 330);
            this.pb_Search_Or_Update_Distributor.Name = "pb_Search_Or_Update_Distributor";
            this.pb_Search_Or_Update_Distributor.Size = new System.Drawing.Size(100, 78);
            this.pb_Search_Or_Update_Distributor.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pb_Search_Or_Update_Distributor.TabIndex = 11;
            this.pb_Search_Or_Update_Distributor.TabStop = false;
            // 
            // pb_Add_New_Distributor
            // 
            this.pb_Add_New_Distributor.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.pb_Add_New_Distributor.Image = ((System.Drawing.Image)(resources.GetObject("pb_Add_New_Distributor.Image")));
            this.pb_Add_New_Distributor.Location = new System.Drawing.Point(853, 213);
            this.pb_Add_New_Distributor.Name = "pb_Add_New_Distributor";
            this.pb_Add_New_Distributor.Size = new System.Drawing.Size(100, 78);
            this.pb_Add_New_Distributor.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pb_Add_New_Distributor.TabIndex = 12;
            this.pb_Add_New_Distributor.TabStop = false;
            // 
            // btn_View_Distributor_Details
            // 
            this.btn_View_Distributor_Details.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.btn_View_Distributor_Details.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.btn_View_Distributor_Details.Font = new System.Drawing.Font("Lucida Bright", 24F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_View_Distributor_Details.ForeColor = System.Drawing.Color.White;
            this.btn_View_Distributor_Details.Location = new System.Drawing.Point(380, 450);
            this.btn_View_Distributor_Details.Name = "btn_View_Distributor_Details";
            this.btn_View_Distributor_Details.Size = new System.Drawing.Size(467, 78);
            this.btn_View_Distributor_Details.TabIndex = 9;
            this.btn_View_Distributor_Details.Text = "View Distributors Details";
            this.btn_View_Distributor_Details.UseVisualStyleBackColor = false;
            this.btn_View_Distributor_Details.Click += new System.EventHandler(this.btn_View_Distributor_Details_Click);
            // 
            // btn_Search_Or_Update_Distributor
            // 
            this.btn_Search_Or_Update_Distributor.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btn_Search_Or_Update_Distributor.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.btn_Search_Or_Update_Distributor.Font = new System.Drawing.Font("Lucida Bright", 24F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Search_Or_Update_Distributor.ForeColor = System.Drawing.Color.White;
            this.btn_Search_Or_Update_Distributor.Location = new System.Drawing.Point(380, 330);
            this.btn_Search_Or_Update_Distributor.Name = "btn_Search_Or_Update_Distributor";
            this.btn_Search_Or_Update_Distributor.Size = new System.Drawing.Size(467, 78);
            this.btn_Search_Or_Update_Distributor.TabIndex = 8;
            this.btn_Search_Or_Update_Distributor.Text = "Search /Update Distributor";
            this.btn_Search_Or_Update_Distributor.UseVisualStyleBackColor = false;
            this.btn_Search_Or_Update_Distributor.Click += new System.EventHandler(this.btn_Search_Or_Update_Distributor_Click);
            // 
            // btn_Add_New_Distributor
            // 
            this.btn_Add_New_Distributor.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.btn_Add_New_Distributor.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.btn_Add_New_Distributor.Font = new System.Drawing.Font("Lucida Bright", 24F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Add_New_Distributor.ForeColor = System.Drawing.Color.White;
            this.btn_Add_New_Distributor.Location = new System.Drawing.Point(380, 213);
            this.btn_Add_New_Distributor.Name = "btn_Add_New_Distributor";
            this.btn_Add_New_Distributor.Size = new System.Drawing.Size(467, 78);
            this.btn_Add_New_Distributor.TabIndex = 7;
            this.btn_Add_New_Distributor.Text = "Add New Distributor";
            this.btn_Add_New_Distributor.UseVisualStyleBackColor = false;
            this.btn_Add_New_Distributor.Click += new System.EventHandler(this.btn_Add_New_Distributor_Click);
            // 
            // pb_Close
            // 
            this.pb_Close.Image = ((System.Drawing.Image)(resources.GetObject("pb_Close.Image")));
            this.pb_Close.Location = new System.Drawing.Point(1184, 34);
            this.pb_Close.Name = "pb_Close";
            this.pb_Close.Size = new System.Drawing.Size(105, 55);
            this.pb_Close.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pb_Close.TabIndex = 5;
            this.pb_Close.TabStop = false;
            this.pb_Close.Click += new System.EventHandler(this.pb_Close_Click);
            // 
            // pb_Back
            // 
            this.pb_Back.Image = ((System.Drawing.Image)(resources.GetObject("pb_Back.Image")));
            this.pb_Back.Location = new System.Drawing.Point(43, 39);
            this.pb_Back.Name = "pb_Back";
            this.pb_Back.Size = new System.Drawing.Size(100, 50);
            this.pb_Back.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pb_Back.TabIndex = 6;
            this.pb_Back.TabStop = false;
            this.pb_Back.Click += new System.EventHandler(this.pb_Back_Click);
            // 
            // frm_Distributor_Entry_Form
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(15F, 28F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.MediumPurple;
            this.ClientSize = new System.Drawing.Size(1344, 730);
            this.Controls.Add(this.pb_View_All_Distributors);
            this.Controls.Add(this.pb_Search_Or_Update_Distributor);
            this.Controls.Add(this.pb_Add_New_Distributor);
            this.Controls.Add(this.btn_View_Distributor_Details);
            this.Controls.Add(this.btn_Search_Or_Update_Distributor);
            this.Controls.Add(this.btn_Add_New_Distributor);
            this.Controls.Add(this.pb_Close);
            this.Controls.Add(this.pb_Back);
            this.Font = new System.Drawing.Font("Lucida Bright", 18F);
            this.Margin = new System.Windows.Forms.Padding(8, 6, 8, 6);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "frm_Distributor_Entry_Form";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Distributor Entry Form";
            this.Load += new System.EventHandler(this.frm_Distributor_Entry_Form_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pb_View_All_Distributors)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_Search_Or_Update_Distributor)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_Add_New_Distributor)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_Close)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_Back)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.PictureBox pb_View_All_Distributors;
        private System.Windows.Forms.PictureBox pb_Search_Or_Update_Distributor;
        private System.Windows.Forms.PictureBox pb_Add_New_Distributor;
        private System.Windows.Forms.Button btn_View_Distributor_Details;
        private System.Windows.Forms.Button btn_Search_Or_Update_Distributor;
        private System.Windows.Forms.Button btn_Add_New_Distributor;
        private System.Windows.Forms.PictureBox pb_Close;
        private System.Windows.Forms.PictureBox pb_Back;

    }
}