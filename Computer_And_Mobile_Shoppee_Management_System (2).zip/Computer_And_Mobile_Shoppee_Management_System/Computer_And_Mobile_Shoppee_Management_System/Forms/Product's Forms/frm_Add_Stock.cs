﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Computer_And_Mobile_Shoppee_Management_System
{
    public partial class frm_Add_Stock : Form
    {
        Global_ClassFile Gobj = new Global_ClassFile();

        public frm_Add_Stock()
        {
            InitializeComponent();
        }

        private void frm_Add_Stock_Load(object sender, EventArgs e)
        {
            Clear_Controls();
        }

        void Clear_Controls()
        {
            cb_Category.Text = " ";
            cb_Subcategory.Text = "";
            cb_Product_Name.Text = "";
            cb_Subcategory.Items.Clear();
            cb_Product_Name.Items.Clear();
            cb_Category.Enabled = true;
            cb_Subcategory.Enabled = true;
            cb_Product_Name.Enabled = true;
            dtp_Date.ResetText();
            tb_Current_Stock.Text = "";
            tb_New_Stock_Quantity.Text = "";
            cb_Category.Focus();
            tb_Product_ID.Text = "";
            cb_Category.Items.Clear();
            Bind_categories_To_ComboBox();
        }

        void Bind_categories_To_ComboBox()
        {
            cb_Category.Text = "";
            cb_Category.Items.Clear();

            Gobj.ConnectDB();

            SqlCommand Cmd = new SqlCommand("Select Distinct(Category_Name) From Category_Details", Gobj.Con);

            var obj = Cmd.ExecuteReader();

            while (obj.Read())
            {
                cb_Category.Items.Add(obj.GetString(obj.GetOrdinal("Category_Name")));
            }

            obj.Dispose();

            Gobj.DisconnectDB();
        }

        void Bind_Subcategories_To_Combobox()
        {
            Gobj.ConnectDB();

            SqlCommand cmd = new SqlCommand();

            cmd.CommandText = "Select Subcategory_Name From Subcategory_Details where Category_Name = '" + cb_Category.Text + "' ";
            cmd.Connection = Gobj.Con;

            var Obj = cmd.ExecuteReader();

            while (Obj.Read())
            {
                cb_Subcategory.Items.Add(Obj.GetString(Obj.GetOrdinal("Subcategory_Name")));
            }

            Gobj.DisconnectDB();
        }

        void Bind_Products_To_Combobox()
        {
            Gobj.ConnectDB();

            SqlCommand cmd = new SqlCommand();

            cmd.CommandText = "Select Product_Name From Product_Details where Subcategory = '" + cb_Subcategory.Text + "' ";
            cmd.Connection = Gobj.Con;

            var Obj = cmd.ExecuteReader();

            while (Obj.Read())
            {
                cb_Product_Name.Items.Add(Obj.GetString(Obj.GetOrdinal("Product_Name")));
            }

            Gobj.DisconnectDB();
        }

        private void cb_Category_SelectedIndexChanged(object sender, EventArgs e)
        {
            cb_Subcategory.Text = "";
            cb_Subcategory.Items.Clear();
            cb_Subcategory.Enabled = true;
            cb_Product_Name.Items.Clear();

            Bind_Subcategories_To_Combobox();
        }

        private void cb_Subcategory_SelectedIndexChanged(object sender, EventArgs e)
        {
            cb_Product_Name.Text = "";
            cb_Product_Name.Items.Clear();
            cb_Product_Name.Enabled = true;

            Bind_Products_To_Combobox();
        }

        private void cb_Product_Name_SelectedIndexChanged(object sender, EventArgs e)
        {
            cb_Product_Name.Enabled = false;
            cb_Category.Enabled = false;
            cb_Subcategory.Enabled = false;

            Gobj.ConnectDB();

            SqlCommand cmd = new SqlCommand();

            cmd.CommandText = "Select Product_ID From Product_Details where Product_Name = '" + cb_Product_Name.Text + "' ";
            cmd.Connection = Gobj.Con;

            var Obj = cmd.ExecuteReader();

            if (Obj.Read())
            {
                tb_Product_ID.Text = (Obj["Product_ID"].ToString());
            }
            Gobj.DisconnectDB();
        }

        private void tb_Product_ID_TextChanged(object sender, EventArgs e)
        {
            Gobj.ConnectDB();

            SqlCommand cmd = new SqlCommand();

            cmd.CommandText = "Select Stock_Quantity From Product_Details where Product_Name = '" + cb_Product_Name.Text + "' ";
            cmd.Connection = Gobj.Con;

            var Obj = cmd.ExecuteReader();

            if (Obj.Read())
            {
                tb_Current_Stock.Text = (Obj["Stock_Quantity"].ToString());
            }

            Gobj.DisconnectDB();
        }

        private void tb_New_Stock_Quantity_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!(Char.IsDigit(e.KeyChar) || (e.KeyChar == (char)Keys.Back)))
            {
                e.Handled = true;
            }
        }

        private void btn_Submit_Click(object sender, EventArgs e)
        {
            Gobj.ConnectDB();

            int stock =0;

            stock += Convert.ToInt32(tb_New_Stock_Quantity.Text);

            SqlCommand cmd = new SqlCommand();

            cmd.CommandText = "Select Username From Product_Details where Product_Name = '" + cb_Product_Name.Text + "' ";
            cmd.Connection = Gobj.Con;

            var Obj = cmd.ExecuteReader();

            string Username = "";

            if (Obj.Read())
            {            
                Username = (Obj["Username"].ToString());
            }
            Obj.Dispose();

            if (cb_Category.Text != "" && cb_Subcategory.Text != "" && cb_Product_Name.Text != "" && tb_Current_Stock.Text != "" && tb_Product_ID.Text != "" && tb_New_Stock_Quantity.Text != "")
            {
                SqlDataAdapter sda2 = new SqlDataAdapter(" Update Product_Details Set Stock_Quantity = (Stock_Quantity + '" + stock + "') , Updaters_Uname ='" + Global_ClassFile.Uname + "' Where Product_ID = " + tb_Product_ID.Text + "", Gobj.Con);
                DataTable dt = new DataTable();
                sda2.Fill(dt);

                SqlDataAdapter sda = new SqlDataAdapter("Insert into Stock_Details(Product_ID ,Category ,Subcategory ,Product_Name ,Date ,Stock_Quantity ,Updaters_Uname ,Username) values(" + tb_Product_ID.Text + ",'" + cb_Category.Text + "','" + cb_Subcategory.Text + "','" + cb_Product_Name.Text + "','" + dtp_Date.Text + "'," + tb_New_Stock_Quantity.Text + ",'" + Global_ClassFile.Uname + "','" + Username + "')", Gobj.Con);
                DataTable DT2 = new DataTable();
                sda.Fill(DT2);


                MessageBox.Show("Record Saved Successfully...", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);

                Clear_Controls();
                Bind_categories_To_ComboBox();
            }

            else
            {
                MessageBox.Show("Please, Fill All The Fields", "Failure", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

            Gobj.DisconnectDB();
        }

        private void btn_Refresh_Click(object sender, EventArgs e)
        {
            Clear_Controls();
            Bind_categories_To_ComboBox();
        }

        private void pb_Back_Click(object sender, EventArgs e)
        {
            frm_Product_Entry_Form Obj = new frm_Product_Entry_Form();

            this.Hide();
            Obj.Show();
        }

        private void pb_Close_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show("Do You Want To Close This Appllication?", "close Application", MessageBoxButtons.YesNo);

            if (result == DialogResult.Yes)
            {
                frm_Login obj = new frm_Login();
                this.Hide();
                obj.Show();
            }
            else
            {
                this.Show();
            }
        }
    }
}
