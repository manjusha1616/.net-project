﻿namespace Computer_And_Mobile_Shoppee_Management_System
{
    partial class frm_Customer_Entry_Form
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frm_Customer_Entry_Form));
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.btn_Add_New_Customer = new System.Windows.Forms.Button();
            this.pb_Close = new System.Windows.Forms.PictureBox();
            this.pb_Back = new System.Windows.Forms.PictureBox();
            this.pb_View_Customer_Details = new System.Windows.Forms.PictureBox();
            this.btn_View_Customer_Details = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_Close)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_Back)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_View_Customer_Details)).BeginInit();
            this.SuspendLayout();
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(858, 290);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(100, 78);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 7;
            this.pictureBox1.TabStop = false;
            // 
            // btn_Add_New_Customer
            // 
            this.btn_Add_New_Customer.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.btn_Add_New_Customer.Font = new System.Drawing.Font("Lucida Bright", 24F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))));
            this.btn_Add_New_Customer.ForeColor = System.Drawing.Color.White;
            this.btn_Add_New_Customer.Location = new System.Drawing.Point(385, 290);
            this.btn_Add_New_Customer.Name = "btn_Add_New_Customer";
            this.btn_Add_New_Customer.Size = new System.Drawing.Size(467, 78);
            this.btn_Add_New_Customer.TabIndex = 6;
            this.btn_Add_New_Customer.Text = "Add New Customer";
            this.btn_Add_New_Customer.UseVisualStyleBackColor = false;
            this.btn_Add_New_Customer.Click += new System.EventHandler(this.btn_Add_New_Customer_Click);
            // 
            // pb_Close
            // 
            this.pb_Close.Image = ((System.Drawing.Image)(resources.GetObject("pb_Close.Image")));
            this.pb_Close.Location = new System.Drawing.Point(1199, 35);
            this.pb_Close.Name = "pb_Close";
            this.pb_Close.Size = new System.Drawing.Size(105, 55);
            this.pb_Close.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pb_Close.TabIndex = 5;
            this.pb_Close.TabStop = false;
            this.pb_Close.Click += new System.EventHandler(this.pb_Close_Click);
            // 
            // pb_Back
            // 
            this.pb_Back.Image = ((System.Drawing.Image)(resources.GetObject("pb_Back.Image")));
            this.pb_Back.Location = new System.Drawing.Point(45, 40);
            this.pb_Back.Name = "pb_Back";
            this.pb_Back.Size = new System.Drawing.Size(100, 50);
            this.pb_Back.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pb_Back.TabIndex = 4;
            this.pb_Back.TabStop = false;
            this.pb_Back.Click += new System.EventHandler(this.pb_Back_Click);
            // 
            // pb_View_Customer_Details
            // 
            this.pb_View_Customer_Details.Image = ((System.Drawing.Image)(resources.GetObject("pb_View_Customer_Details.Image")));
            this.pb_View_Customer_Details.Location = new System.Drawing.Point(858, 386);
            this.pb_View_Customer_Details.Name = "pb_View_Customer_Details";
            this.pb_View_Customer_Details.Size = new System.Drawing.Size(100, 78);
            this.pb_View_Customer_Details.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pb_View_Customer_Details.TabIndex = 7;
            this.pb_View_Customer_Details.TabStop = false;
            // 
            // btn_View_Customer_Details
            // 
            this.btn_View_Customer_Details.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.btn_View_Customer_Details.Font = new System.Drawing.Font("Lucida Bright", 24F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))));
            this.btn_View_Customer_Details.ForeColor = System.Drawing.Color.White;
            this.btn_View_Customer_Details.Location = new System.Drawing.Point(385, 386);
            this.btn_View_Customer_Details.Name = "btn_View_Customer_Details";
            this.btn_View_Customer_Details.Size = new System.Drawing.Size(467, 78);
            this.btn_View_Customer_Details.TabIndex = 8;
            this.btn_View_Customer_Details.Text = "View Customer Details";
            this.btn_View_Customer_Details.UseVisualStyleBackColor = false;
            this.btn_View_Customer_Details.Click += new System.EventHandler(this.btn_View_Customer_Details_Click);
            // 
            // frm_Customer_Entry_Form
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(21F, 36F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.MediumPurple;
            this.ClientSize = new System.Drawing.Size(1344, 730);
            this.Controls.Add(this.btn_View_Customer_Details);
            this.Controls.Add(this.pb_View_Customer_Details);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.btn_Add_New_Customer);
            this.Controls.Add(this.pb_Close);
            this.Controls.Add(this.pb_Back);
            this.Font = new System.Drawing.Font("Lucida Bright", 24F, System.Drawing.FontStyle.Bold);
            this.Margin = new System.Windows.Forms.Padding(10, 8, 10, 8);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "frm_Customer_Entry_Form";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Customer Entry Form";
            this.Load += new System.EventHandler(this.frm_Customer_Entry_Form_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_Close)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_Back)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_View_Customer_Details)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button btn_Add_New_Customer;
        private System.Windows.Forms.PictureBox pb_Close;
        private System.Windows.Forms.PictureBox pb_Back;
        private System.Windows.Forms.PictureBox pb_View_Customer_Details;
        private System.Windows.Forms.Button btn_View_Customer_Details;
    }
}