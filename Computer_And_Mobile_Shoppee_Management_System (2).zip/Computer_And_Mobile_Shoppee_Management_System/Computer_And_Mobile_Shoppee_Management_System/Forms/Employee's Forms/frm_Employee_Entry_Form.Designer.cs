﻿namespace Computer_And_Mobile_Shoppee_Management_System
{
    partial class frm_Employee_Entry_Form
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frm_Employee_Entry_Form));
            this.pb_View_All_Employees = new System.Windows.Forms.PictureBox();
            this.pb_Search_Or_Update_Employee = new System.Windows.Forms.PictureBox();
            this.pb_Add_Employee = new System.Windows.Forms.PictureBox();
            this.btn_View_All_Employees = new System.Windows.Forms.Button();
            this.btn_Search_Or_Update_Employee = new System.Windows.Forms.Button();
            this.btn_Add_Employee = new System.Windows.Forms.Button();
            this.pb_Close = new System.Windows.Forms.PictureBox();
            this.pb_Back = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pb_View_All_Employees)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_Search_Or_Update_Employee)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_Add_Employee)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_Close)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_Back)).BeginInit();
            this.SuspendLayout();
            // 
            // pb_View_All_Employees
            // 
            this.pb_View_All_Employees.Image = ((System.Drawing.Image)(resources.GetObject("pb_View_All_Employees.Image")));
            this.pb_View_All_Employees.Location = new System.Drawing.Point(849, 445);
            this.pb_View_All_Employees.Name = "pb_View_All_Employees";
            this.pb_View_All_Employees.Size = new System.Drawing.Size(100, 78);
            this.pb_View_All_Employees.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pb_View_All_Employees.TabIndex = 14;
            this.pb_View_All_Employees.TabStop = false;
            // 
            // pb_Search_Or_Update_Employee
            // 
            this.pb_Search_Or_Update_Employee.Image = ((System.Drawing.Image)(resources.GetObject("pb_Search_Or_Update_Employee.Image")));
            this.pb_Search_Or_Update_Employee.Location = new System.Drawing.Point(849, 325);
            this.pb_Search_Or_Update_Employee.Name = "pb_Search_Or_Update_Employee";
            this.pb_Search_Or_Update_Employee.Size = new System.Drawing.Size(100, 78);
            this.pb_Search_Or_Update_Employee.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pb_Search_Or_Update_Employee.TabIndex = 13;
            this.pb_Search_Or_Update_Employee.TabStop = false;
            // 
            // pb_Add_Employee
            // 
            this.pb_Add_Employee.Image = ((System.Drawing.Image)(resources.GetObject("pb_Add_Employee.Image")));
            this.pb_Add_Employee.Location = new System.Drawing.Point(849, 208);
            this.pb_Add_Employee.Name = "pb_Add_Employee";
            this.pb_Add_Employee.Size = new System.Drawing.Size(100, 78);
            this.pb_Add_Employee.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pb_Add_Employee.TabIndex = 12;
            this.pb_Add_Employee.TabStop = false;
            // 
            // btn_View_All_Employees
            // 
            this.btn_View_All_Employees.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.btn_View_All_Employees.Font = new System.Drawing.Font("Lucida Bright", 24F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))));
            this.btn_View_All_Employees.ForeColor = System.Drawing.Color.White;
            this.btn_View_All_Employees.Location = new System.Drawing.Point(376, 445);
            this.btn_View_All_Employees.Name = "btn_View_All_Employees";
            this.btn_View_All_Employees.Size = new System.Drawing.Size(467, 78);
            this.btn_View_All_Employees.TabIndex = 11;
            this.btn_View_All_Employees.Text = "View All Employees";
            this.btn_View_All_Employees.UseVisualStyleBackColor = false;
            this.btn_View_All_Employees.Click += new System.EventHandler(this.btn_View_All_Employees_Click);
            // 
            // btn_Search_Or_Update_Employee
            // 
            this.btn_Search_Or_Update_Employee.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.btn_Search_Or_Update_Employee.Font = new System.Drawing.Font("Lucida Bright", 24F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))));
            this.btn_Search_Or_Update_Employee.ForeColor = System.Drawing.Color.White;
            this.btn_Search_Or_Update_Employee.Location = new System.Drawing.Point(376, 325);
            this.btn_Search_Or_Update_Employee.Name = "btn_Search_Or_Update_Employee";
            this.btn_Search_Or_Update_Employee.Size = new System.Drawing.Size(467, 78);
            this.btn_Search_Or_Update_Employee.TabIndex = 10;
            this.btn_Search_Or_Update_Employee.Text = "Search / Update Employee";
            this.btn_Search_Or_Update_Employee.UseVisualStyleBackColor = false;
            this.btn_Search_Or_Update_Employee.Click += new System.EventHandler(this.btn_Search_Or_Update_Employee_Click);
            // 
            // btn_Add_Employee
            // 
            this.btn_Add_Employee.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.btn_Add_Employee.Font = new System.Drawing.Font("Lucida Bright", 24F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))));
            this.btn_Add_Employee.ForeColor = System.Drawing.Color.White;
            this.btn_Add_Employee.Location = new System.Drawing.Point(376, 208);
            this.btn_Add_Employee.Name = "btn_Add_Employee";
            this.btn_Add_Employee.Size = new System.Drawing.Size(467, 78);
            this.btn_Add_Employee.TabIndex = 8;
            this.btn_Add_Employee.Text = "Add New Employee";
            this.btn_Add_Employee.UseVisualStyleBackColor = false;
            this.btn_Add_Employee.Click += new System.EventHandler(this.btn_Add_Employee_Click);
            // 
            // pb_Close
            // 
            this.pb_Close.Image = ((System.Drawing.Image)(resources.GetObject("pb_Close.Image")));
            this.pb_Close.Location = new System.Drawing.Point(1187, 25);
            this.pb_Close.Name = "pb_Close";
            this.pb_Close.Size = new System.Drawing.Size(105, 55);
            this.pb_Close.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pb_Close.TabIndex = 9;
            this.pb_Close.TabStop = false;
            this.pb_Close.Click += new System.EventHandler(this.pb_Close_Click);
            // 
            // pb_Back
            // 
            this.pb_Back.Image = ((System.Drawing.Image)(resources.GetObject("pb_Back.Image")));
            this.pb_Back.Location = new System.Drawing.Point(60, 25);
            this.pb_Back.Name = "pb_Back";
            this.pb_Back.Size = new System.Drawing.Size(100, 50);
            this.pb_Back.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pb_Back.TabIndex = 7;
            this.pb_Back.TabStop = false;
            this.pb_Back.Click += new System.EventHandler(this.pb_Back_Click);
            // 
            // frm_Employee_Entry_Form
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(21F, 36F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.MediumPurple;
            this.ClientSize = new System.Drawing.Size(1344, 730);
            this.Controls.Add(this.pb_View_All_Employees);
            this.Controls.Add(this.pb_Search_Or_Update_Employee);
            this.Controls.Add(this.pb_Add_Employee);
            this.Controls.Add(this.btn_View_All_Employees);
            this.Controls.Add(this.btn_Search_Or_Update_Employee);
            this.Controls.Add(this.btn_Add_Employee);
            this.Controls.Add(this.pb_Close);
            this.Controls.Add(this.pb_Back);
            this.Font = new System.Drawing.Font("Lucida Bright", 24F, System.Drawing.FontStyle.Bold);
            this.Margin = new System.Windows.Forms.Padding(10, 8, 10, 8);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "frm_Employee_Entry_Form";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Employee Entry Form";
            this.Load += new System.EventHandler(this.frm_Employee_Entry_Form_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pb_View_All_Employees)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_Search_Or_Update_Employee)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_Add_Employee)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_Close)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_Back)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.PictureBox pb_View_All_Employees;
        private System.Windows.Forms.PictureBox pb_Search_Or_Update_Employee;
        private System.Windows.Forms.PictureBox pb_Add_Employee;
        private System.Windows.Forms.Button btn_View_All_Employees;
        private System.Windows.Forms.Button btn_Search_Or_Update_Employee;
        private System.Windows.Forms.Button btn_Add_Employee;
        private System.Windows.Forms.PictureBox pb_Close;
        private System.Windows.Forms.PictureBox pb_Back;
    }
}