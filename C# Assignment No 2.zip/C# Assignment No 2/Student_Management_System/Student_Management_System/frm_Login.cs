﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Student_Management_System
{
    public partial class frm_Login : Form
    {
        public frm_Login()
        {
            InitializeComponent();
        }

        private void btn_Submit_Click(object sender, EventArgs e)
        {
            if (tb_Username.Text == "A" && tb_Password.Text == "A")
            {
                MessageBox.Show("Login Successfull!!!");
                frm_Add_New_Student Obj = new frm_Add_New_Student();
                Obj.Show();
                this.Hide();
            }
            else
            {
                MessageBox.Show("Login Failed, Please Enter Valid Username & Password");
            }

            tb_Username.Text = "";
            tb_Password.Text = "";
            tb_Username.Focus();
        }
    }
}
