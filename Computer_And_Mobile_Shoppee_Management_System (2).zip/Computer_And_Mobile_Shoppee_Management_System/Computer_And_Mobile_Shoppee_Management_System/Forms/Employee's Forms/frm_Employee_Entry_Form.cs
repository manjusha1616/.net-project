﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Computer_And_Mobile_Shoppee_Management_System
{
    public partial class frm_Employee_Entry_Form : Form
    {
        public frm_Employee_Entry_Form()
        {
            InitializeComponent();
        }

        private void frm_Employee_Entry_Form_Load(object sender, EventArgs e)
        {
            pb_Back.Focus();
        }

        private void btn_Add_Employee_Click(object sender, EventArgs e)
        {
            frm_Add_New_Employee Obj = new frm_Add_New_Employee();

            Obj.WindowState = FormWindowState.Maximized;
            this.Hide();
            Obj.Show();
        }

        private void btn_Search_Or_Update_Employee_Click(object sender, EventArgs e)
        {
            frm_Search_Or_Update_Employee Obj = new frm_Search_Or_Update_Employee();

            Obj.WindowState = FormWindowState.Maximized;
            this.Hide();
            Obj.Show();
        }

        private void btn_View_All_Employees_Click(object sender, EventArgs e)
        {
            frm_View_All_Employees Obj = new frm_View_All_Employees();

            Obj.WindowState = FormWindowState.Maximized;
            this.Hide();
            Obj.Show();
        }

        private void pb_Back_Click(object sender, EventArgs e)
        {
            frm_Entry_Form Obj = new frm_Entry_Form();

            Obj.WindowState = FormWindowState.Maximized;
            this.Hide();
            Obj.Show();
        }

        private void pb_Close_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show("Do You Want To Close This Appllication?", "close Application", MessageBoxButtons.YesNo);

            if (result == DialogResult.Yes)
            {
                frm_Login obj = new frm_Login();
                this.Hide();
                obj.Show();
            }
            else
            {
                this.Show();
            }
        }
    }
}
