﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Student_Management_System
{
    public partial class frm_Search_Student : Form
    {
        SqlConnection Con = new SqlConnection(@"Data Source=.\SQLEXPRESS;Initial Catalog=Student_Data_System_DB;Integrated Security=True");

        void Con_Open()
        {
            if (Con.State == ConnectionState.Closed)
            {
                Con.Open();
            }
        }

        void Con_Close()
        {
            if (Con.State == ConnectionState.Open)
            {
                Con.Close();
            }
        }

        private void frm_Search_Student_Load(object sender, EventArgs e)
        {
            tb_Roll_No.Focus();
        }

        void Clear_Controls()
        {
            tb_Roll_No.Clear();
            tb_Name.Clear();
            tb_Mob_No.Clear();
            cb_Course.Clear();
            dtp_DOB.ResetText();
            tb_Roll_No.Focus();
            cb_Course.Enabled = false;
            tb_Name.Enabled =false;
            tb_Mob_No.Enabled = false;
            dtp_DOB.Enabled = false;
        }


        public frm_Search_Student()
        {
            InitializeComponent();
        }

        private void btn_Log_Out_Click(object sender, EventArgs e)
        {
            frm_Login a = new frm_Login();
            a.Show();
            this.Hide();
        }

        private void btn_Reset_Click(object sender, EventArgs e)
        {
            Clear_Controls();
        }

        private void btn_Add_New_Students_Click(object sender, EventArgs e)
        {
            frm_Add_New_Student obj = new frm_Add_New_Student();
            obj.Show();
            this.Hide();
                       
        }

        private void btn_View_All_Students_Click(object sender, EventArgs e)
        {
            frm_View_All_Students obj = new frm_View_All_Students();
            obj.Show();
            this.Hide();
        }

        private void btn_Search_Click(object sender, EventArgs e)
        {
            Con_Open();

            SqlCommand cmd = new SqlCommand("Select * from Student_Details where Roll_No = " + tb_Roll_No.Text + " ",Con);

            var obj = cmd.ExecuteReader();

            if (obj.Read())
            {
                tb_Name.Text = obj.GetString(obj.GetOrdinal("Name"));
                tb_Mob_No.Text = (obj["Mob_No"].ToString());
                dtp_DOB.Text = (obj["DOB"].ToString());
                cb_Course.Text = obj.GetString(obj.GetOrdinal("Course"));
            }
            else 
            {
                MessageBox.Show("Invalid Roll No");
                tb_Roll_No.Clear();
                tb_Roll_No.Focus();
            }
            Con_Close();
        }
    }
}
